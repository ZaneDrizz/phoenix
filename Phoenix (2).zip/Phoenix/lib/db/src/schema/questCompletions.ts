import { date, integer, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const questCompletionsTable = pgTable("quest_completions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  questId: text("quest_id").notNull(),
  completedOn: date("completed_on", { mode: "string" }).notNull(),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
}, (table) => ({
  userQuestDayUnique: uniqueIndex("quest_completions_user_quest_day_unique").on(table.userId, table.questId, table.completedOn),
}));

export type QuestCompletion = typeof questCompletionsTable.$inferSelect;