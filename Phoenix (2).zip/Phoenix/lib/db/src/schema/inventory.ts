import { pgTable, integer, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const userInventoryTable = pgTable("user_inventory", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  itemId: text("item_id").notNull(),
  purchasedAt: timestamp("purchased_at").notNull().defaultNow(),
}, (table) => ({
  userItemUnique: uniqueIndex("user_inventory_user_item_unique").on(table.userId, table.itemId),
}));

export type UserInventoryItem = typeof userInventoryTable.$inferSelect;