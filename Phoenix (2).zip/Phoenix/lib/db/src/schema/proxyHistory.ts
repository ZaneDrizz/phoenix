import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const proxyHistoryTable = pgTable("proxy_history", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  finalUrl: text("final_url").notNull(),
  title: text("title"),
  favicon: text("favicon"),
  visitedAt: timestamp("visited_at").notNull().defaultNow(),
});

export const insertProxyHistorySchema = createInsertSchema(proxyHistoryTable).omit({ id: true, visitedAt: true });
export type InsertProxyHistory = z.infer<typeof insertProxyHistorySchema>;
export type ProxyHistory = typeof proxyHistoryTable.$inferSelect;
