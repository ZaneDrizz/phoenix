import { pgTable, text, serial, integer, date, timestamp } from "drizzle-orm/pg-core";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  displayName: text("display_name").notNull().default(""),
  bio: text("bio").notNull().default(""),
  passwordHash: text("password_hash").notNull(),
  token: text("token"),
  avatarUrl: text("avatar_url"),
  avatarDecoration: text("avatar_decoration").notNull().default("none"),
  atbucks: integer("atbucks").notNull().default(0),
  lastDailyClaim: date("last_daily_claim", { mode: "string" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type User = typeof usersTable.$inferSelect;
