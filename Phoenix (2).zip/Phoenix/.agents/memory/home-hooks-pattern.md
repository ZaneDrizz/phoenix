---
name: Home.tsx hooks pattern
description: Rules of hooks violation when using useState inside IIFEs in JSX.
---

## Rule
Never call `useState` (or any React hook) inside an IIFE (`{(() => { const [x] = useState(); ... })()}`). This violates the Rules of Hooks.

## Why
React hooks must be called unconditionally at the top level of a function component or custom hook. An IIFE is a regular function call — not a component — so hooks inside it are forbidden and will throw at runtime.

## How to apply
Always lift state to the enclosing component. If a subsection of settings needs local state, convert it into a proper sub-component and mount it in the JSX tree, or add the state directly to the parent component (e.g. SettingsModal).
