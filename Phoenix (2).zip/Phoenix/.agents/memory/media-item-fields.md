---
name: MediaItem and AnimeItem required fields
description: Both interfaces have required string fields that reject null.
---

## MediaItem (movies-view.tsx)
```ts
interface MediaItem {
  id: number; title: string; poster: string | null; backdrop: string | null;
  year: string;      // NOT nullable
  rating: number;
  overview: string;  // NOT nullable
  kind: "movie" | "tv";
}
```

## AnimeItem (anime-view.tsx)
```ts
interface AnimeItem {
  mal_id: number; title: string; poster: string | null; backdrop: string | null;
  year: string;     // NOT nullable
  rating: number;
  overview: string; // NOT nullable
  episodes: number | null;
  kind: "anime";    // required literal
  status: string;   // required
}
```

## How to apply
When mapping WatchlistItem to MediaItem/AnimeItem for the "My List" shelf, use `year: ""` and `overview: ""` (empty strings), not `null`. AnimeItem also needs `kind: "anime" as const` and `status: ""`.
