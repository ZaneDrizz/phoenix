---
name: Production schema sync
description: How published Phoenix API failures relate to the managed production database
---

The published API can remain reachable while auth and feature routes fail if production's managed PostgreSQL schema is behind development. Production schema changes must be applied through Publish after the production database is unfrozen; do not add startup DDL or deployment migration scripts.

**Why:** The live health endpoint stayed healthy while login failed on a query containing newer `users` columns, and the production database inspection path reported that the database was frozen.

**How to apply:** When a published route reports database query failures but health is 200, check the production database state and schema diff, unfreeze it in the database workspace if required, then use Publish to apply the schema.