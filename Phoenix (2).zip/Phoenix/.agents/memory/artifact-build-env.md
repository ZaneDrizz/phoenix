---
name: Artifact production build environment
description: Required environment variables for this project's Vite production build
---

The web artifact's production build must receive both `PORT` and `BASE_PATH` explicitly in its build environment; runtime service variables alone are not available while Vite loads its config.

**Why:** Running the package build outside the managed development workflow failed immediately when either required variable was absent, which would block publishing even though the dev preview worked.

**How to apply:** When changing the web artifact's production build settings, keep `PORT` and `BASE_PATH` in the validated production build environment as well as the runtime service environment.