---
name: GameEntry type from gameprefs
description: Type and return shape of gameprefs utility functions.
---

## GameEntry shape
```ts
interface GameEntry { t: string; u: string; g?: string; }
```
Games in the GAMES array also have `i?: string` (thumbnail URL) that is not in the GameEntry type — cast with `g as GameEntry & { i?: string }` when needed.

## Key functions
- `getGameFavorites(): GameEntry[]` — returns full GameEntry objects, not strings
- `toggleGameFavorite(game: GameEntry): boolean` — returns true if now favorited
- `isGameFavorite(url: string): boolean`
- `getRecentGames(): GameEntry[]` — last 8 played
- `addToRecentGames(game: GameEntry): void`

## How to apply
gameFavorites state must be typed `GameEntry[]`, not `string[]`. Call `addToRecentGames(g)` inside `launchGame` to track recents.
