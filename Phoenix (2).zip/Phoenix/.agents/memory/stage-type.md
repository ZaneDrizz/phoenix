---
name: Stage type in home.tsx
description: The Stage union type must be kept in sync with all nav targets.
---

## Current Stage union
```ts
type Stage = "login" | "welcome" | "theme" | "cloak" | "autocloak" | "home" | "browser" | "games" | "movies" | "anime" | "music" | "chat" | "ai" | "html";
```

## Why
Every new nav section (e.g. "html") must be added to Stage explicitly. Missing stages cause TS2367 "comparison appears to be unintentional" errors in the nav handler and stage conditionals.

## How to apply
Whenever a new nav item is added to NAV_ITEMS, add its id to the Stage union type as well.
