import { Router, type Request, type Response } from "express";
import { db, userInventoryTable, usersTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { randomUUID } from "crypto";
import { getAccountId } from "../lib/accounts";

const router = Router();
const AVATAR_DECORATIONS = new Set(["none", "sparkles", "crown", "flame", "hearts", "halo", "diamond"]);

router.post("/auth/register", async (req: Request, res: Response) => {
  const { username, password, displayName } = req.body as { username?: string; password?: string; displayName?: string };
  if (!username?.trim() || !password) {
    res.status(400).json({ error: "Username and password required" });
    return;
  }
  const u = username.trim();
  if (u.length < 2 || u.length > 24) {
    res.status(400).json({ error: "Username must be 2–24 characters" });
    return;
  }
  if (!/^[a-zA-Z0-9_]+$/.test(u)) {
    res.status(400).json({ error: "Username: letters, numbers, underscores only" });
    return;
  }
  if (password.length < 4) {
    res.status(400).json({ error: "Password must be at least 4 characters" });
    return;
  }
  const name = displayName?.trim() || u;
  if (name.length > 32) {
    res.status(400).json({ error: "Display name must be 32 characters or fewer" });
    return;
  }

  const existing = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.username, u)).limit(1);
  if (existing.length > 0) {
    res.status(409).json({ error: "Username already taken" });
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const token = randomUUID();
  const [user] = await db.insert(usersTable).values({ username: u, displayName: name, passwordHash, token }).returning({ id: usersTable.id, username: usersTable.username, displayName: usersTable.displayName, bio: usersTable.bio, token: usersTable.token, avatarUrl: usersTable.avatarUrl, avatarDecoration: usersTable.avatarDecoration });
  res.json({ accountId: getAccountId(user.id), username: user.username, displayName: user.displayName, bio: user.bio, token: user.token, avatarUrl: user.avatarUrl, avatarDecoration: user.avatarDecoration });
});

router.post("/auth/login", async (req: Request, res: Response) => {
  const { username, password } = req.body as { username?: string; password?: string };
  if (!username?.trim() || !password) {
    res.status(400).json({ error: "Username and password required" });
    return;
  }
  const u = username.trim();
  const [user] = await db.select().from(usersTable).where(eq(usersTable.username, u)).limit(1);
  if (!user) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }
  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }
  const token = randomUUID();
  await db.update(usersTable).set({ token }).where(eq(usersTable.id, user.id));
  res.json({ accountId: getAccountId(user.id), username: user.username, displayName: user.displayName, bio: user.bio, token, avatarUrl: user.avatarUrl, avatarDecoration: user.avatarDecoration });
});

router.post("/auth/change-password", async (req: Request, res: Response) => {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) { res.status(401).json({ error: "Unauthorized" }); return; }
  const token = auth.slice(7);
  const { currentPassword, newPassword } = req.body as { currentPassword?: string; newPassword?: string };
  if (!currentPassword || !newPassword) { res.status(400).json({ error: "Both passwords required" }); return; }
  if (newPassword.length < 4) { res.status(400).json({ error: "New password must be at least 4 characters" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.token, token)).limit(1);
  if (!user) { res.status(401).json({ error: "Invalid token" }); return; }
  const match = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!match) { res.status(400).json({ error: "Current password is incorrect" }); return; }
  const newHash = await bcrypt.hash(newPassword, 10);
  await db.update(usersTable).set({ passwordHash: newHash }).where(eq(usersTable.id, user.id));
  res.json({ success: true });
});

router.get("/auth/me", async (req: Request, res: Response) => {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const token = auth.slice(7);
  const [user] = await db.select({ id: usersTable.id, username: usersTable.username, displayName: usersTable.displayName, bio: usersTable.bio, avatarUrl: usersTable.avatarUrl, avatarDecoration: usersTable.avatarDecoration }).from(usersTable).where(eq(usersTable.token, token)).limit(1);
  if (!user) {
    res.status(401).json({ error: "Invalid token" });
    return;
  }
  res.json({ accountId: getAccountId(user.id), username: user.username, displayName: user.displayName, bio: user.bio, avatarUrl: user.avatarUrl, avatarDecoration: user.avatarDecoration });
});

router.patch("/auth/profile", async (req: Request, res: Response) => {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) { res.status(401).json({ error: "Unauthorized" }); return; }
  const [user] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.token, auth.slice(7))).limit(1);
  if (!user) { res.status(401).json({ error: "Invalid token" }); return; }
  const { avatarUrl, avatarDecoration, displayName, bio } = req.body as { avatarUrl?: unknown; avatarDecoration?: unknown; displayName?: unknown; bio?: unknown };
  if (avatarUrl !== undefined && avatarUrl !== null && (typeof avatarUrl !== "string" || !avatarUrl.startsWith("data:image/") || avatarUrl.length > 1_400_000)) {
    res.status(400).json({ error: "Use an image smaller than 1 MB." });
    return;
  }
  if (displayName !== undefined && (typeof displayName !== "string" || displayName.trim().length < 1 || displayName.trim().length > 32)) {
    res.status(400).json({ error: "Display name must be 1–32 characters." });
    return;
  }
  if (bio !== undefined && (typeof bio !== "string" || bio.length > 190)) {
    res.status(400).json({ error: "About me must be 190 characters or fewer." });
    return;
  }
  if (avatarDecoration !== undefined && (typeof avatarDecoration !== "string" || !AVATAR_DECORATIONS.has(avatarDecoration))) {
    res.status(400).json({ error: "That avatar decoration is not available." });
    return;
  }
  if (avatarDecoration !== undefined && avatarDecoration !== "none") {
    const [owned] = await db.select({ id: userInventoryTable.id }).from(userInventoryTable).where(and(
      eq(userInventoryTable.userId, user.id),
      eq(userInventoryTable.itemId, `decoration:${avatarDecoration}`),
    )).limit(1);
    if (!owned) {
      res.status(403).json({ error: "Buy that decoration in AtBucks before equipping it." });
      return;
    }
  }
  const changes: { avatarUrl?: string | null; avatarDecoration?: string; displayName?: string; bio?: string } = {};
  if (avatarUrl !== undefined) changes.avatarUrl = avatarUrl === null ? null : avatarUrl;
  if (avatarDecoration !== undefined) changes.avatarDecoration = avatarDecoration;
  if (displayName !== undefined) changes.displayName = displayName.trim();
  if (bio !== undefined) changes.bio = bio;
  await db.update(usersTable).set(changes).where(eq(usersTable.id, user.id));
  const [updated] = await db.select({ displayName: usersTable.displayName, bio: usersTable.bio, avatarUrl: usersTable.avatarUrl, avatarDecoration: usersTable.avatarDecoration }).from(usersTable).where(eq(usersTable.id, user.id)).limit(1);
  res.json(updated);
});

export default router;
