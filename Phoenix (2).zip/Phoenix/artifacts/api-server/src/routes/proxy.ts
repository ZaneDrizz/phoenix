import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, proxyHistoryTable } from "@workspace/db";
import { ProxyFetchBody, ProxyFetchResponse, GetProxyHistoryResponse, ClearProxyHistoryResponse } from "@workspace/api-zod";
import * as cheerio from "cheerio";

const router: IRouter = Router();

function rewriteHtml(html: string, baseUrl: string): string {
  const $ = cheerio.load(html);
  const base = new URL(baseUrl);

  $("base").remove();
  $("head").prepend(`<base href="${baseUrl}">`);

  $("a[href]").each((_, el) => {
    const href = $(el).attr("href");
    if (!href) return;
    if (href.startsWith("#") || href.startsWith("javascript:")) return;
    $(el).attr("href", "javascript:void(0)");
    $(el).attr("data-proxy-href", href);
    $(el).attr("onclick", "");
  });

  $("form").each((_, el) => {
    $(el).removeAttr("onsubmit");
    $(el).removeAttr("target");
  });

  $("[src]").each((_, el) => {
    const src = $(el).attr("src");
    if (!src || src.startsWith("data:") || src.startsWith("blob:")) return;
    try {
      const abs = new URL(src, base).href;
      $(el).attr("src", abs);
    } catch {
      // ignore invalid urls
    }
  });

  $("link[href]").each((_, el) => {
    const href = $(el).attr("href");
    if (!href || href.startsWith("data:")) return;
    try {
      const abs = new URL(href, base).href;
      $(el).attr("href", abs);
    } catch {
      // ignore
    }
  });

  // Modern sites frequently use responsive image sources. Resolve those
  // URLs too so the proxied document does not render a wall of broken media.
  $("[srcset]").each((_, el) => {
    const srcset = $(el).attr("srcset");
    if (!srcset) return;
    const resolved = srcset.split(",").map(part => {
      const [src, ...descriptor] = part.trim().split(/\s+/);
      try { return [new URL(src, base).href, ...descriptor].join(" "); } catch { return part.trim(); }
    }).join(", ");
    $(el).attr("srcset", resolved);
  });

  $("script").remove();
  $("noscript").remove();

  // Inject our own handler script that intercepts navigation and forwards
  // it to the parent frame via postMessage.
  const handlerScript = `
(function(){
  function findAnchor(node){
    while(node && node !== document.body){
      if(node.dataset && node.dataset.proxyHref) return node;
      node = node.parentNode;
    }
    return null;
  }
  document.addEventListener('click', function(e){
    var a = findAnchor(e.target);
    if(!a) return;
    e.preventDefault(); e.stopPropagation();
    try{
      var abs = new URL(a.dataset.proxyHref, document.baseURI).href;
      parent.postMessage({type:'phoenix-navigate', url: abs}, '*');
    }catch(_){}
  }, true);
  document.addEventListener('submit', function(e){
    var f = e.target;
    if(!f || f.tagName !== 'FORM') return;
    e.preventDefault();
    try{
      var action = f.getAttribute('action') || document.baseURI;
      var url = new URL(action, document.baseURI);
      var qs = new URLSearchParams();
      var els = f.elements;
      for(var i=0;i<els.length;i++){
        var el = els[i];
        if(!el.name || el.disabled) continue;
        if((el.type==='checkbox'||el.type==='radio') && !el.checked) continue;
        if(el.type==='file' || el.type==='submit' || el.type==='button') continue;
        qs.append(el.name, el.value);
      }
      var finalUrl = url.origin + url.pathname + (qs.toString() ? '?' + qs.toString() : '');
      parent.postMessage({type:'phoenix-navigate', url: finalUrl}, '*');
    }catch(_){}
  }, true);
})();`;
  $("body").append(`<script>${handlerScript}</script>`);

  return $.html();
}

function extractTitle(html: string): string | undefined {
  const match = html.match(/<title[^>]*>([^<]*)<\/title>/i);
  return match ? match[1].trim() : undefined;
}

function extractFavicon(html: string, baseUrl: string): string | undefined {
  const $ = cheerio.load(html);
  const base = new URL(baseUrl);

  const iconLink = $('link[rel~="icon"], link[rel~="shortcut"]').first().attr("href");
  if (iconLink) {
    try {
      return new URL(iconLink, base).href;
    } catch {
      // ignore
    }
  }

  return `${base.origin}/favicon.ico`;
}

router.post("/proxy/fetch", async (req, res): Promise<void> => {
  const parsed = ProxyFetchBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  let rawUrl = parsed.data.url.trim();
  if (!/^https?:\/\//i.test(rawUrl)) {
    rawUrl = "https://" + rawUrl;
  }

  let targetUrl: URL;
  try {
    targetUrl = new URL(rawUrl);
  } catch {
    res.status(400).json({ error: "Invalid URL provided" });
    return;
  }

  try {
    const response = await fetch(targetUrl.href, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(15000),
    });

    const contentType = response.headers.get("content-type") ?? "text/html";
    const finalUrl = response.url || targetUrl.href;

    let html = "";
    let title: string | undefined;
    let favicon: string | undefined;

    if (contentType.includes("text/html")) {
      const rawHtml = await response.text();
      title = extractTitle(rawHtml);
      favicon = extractFavicon(rawHtml, finalUrl);
      html = rewriteHtml(rawHtml, finalUrl);
    } else {
      html = `<html><body style="font-family:sans-serif;padding:2rem;"><p>Content type: ${contentType}</p><p><a href="${finalUrl}" target="_blank">Open original</a></p></body></html>`;
    }

    const fetchedAt = new Date().toISOString();

    await db.insert(proxyHistoryTable).values({
      url: targetUrl.href,
      finalUrl,
      title: title ?? null,
      favicon: favicon ?? null,
    });

    const result = ProxyFetchResponse.parse({
      url: targetUrl.href,
      finalUrl,
      status: response.status,
      contentType,
      html,
      title,
      favicon,
      fetchedAt,
    });

    res.json(result);
  } catch (err: unknown) {
    req.log.error({ err, url: targetUrl.href }, "Proxy fetch failed");
    const message = err instanceof Error ? err.message : "Unknown error";
    res.status(500).json({ error: `Failed to fetch URL: ${message}`, url: targetUrl.href });
  }
});

router.get("/proxy/history", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(proxyHistoryTable)
    .orderBy(desc(proxyHistoryTable.visitedAt))
    .limit(50);

  const items = rows.map(r => ({
    ...r,
    visitedAt: r.visitedAt instanceof Date ? r.visitedAt.toISOString() : r.visitedAt,
  }));

  const result = GetProxyHistoryResponse.parse({ items });
  res.json(result);
});

router.delete("/proxy/history", async (_req, res): Promise<void> => {
  await db.delete(proxyHistoryTable);
  const result = ClearProxyHistoryResponse.parse({ success: true });
  res.json(result);
});

export default router;
