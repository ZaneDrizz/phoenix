import { Router } from "express";
import { spawn, type ChildProcessWithoutNullStreams } from "child_process";

const router = Router();

// HEAD /api/download — quick liveness check, no yt-dlp
router.head("/download", (req, res) => {
  const url = (req.query.url as string | undefined)?.trim();
  if (!url) { res.status(400).end(); return; }
  res.status(200).end();
});

// GET /api/download?url=...&title=...
// Streams the best available video quality directly to the browser as a download.
router.get("/download", (req, res) => {
  const url = (req.query.url as string | undefined)?.trim();
  const rawTitle = (req.query.title as string | undefined) || "video";

  if (!url) {
    res.status(400).json({ error: "url required" });
    return;
  }

  // Sanitise filename
  const safeName = rawTitle.replace(/[^\w\s.\-()[\]]/g, "").trim().slice(0, 120) || "video";

  req.log.info({ url }, "download requested");

  // First do a quick info probe so we can set a filename extension
  const probe: ChildProcessWithoutNullStreams = spawn("yt-dlp", [
    "-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/bestvideo+bestaudio/best",
    "--print", "%(ext)s",
    "--no-playlist",
    "--no-warnings",
    url,
  ]);

  let ext = "mp4";
  let extBuf = "";
  probe.stdout.on("data", (d: Buffer) => { extBuf += d.toString(); });

  probe.on("close", () => {
    ext = extBuf.trim().split("\n")[0] || "mp4";
    if (!ext || ext.length > 5) ext = "mp4";
    startDownload(ext);
  });

  probe.on("error", () => startDownload("mp4"));

  function startDownload(fileExt: string) {
    const filename = `${safeName}.${fileExt}`;

    // Detect if we need to merge (separate video+audio) — output via ffmpeg to fragmented mp4
    // so it can be piped without seeking
    const args: string[] = [
      "-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/bestvideo+bestaudio/best",
      "--no-playlist",
      "--no-warnings",
      "--merge-output-format", "mp4",
      // Use frag_keyframe+empty_moov so mp4 can be streamed without seeking
      "--postprocessor-args", "ffmpeg:-movflags frag_keyframe+empty_moov",
      "-o", "-",
      url as string,
    ];

    const proc: ChildProcessWithoutNullStreams = spawn("yt-dlp", args);

    res.setHeader("Content-Type", `video/${fileExt}`);
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("X-Content-Type-Options", "nosniff");

    let started = false;
    proc.stdout.on("data", (chunk: Buffer) => {
      if (!started) { started = true; }
      if (!res.writableEnded) res.write(chunk);
    });

    proc.stderr.on("data", (d: Buffer) => {
      req.log.debug({ output: d.toString().trim() }, "yt-dlp stderr");
    });

    proc.on("error", (err) => {
      req.log.error(err, "yt-dlp spawn error");
      if (!res.headersSent) {
        res.status(500).json({ error: "Download unavailable for this source" });
      } else if (!res.writableEnded) {
        res.end();
      }
    });

    proc.on("close", (code) => {
      if (code !== 0 && !started && !res.headersSent) {
        res.status(502).json({ error: "This source does not support direct download. Try 'Next source'." });
        return;
      }
      if (!res.writableEnded) res.end();
      req.log.info({ code, filename }, "download complete");
    });

    // If client disconnects, kill the yt-dlp process
    req.on("close", () => {
      if (!proc.killed) proc.kill("SIGTERM");
    });
  }
});

export default router;
