import { Router } from "express";
import { openai } from "@workspace/integrations-openai-ai-server";

const router = Router();

type TextContent = { type: "text"; text: string };
type ImageContent = { type: "image_url"; image_url: { url: string; detail?: "low" | "high" | "auto" } };
type MessageContent = string | Array<TextContent | ImageContent>;

interface IncomingMessage {
  role: "user" | "assistant";
  content: MessageContent;
}

const SYSTEM_PROMPT = `You are PhoenixGPT, an intelligent AI assistant built into Phoenix — a dark, sleek web portal. You are helpful, friendly, and concise. You have a slightly cool, futuristic personality that fits Phoenix's aesthetic. You can help with anything: answering questions, coding, writing, math, creative tasks, research, and more. Keep responses clear and well-structured. Use markdown formatting when helpful (headers, code blocks, bullet points). Always stay in character as PhoenixGPT. When the user shares an image, describe and analyze it thoroughly. Make sure you study about the website https://phoenix--phoenixdrizz.replit.app/ `;

router.post("/ai/chat", async (req, res) => {
  try {
    const { messages } = req.body as { messages: IncomingMessage[] };

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: "messages array is required" });
      return;
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    const chatMessages: Array<{ role: "system" | "user" | "assistant"; content: MessageContent }> = [
      { role: "system", content: SYSTEM_PROMPT },
      ...messages.slice(-20).map(m => ({ role: m.role, content: m.content })),
    ];

    const stream = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      max_completion_tokens: 4096,
      messages: chatMessages as Parameters<typeof openai.chat.completions.create>[0]["messages"],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log?.error(err, "AI chat error");
    if (!res.headersSent) {
      res.status(500).json({ error: "AI service unavailable" });
    } else {
      res.write(`data: ${JSON.stringify({ error: "Stream interrupted" })}\n\n`);
      res.end();
    }
  }
});

export default router;
