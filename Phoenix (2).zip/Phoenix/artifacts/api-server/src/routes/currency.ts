import { Router, type Request, type Response } from "express";
import { and, count, eq, gte, inArray, sql } from "drizzle-orm";
import { db, chatMessagesTable, questCompletionsTable, userInventoryTable, usersTable } from "@workspace/db";
import { getAccountId, isOwner } from "../lib/accounts";

const router = Router();
const DAILY_REWARD = 100;
const TODAY = () => new Date().toISOString().slice(0, 10);

const SHOP_ITEMS = [
  { id: "decoration:sparkles", type: "avatarDecoration", value: "sparkles", name: "Sparkles", description: "A soft pink shimmer", price: 100, emoji: "✦", color: "#f9a8d4" },
  { id: "decoration:hearts", type: "avatarDecoration", value: "hearts", name: "Hearts", description: "Wear your heart out", price: 140, emoji: "♥", color: "#fb7185" },
  { id: "decoration:flame", type: "avatarDecoration", value: "flame", name: "Flame", description: "A little extra heat", price: 180, emoji: "🔥", color: "#fb923c" },
  { id: "decoration:crown", type: "avatarDecoration", value: "crown", name: "Crown", description: "Royal Phoenix energy", price: 250, emoji: "♛", color: "#facc15" },
  { id: "decoration:halo", type: "avatarDecoration", value: "halo", name: "Halo", description: "A golden orbit", price: 300, emoji: "◌", color: "#fde68a" },
  { id: "decoration:diamond", type: "avatarDecoration", value: "diamond", name: "Diamond", description: "A cool cyan edge", price: 450, emoji: "◆", color: "#67e8f9" },
] as const;

const QUESTS = [
  { id: "say-hello", title: "Say hello", description: "Send a message in Global Chat today.", reward: 40, target: 1 },
  { id: "make-it-yours", title: "Make it yours", description: "Customize your profile with a name, bio, picture, or decoration.", reward: 60, target: 1 },
] as const;

async function getUser(req: Request, res: Response) {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Sign in to use AtBucks." });
    return null;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.token, auth.slice(7))).limit(1);
  if (!user) {
    res.status(401).json({ error: "Your session has expired. Sign in again." });
    return null;
  }
  return user;
}

async function getQuestProgress(user: typeof usersTable.$inferSelect, day: string) {
  const since = new Date(`${day}T00:00:00.000Z`);
  const [chatCount] = await db.select({ count: count() }).from(chatMessagesTable)
    .where(and(eq(chatMessagesTable.username, user.username), gte(chatMessagesTable.createdAt, since)));
  return {
    "say-hello": Math.min(Number(chatCount?.count ?? 0), 1),
    "make-it-yours": (user.displayName !== user.username || user.bio.trim().length > 0 || !!user.avatarUrl || user.avatarDecoration !== "none") ? 1 : 0,
  };
}

async function getState(user: typeof usersTable.$inferSelect) {
  const day = TODAY();
  const [ownedRows, completedRows, progress] = await Promise.all([
    db.select({ itemId: userInventoryTable.itemId }).from(userInventoryTable).where(eq(userInventoryTable.userId, user.id)),
    db.select({ questId: questCompletionsTable.questId }).from(questCompletionsTable).where(and(eq(questCompletionsTable.userId, user.id), eq(questCompletionsTable.completedOn, day))),
    getQuestProgress(user, day),
  ]);
  const owned = ownedRows.map(row => row.itemId);
  const completed = new Set(completedRows.map(row => row.questId));
  return {
    accountId: getAccountId(user.id),
    username: user.username,
    displayName: user.displayName || user.username,
    balance: user.atbucks,
    equippedDecoration: user.avatarDecoration,
    daily: { reward: DAILY_REWARD, claimed: user.lastDailyClaim === day },
    inventory: owned,
    shop: SHOP_ITEMS,
    quests: QUESTS.map(quest => ({ ...quest, progress: progress[quest.id], completed: completed.has(quest.id) })),
    isAdmin: isOwner(user.username),
  };
}

router.get("/currency", async (req, res) => {
  const user = await getUser(req, res);
  if (!user) return;
  res.json(await getState(user));
});

router.post("/currency/daily", async (req, res) => {
  const user = await getUser(req, res);
  if (!user) return;
  const day = TODAY();
  if (user.lastDailyClaim === day) {
    res.status(409).json({ error: "Your daily AtBucks are already claimed.", balance: user.atbucks });
    return;
  }
  const [updated] = await db.update(usersTable)
    .set({ atbucks: sql`${usersTable.atbucks} + ${DAILY_REWARD}`, lastDailyClaim: day })
    .where(eq(usersTable.id, user.id))
    .returning({ balance: usersTable.atbucks });
  res.json({ balance: updated.balance, reward: DAILY_REWARD });
});

router.post("/currency/quests/claim", async (req, res) => {
  const user = await getUser(req, res);
  if (!user) return;
  const questId = typeof req.body?.questId === "string" ? req.body.questId : "";
  const quest = QUESTS.find(item => item.id === questId);
  if (!quest) {
    res.status(400).json({ error: "That quest does not exist." });
    return;
  }
  const day = TODAY();
  const progress = await getQuestProgress(user, day);
  if (progress[quest.id] < quest.target) {
    res.status(400).json({ error: quest.id === "say-hello" ? "Send a message in Global Chat first." : "Customize your profile first." });
    return;
  }
  try {
    let balance = user.atbucks;
    await db.transaction(async tx => {
      const [existing] = await tx.select({ id: questCompletionsTable.id }).from(questCompletionsTable).where(and(
        eq(questCompletionsTable.userId, user.id),
        eq(questCompletionsTable.questId, quest.id),
        eq(questCompletionsTable.completedOn, day),
      )).limit(1);
      if (existing) throw new Error("already-completed");
      await tx.insert(questCompletionsTable).values({ userId: user.id, questId: quest.id, completedOn: day });
      const [updated] = await tx.update(usersTable)
        .set({ atbucks: sql`${usersTable.atbucks} + ${quest.reward}` })
        .where(eq(usersTable.id, user.id))
        .returning({ balance: usersTable.atbucks });
      balance = updated.balance;
    });
    res.json({ balance, reward: quest.reward, questId: quest.id });
  } catch (error) {
    if (error instanceof Error && error.message === "already-completed") {
      res.status(409).json({ error: "That quest is already complete today." });
      return;
    }
    throw error;
  }
});

router.post("/currency/shop/purchase", async (req, res) => {
  const user = await getUser(req, res);
  if (!user) return;
  const itemId = typeof req.body?.itemId === "string" ? req.body.itemId : "";
  const item = SHOP_ITEMS.find(candidate => candidate.id === itemId);
  if (!item) {
    res.status(400).json({ error: "That shop item does not exist." });
    return;
  }
  try {
    let balance = user.atbucks;
    await db.transaction(async tx => {
      const [owned] = await tx.select({ id: userInventoryTable.id }).from(userInventoryTable).where(and(
        eq(userInventoryTable.userId, user.id),
        eq(userInventoryTable.itemId, item.id),
      )).limit(1);
      if (owned) throw new Error("already-owned");
      const [updated] = await tx.update(usersTable)
        .set({ atbucks: sql`${usersTable.atbucks} - ${item.price}` })
        .where(and(eq(usersTable.id, user.id), gte(usersTable.atbucks, item.price)))
        .returning({ balance: usersTable.atbucks });
      if (!updated) throw new Error("not-enough");
      await tx.insert(userInventoryTable).values({ userId: user.id, itemId: item.id });
      balance = updated.balance;
    });
    res.json({ balance, itemId: item.id });
  } catch (error) {
    if (error instanceof Error && error.message === "already-owned") {
      res.status(409).json({ error: "You already own that item." });
      return;
    }
    if (error instanceof Error && error.message === "not-enough") {
      res.status(400).json({ error: "You do not have enough AtBucks." });
      return;
    }
    throw error;
  }
});

router.post("/currency/shop/equip", async (req, res) => {
  const user = await getUser(req, res);
  if (!user) return;
  const itemId = typeof req.body?.itemId === "string" ? req.body.itemId : "";
  if (itemId === "none") {
    await db.update(usersTable).set({ avatarDecoration: "none" }).where(eq(usersTable.id, user.id));
    res.json({ equippedDecoration: "none" });
    return;
  }
  const item = SHOP_ITEMS.find(candidate => candidate.id === itemId);
  if (!item) {
    res.status(400).json({ error: "That shop item does not exist." });
    return;
  }
  const [owned] = await db.select({ id: userInventoryTable.id }).from(userInventoryTable).where(and(
    eq(userInventoryTable.userId, user.id),
    eq(userInventoryTable.itemId, item.id),
  )).limit(1);
  if (!owned) {
    res.status(403).json({ error: "Buy this decoration before equipping it." });
    return;
  }
  await db.update(usersTable).set({ avatarDecoration: item.value }).where(eq(usersTable.id, user.id));
  res.json({ equippedDecoration: item.value });
});

router.post("/currency/admin/grant", async (req, res) => {
  const user = await getUser(req, res);
  if (!user) return;
  if (!isOwner(user.username)) {
    res.status(403).json({ error: "Owner tools are only available to Phoenix and PhoenixDrizz." });
    return;
  }
  const amount = Number(req.body?.amount);
  if (!Number.isInteger(amount) || amount < 1 || amount > 100_000) {
    res.status(400).json({ error: "Grant an integer amount from 1 to 100,000." });
    return;
  }
  const [updated] = await db.update(usersTable)
    .set({ atbucks: sql`${usersTable.atbucks} + ${amount}` })
    .where(eq(usersTable.id, user.id))
    .returning({ balance: usersTable.atbucks });
  res.json({ balance: updated.balance, reward: amount });
});

router.get("/currency/admin/users", async (req, res) => {
  const user = await getUser(req, res);
  if (!user) return;
  if (!isOwner(user.username)) {
    res.status(403).json({ error: "Owner tools are only available to Phoenix and PhoenixDrizz." });
    return;
  }
  const users = await db.select({
    id: usersTable.id,
    accountId: usersTable.id,
    username: usersTable.username,
    displayName: usersTable.displayName,
  }).from(usersTable).orderBy(usersTable.username);
  res.json({ users: users.map(candidate => ({ ...candidate, accountId: getAccountId(candidate.id) })) });
});

router.post("/currency/admin/modgive", async (req, res) => {
  const owner = await getUser(req, res);
  if (!owner) return;
  if (!isOwner(owner.username)) {
    res.status(403).json({ error: "Owner tools are only available to Phoenix and PhoenixDrizz." });
    return;
  }
  const rawIds: unknown[] = Array.isArray(req.body?.userIds) ? req.body.userIds as unknown[] : [];
  const validIds = rawIds.reduce<number[]>((ids, id) => {
    if (typeof id === "number" && Number.isInteger(id) && id > 0) ids.push(id);
    return ids;
  }, []);
  const userIds = Array.from(new Set(validIds)).slice(0, 50);
  const amount = Number(req.body?.amount);
  if (!userIds.length) {
    res.status(400).json({ error: "Pick at least one user." });
    return;
  }
  if (!Number.isInteger(amount) || amount < 1 || amount > 100_000) {
    res.status(400).json({ error: "Grant an integer amount from 1 to 100,000." });
    return;
  }
  const updated = await db.update(usersTable)
    .set({ atbucks: sql`${usersTable.atbucks} + ${amount}` })
    .where(inArray(usersTable.id, userIds))
    .returning({ id: usersTable.id, username: usersTable.username, balance: usersTable.atbucks });
  res.json({ reward: amount, users: updated.map(candidate => ({ ...candidate, accountId: getAccountId(candidate.id) })) });
});

export default router;