import { Router, type IRouter } from "express";

const router: IRouter = Router();

const JIKAN = "https://api.jikan.moe/v4";

type AnyRec = Record<string, unknown>;

async function jikan(path: string, query: Record<string, string | number> = {}): Promise<AnyRec> {
  const url = new URL(JIKAN + path);
  for (const [k, v] of Object.entries(query)) url.searchParams.set(k, String(v));
  const r = await fetch(url.toString(), { signal: AbortSignal.timeout(12000) });
  if (!r.ok) throw new Error(`jikan ${r.status}`);
  return (await r.json()) as AnyRec;
}

interface AnimeItem {
  mal_id: number;
  title: string;
  title_english: string | null;
  poster: string | null;
  backdrop: string | null;
  year: string;
  rating: number;
  overview: string;
  episodes: number | null;
  kind: "anime";
  status: string;
}

function mapAnime(a: AnyRec): AnimeItem {
  const images = (a.images as AnyRec | undefined)?.jpg as AnyRec | undefined;
  const trailer = (a.trailer as AnyRec | undefined);
  return {
    mal_id: a.mal_id as number,
    title: ((a.title_english as string) || (a.title as string) || "Untitled").trim(),
    title_english: (a.title_english as string | null) || null,
    poster: (images?.large_image_url as string) || (images?.image_url as string) || null,
    backdrop: (trailer?.images as AnyRec | undefined)?.maximum_image_url as string | null || null,
    year: a.year ? String(a.year) : String(((((a.aired as AnyRec)?.prop) as AnyRec)?.from as AnyRec)?.year || ""),
    rating: Math.round(((a.score as number) || 0) * 10) / 10,
    overview: (a.synopsis as string) || "",
    episodes: (a.episodes as number | null) || null,
    kind: "anime",
    status: (a.status as string) || "",
  };
}

// Trending (Top airing)
router.get("/anime/trending", async (req, res) => {
  try {
    const data = await jikan("/top/anime", { filter: "airing", limit: 25 });
    res.json({ results: ((data.data as AnyRec[]) || []).map(mapAnime) });
  } catch (err) {
    req.log.error(err, "anime trending");
    res.status(500).json({ error: "Failed to fetch trending anime" });
  }
});

// Seasonal (currently airing)
router.get("/anime/seasonal", async (req, res) => {
  try {
    const data = await jikan("/seasons/now", { limit: 25 });
    res.json({ results: ((data.data as AnyRec[]) || []).map(mapAnime) });
  } catch (err) {
    req.log.error(err, "anime seasonal");
    res.status(500).json({ error: "Failed to fetch seasonal anime" });
  }
});

// Popular all time
router.get("/anime/popular", async (req, res) => {
  try {
    const data = await jikan("/top/anime", { filter: "bypopularity", limit: 25 });
    res.json({ results: ((data.data as AnyRec[]) || []).map(mapAnime) });
  } catch (err) {
    req.log.error(err, "anime popular");
    res.status(500).json({ error: "Failed to fetch popular anime" });
  }
});

// Top rated
router.get("/anime/top", async (req, res) => {
  try {
    const data = await jikan("/top/anime", { limit: 25 });
    res.json({ results: ((data.data as AnyRec[]) || []).map(mapAnime) });
  } catch (err) {
    req.log.error(err, "anime top");
    res.status(500).json({ error: "Failed to fetch top anime" });
  }
});

// Search
router.get("/anime/search", async (req, res) => {
  const q = (req.query.q as string | undefined)?.trim() || "";
  if (!q) { res.json({ results: [] }); return; }
  try {
    const data = await jikan("/anime", { q, limit: 24, sfw: 1 });
    res.json({ results: ((data.data as AnyRec[]) || []).map(mapAnime) });
  } catch (err) {
    req.log.error(err, "anime search");
    res.status(500).json({ error: "Search failed" });
  }
});

// Details + episodes
router.get("/anime/details/:malId", async (req, res) => {
  const malId = Number(req.params.malId);
  if (!malId) { res.status(400).json({ error: "Invalid MAL ID" }); return; }
  try {
    const [detailData, epsData] = await Promise.all([
      jikan(`/anime/${malId}`),
      jikan(`/anime/${malId}/episodes`, { limit: 100 }),
    ]);
    const item = mapAnime((detailData.data as AnyRec) || {});
    const episodes = ((epsData.data as AnyRec[]) || []).map((ep: AnyRec) => ({
      number: ep.episode as number,
      title: (ep.title as string) || `Episode ${ep.episode}`,
      aired: (ep.aired as string) || null,
    }));
    res.json({ item, episodes });
  } catch (err) {
    req.log.error(err, "anime details");
    res.status(500).json({ error: "Failed to fetch anime details" });
  }
});

export default router;
