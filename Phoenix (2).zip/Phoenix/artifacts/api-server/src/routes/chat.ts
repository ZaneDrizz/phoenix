import { Router, type Request, type Response, type NextFunction } from "express";
import { db, chatMessagesTable, usersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const token = auth.slice(7);
  const [user] = await db.select({ id: usersTable.id, username: usersTable.username }).from(usersTable).where(eq(usersTable.token, token)).limit(1);
  if (!user) {
    res.status(401).json({ error: "Invalid token" });
    return;
  }
  (req as Request & { user: { id: number; username: string } }).user = user;
  next();
}

router.get("/chat/messages", requireAuth, async (req: Request, res: Response) => {
  const rows = await db
    .select({ id: chatMessagesTable.id, username: chatMessagesTable.username, displayName: usersTable.displayName, content: chatMessagesTable.content, createdAt: chatMessagesTable.createdAt, avatarUrl: usersTable.avatarUrl, avatarDecoration: usersTable.avatarDecoration })
    .from(chatMessagesTable)
    .leftJoin(usersTable, eq(chatMessagesTable.username, usersTable.username))
    .orderBy(desc(chatMessagesTable.createdAt))
    .limit(80);
  res.json({ messages: rows.reverse() });
});

router.post("/chat/message", requireAuth, async (req: Request, res: Response) => {
  const { content } = req.body as { content?: string };
  if (!content?.trim()) {
    res.status(400).json({ error: "Message cannot be empty" });
    return;
  }
  const isFile = content.trim().startsWith("[FILE ");
  if ((!isFile && content.trim().length > 500) || content.length > 8 * 1024 * 1024) {
    res.status(400).json({ error: isFile ? "File is too large (max 6 MB)" : "Message too long (max 500 chars)" });
    return;
  }
  const username = (req as Request & { user: { username: string } }).user.username;
  const [msg] = await db.insert(chatMessagesTable).values({ username, content: content.trim() }).returning();
  const [profile] = await db.select({ avatarUrl: usersTable.avatarUrl, displayName: usersTable.displayName, avatarDecoration: usersTable.avatarDecoration }).from(usersTable).where(eq(usersTable.username, username)).limit(1);
  res.json({ message: { ...msg, avatarUrl: profile?.avatarUrl ?? null, displayName: profile?.displayName ?? username, avatarDecoration: profile?.avatarDecoration ?? "none" } });
});

export default router;
