import { Router, type IRouter } from "express";
import healthRouter from "./health";
import proxyRouter from "./proxy";
import moviesRouter from "./movies";
import authRouter from "./auth";
import chatRouter from "./chat";
import aiRouter from "./ai";
import animeRouter from "./anime";
import downloadRouter from "./download";
import currencyRouter from "./currency";

const router: IRouter = Router();

router.use(healthRouter);
router.use(proxyRouter);
router.use(moviesRouter);
router.use(authRouter);
router.use(chatRouter);
router.use(aiRouter);
router.use(animeRouter);
router.use(downloadRouter);
router.use(currencyRouter);

export default router;
