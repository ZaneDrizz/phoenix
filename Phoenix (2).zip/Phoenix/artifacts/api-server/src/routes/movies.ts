import { Router, type IRouter } from "express";

const router: IRouter = Router();

const TMDB_KEY = process.env.TMDB_API_KEY || "8265bd1679663a7ea12ac168da84d2e8";
const TMDB = "https://api.themoviedb.org/3";

type AnyRec = Record<string, unknown>;

async function tmdb(path: string, query: Record<string, string | number | undefined> = {}): Promise<AnyRec> {
  const url = new URL(TMDB + path);
  url.searchParams.set("api_key", TMDB_KEY);
  url.searchParams.set("language", "en-US");
  for (const [k, v] of Object.entries(query)) {
    if (v !== undefined && v !== "") url.searchParams.set(k, String(v));
  }
  const r = await fetch(url.toString(), { signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error(`tmdb ${r.status}`);
  return (await r.json()) as AnyRec;
}

interface MediaItem {
  id: number;
  imdb_id?: string | null;
  title: string;
  poster: string | null;
  backdrop: string | null;
  year: string;
  rating: number;
  overview: string;
  kind: "movie" | "tv";
}

function mapMovie(m: AnyRec): MediaItem {
  const posterPath = (m.poster_path as string | null) || null;
  const backdropPath = (m.backdrop_path as string | null) || null;
  const date = (m.release_date as string) || "";
  return {
    id: m.id as number,
    title: ((m.title as string) || (m.name as string) || "Untitled").trim(),
    poster: posterPath ? `https://image.tmdb.org/t/p/w500${posterPath}` : null,
    backdrop: backdropPath ? `https://image.tmdb.org/t/p/w1280${backdropPath}` : null,
    year: date ? date.slice(0, 4) : "",
    rating: Math.round(((m.vote_average as number) || 0) * 10) / 10,
    overview: (m.overview as string) || "",
    kind: "movie",
  };
}

function mapTv(m: AnyRec): MediaItem {
  const posterPath = (m.poster_path as string | null) || null;
  const backdropPath = (m.backdrop_path as string | null) || null;
  const date = (m.first_air_date as string) || "";
  return {
    id: m.id as number,
    title: ((m.name as string) || (m.title as string) || "Untitled").trim(),
    poster: posterPath ? `https://image.tmdb.org/t/p/w500${posterPath}` : null,
    backdrop: backdropPath ? `https://image.tmdb.org/t/p/w1280${backdropPath}` : null,
    year: date ? date.slice(0, 4) : "",
    rating: Math.round(((m.vote_average as number) || 0) * 10) / 10,
    overview: (m.overview as string) || "",
    kind: "tv",
  };
}

router.get("/movies/discover", async (req, res) => {
  try {
    const cat = String(req.query.cat || "popular");
    const page = Number(req.query.page || 1);
    const allowed = new Set(["popular", "top_rated", "now_playing", "upcoming"]);
    const c = allowed.has(cat) ? cat : "popular";
    const data = await tmdb(`/movie/${c}`, { page });
    const results = ((data.results as AnyRec[]) || []).map(mapMovie);
    res.json({ results, page: data.page, total_pages: data.total_pages });
  } catch (e) {
    req.log.error({ err: e }, "movies discover failed");
    res.status(500).json({ error: "discover failed" });
  }
});

router.get("/movies/trending", async (req, res) => {
  try {
    const win = String(req.query.window || "week");
    const w = win === "day" ? "day" : "week";
    const data = await tmdb(`/trending/movie/${w}`);
    const results = ((data.results as AnyRec[]) || []).map(mapMovie);
    res.json({ results });
  } catch (e) {
    req.log.error({ err: e }, "trending movies failed");
    res.status(500).json({ error: "trending failed" });
  }
});

router.get("/movies/genre/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const page = Number(req.query.page || 1);
    const data = await tmdb(`/discover/movie`, {
      with_genres: id,
      page,
      sort_by: "popularity.desc",
    });
    const results = ((data.results as AnyRec[]) || []).map(mapMovie);
    res.json({ results, page: data.page, total_pages: data.total_pages });
  } catch (e) {
    req.log.error({ err: e }, "genre failed");
    res.status(500).json({ error: "genre failed" });
  }
});

router.get("/movies/genres", async (_req, res) => {
  try {
    const data = await tmdb(`/genre/movie/list`);
    res.json({ genres: data.genres || [] });
  } catch {
    res.status(500).json({ error: "genres failed" });
  }
});

router.get("/movies/search", async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    if (!q) { res.json({ results: [] }); return; }
    const [movies, tv] = await Promise.all([
      tmdb(`/search/movie`, { query: q, include_adult: "false" }),
      tmdb(`/search/tv`, { query: q, include_adult: "false" }),
    ]);
    const m = ((movies.results as AnyRec[]) || []).map(mapMovie);
    const t = ((tv.results as AnyRec[]) || []).map(mapTv);
    const merged = [...m, ...t]
      .filter((x) => x.poster)
      .sort((a, b) => b.rating - a.rating);
    res.json({ results: merged });
  } catch (e) {
    req.log.error({ err: e }, "search failed");
    res.status(500).json({ error: "search failed" });
  }
});

router.get("/movies/details/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const data = await tmdb(`/movie/${id}`, { append_to_response: "external_ids,videos,credits,recommendations" });
    const item = mapMovie(data);
    item.imdb_id = ((data.external_ids as AnyRec | undefined)?.imdb_id as string) || null;
    const recsData = (data.recommendations as AnyRec | undefined)?.results as AnyRec[] | undefined;
    const recs = (recsData || []).map(mapMovie).filter((x) => x.poster);
    res.json({ item, recommendations: recs });
  } catch (e) {
    req.log.error({ err: e }, "details failed");
    res.status(500).json({ error: "details failed" });
  }
});

router.get("/tv/discover", async (req, res) => {
  try {
    const cat = String(req.query.cat || "popular");
    const page = Number(req.query.page || 1);
    const allowed = new Set(["popular", "top_rated", "on_the_air", "airing_today"]);
    const c = allowed.has(cat) ? cat : "popular";
    const data = await tmdb(`/tv/${c}`, { page });
    const results = ((data.results as AnyRec[]) || []).map(mapTv);
    res.json({ results, page: data.page, total_pages: data.total_pages });
  } catch (e) {
    req.log.error({ err: e }, "tv discover failed");
    res.status(500).json({ error: "tv discover failed" });
  }
});

router.get("/tv/details/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const data = await tmdb(`/tv/${id}`, { append_to_response: "external_ids,recommendations" });
    const item = mapTv(data);
    item.imdb_id = ((data.external_ids as AnyRec | undefined)?.imdb_id as string) || null;
    const seasons = ((data.seasons as AnyRec[]) || [])
      .filter((s) => (s.season_number as number) > 0)
      .map((s) => ({
        season_number: s.season_number as number,
        name: s.name as string,
        episode_count: s.episode_count as number,
        poster: s.poster_path ? `https://image.tmdb.org/t/p/w300${s.poster_path}` : null,
      }));
    const recsData = (data.recommendations as AnyRec | undefined)?.results as AnyRec[] | undefined;
    const recs = (recsData || []).map(mapTv).filter((x) => x.poster);
    res.json({ item, seasons, recommendations: recs });
  } catch (e) {
    req.log.error({ err: e }, "tv details failed");
    res.status(500).json({ error: "tv details failed" });
  }
});

router.get("/tv/season/:id/:season", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const season = Number(req.params.season);
    const data = await tmdb(`/tv/${id}/season/${season}`);
    const episodes = ((data.episodes as AnyRec[]) || []).map((e) => ({
      episode_number: e.episode_number as number,
      name: e.name as string,
      overview: e.overview as string,
      still: e.still_path ? `https://image.tmdb.org/t/p/w300${e.still_path}` : null,
      runtime: e.runtime as number | null,
      air_date: e.air_date as string | null,
    }));
    res.json({ episodes });
  } catch (e) {
    req.log.error({ err: e }, "season failed");
    res.status(500).json({ error: "season failed" });
  }
});

export default router;
