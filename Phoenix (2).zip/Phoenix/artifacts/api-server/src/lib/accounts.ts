export const OWNER_USERNAMES = new Set(["phoenix", "phoenixdrizz"]);

export function isOwner(username: string) {
  return OWNER_USERNAMES.has(username.trim().toLowerCase());
}

export function getAccountId(userId: number) {
  return `PX-${userId.toString(36).toUpperCase().padStart(6, "0")}`;
}