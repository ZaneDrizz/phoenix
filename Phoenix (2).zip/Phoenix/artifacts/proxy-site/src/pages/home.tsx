import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import {
  Globe, Lock, History, Trash2, AlertCircle, RefreshCw, X,
  EyeOff, Search,
  Star, ExternalLink, Bookmark as BookmarkIcon, Zap, LogIn, UserPlus, Eye, EyeOff as EyeOffIcon,
  Clock, Keyboard, StickyNote, CheckSquare, Shuffle, Timer, Calculator, Cloud, Wind, Droplets,
  ChevronRight, ChevronLeft, Plus, Minus, Delete, Equal, ArrowUp, ArrowDown,
  Command as CommandIcon,
  Compass, Library, Activity, Heart, Coins
} from "lucide-react";
import BootScreen from "../components/boot-screen";
import {
  HomeIcon2, GamesIcon, MoviesIcon, TVIcon, AnimeIcon, MusicIcon2,
  AIIcon, AppsIcon, HTMLIcon, ChatIcon, SettingsIcon2, IncognitoIcon,
} from "../components/app-icons";
import { toggleGameFavorite, isGameFavorite, getGameFavorites, addToRecentGames, getRecentGames, type GameEntry } from "../lib/gameprefs";

import {
  useProxyFetch,
  useGetProxyHistory,
  getGetProxyHistoryQueryKey,
  useClearProxyHistory,
  useHealthCheck,
  getHealthCheckQueryKey
} from "@workspace/api-client-react";
interface ProxyFetchResult { url: string; finalUrl: string; status: number; contentType: string; html: string; title?: string; favicon?: string; fetchedAt: string; }
import { GAMES, GENRES } from "../data/games";
import MoviesView from "../components/movies-view";
import ChatView from "../components/chat-view";
import PhoenixGPT from "../components/phoenix-gpt";
import AnimeView from "../components/anime-view";
import MusicView from "../components/music-view";
import HtmlView from "../components/html-view";
import WelcomeWizard from "../components/welcome-wizard";
import WorkspaceView from "../components/workspace-view";
import CurrencyView from "../components/currency-view";

const API_BASE = `${import.meta.env.BASE_URL || "/"}api`.replace("//api", "/api");

/* ─── Theme definitions ──────────────────────────────────── */
type ThemeKey =
  | "default" | "forest" | "crimson" | "lavendar"
  | "monochrome" | "midnight" | "sunset" | "ocean"
  | "aurora" | "sakura" | "cyberpunk" | "galaxy"
  | "matrix" | "volcano" | "vaporwave" | "mint"
  | "rose" | "nebula" | "arctic" | "toxic"
  | "twilight" | "amber"
  | "neon" | "blood" | "sapphire" | "jade" | "copper" | "abyss"
  | "lava" | "petal" | "storm" | "coral" | "obsidian" | "prism"
  | "dusk" | "ultraviolet" | "terra" | "carnival" | "hollow"
  | "phoenix" | "marble" | "deepspace" | "noire" | "gold"
  // Yuki OS-inspired themes
  | "tokyo-night" | "catppuccin" | "dracula" | "oled" | "nordic"
  | "crt" | "gameboy" | "frutiger" | "nier" | "eva01" | "eva02"
  | "y2k" | "aura-dark" | "miku" | "solarized" | "high-contrast"
  | "sepia" | "starwars" | "windows-xp" | "synthwave"
  | "gruvbox" | "monokai" | "hackerblue" | "outrun" | "rosepine"
  | "material" | "onedark" | "cobalt" | "snes" | "horizon"
  | "ember" | "lavender-mist" | "deep-ocean" | "terminal" | "paper" | "plasma";
type ParticleType = "twinkle" | "ember" | "bubble" | "firefly" | "drift" | "snow" | "rain" | "shooting";

interface ThemeDef {
  name: string;
  bg: string;
  accent: string;
  glow: string;
  particle: ParticleType;
  particleColor: string;
}

const THEMES: Record<ThemeKey, ThemeDef> = {
  default: {
    name: "Default",
    bg: "radial-gradient(ellipse 80% 60% at 50% 30%, #3a0028 0%, #1a0014 30%, #0a0008 65%, #000000 100%)",
    accent: "#ff4ecd", glow: "rgba(255,78,205,0.5)",
    particle: "twinkle", particleColor: "255,180,240",
  },
  forest: {
    name: "Forest",
    bg: "radial-gradient(ellipse 110% 80% at 50% 100%, #1a4020 0%, #0a2410 25%, #061a0c 55%, #020a04 100%)",
    accent: "#4ade80", glow: "rgba(74,222,128,0.45)",
    particle: "firefly", particleColor: "170,255,140",
  },
  crimson: {
    name: "Crimson",
    bg: "radial-gradient(ellipse 95% 75% at 50% 105%, #a00a14 0%, #5a060a 18%, #2c0306 45%, #100204 70%, #050001 100%)",
    accent: "#ef4444", glow: "rgba(255,80,60,0.6)",
    particle: "ember", particleColor: "255,170,60",
  },
  lavendar: {
    name: "Lavendar",
    bg: "radial-gradient(ellipse 85% 70% at 50% 35%, #4a2a8c 0%, #2a1660 25%, #140a32 55%, #070418 80%, #02010a 100%)",
    accent: "#c084fc", glow: "rgba(192,132,252,0.45)",
    particle: "drift", particleColor: "230,200,255",
  },
  monochrome: {
    name: "Monochrome",
    bg: "radial-gradient(ellipse at 50% 30%, #2a2a2a 0%, #161616 45%, #080808 75%, #020202 100%)",
    accent: "#f4f4f4", glow: "rgba(244,244,244,0.22)",
    particle: "snow", particleColor: "255,255,255",
  },
  midnight: {
    name: "Midnight",
    bg: "radial-gradient(ellipse 100% 80% at 50% -10%, #0e1a6a 0%, #050a32 30%, #02041a 60%, #000004 100%)",
    accent: "#60a5fa", glow: "rgba(96,165,250,0.5)",
    particle: "twinkle", particleColor: "220,235,255",
  },
  sunset: {
    name: "Sunset",
    bg: "linear-gradient(180deg, #1c0440 0%, #5e1660 18%, #b02a52 35%, #e85a28 50%, #f08a30 60%, #6a1808 78%, #1a0402 92%, #050001 100%)",
    accent: "#fb923c", glow: "rgba(251,146,60,0.55)",
    particle: "drift", particleColor: "255,200,140",
  },
  ocean: {
    name: "Ocean",
    bg: "linear-gradient(180deg, #0a3478 0%, #062260 25%, #04183a 55%, #02091e 80%, #00040c 100%)",
    accent: "#22d3ee", glow: "rgba(34,211,238,0.45)",
    particle: "bubble", particleColor: "150,225,255",
  },
  aurora: {
    name: "Aurora",
    bg: "linear-gradient(180deg, #020618 0%, #0a3060 18%, #0a5a5a 35%, #185838 52%, #1a3060 70%, #0a1830 85%, #02050e 100%)",
    accent: "#5eead4", glow: "rgba(94,234,212,0.5)",
    particle: "firefly", particleColor: "140,255,210",
  },
  sakura: {
    name: "Sakura",
    bg: "linear-gradient(180deg, #3a0a2c 0%, #5a1840 30%, #2a0820 65%, #100410 90%, #04010a 100%)",
    accent: "#f9a8d4", glow: "rgba(249,168,212,0.5)",
    particle: "snow", particleColor: "255,190,225",
  },
  cyberpunk: {
    name: "Cyberpunk",
    bg: "linear-gradient(135deg, #2a004c 0%, #4a0a5a 22%, #6a0a4a 38%, #1a1060 60%, #061030 80%, #02020c 100%)",
    accent: "#ec4899", glow: "rgba(236,72,153,0.5)",
    particle: "bubble", particleColor: "240,80,200",
  },
  galaxy: {
    name: "Galaxy",
    bg: "radial-gradient(ellipse 80% 70% at 35% 40%, #4a1670 0%, #2a0c50 22%, #150528 50%, #060114 80%, #000004 100%)",
    accent: "#a78bfa", glow: "rgba(167,139,250,0.5)",
    particle: "twinkle", particleColor: "230,200,255",
  },
  matrix: {
    name: "Matrix",
    bg: "linear-gradient(180deg, #021004 0%, #010a02 50%, #000400 100%)",
    accent: "#22c55e", glow: "rgba(34,197,94,0.5)",
    particle: "rain", particleColor: "60,255,100",
  },
  volcano: {
    name: "Volcano",
    bg: "radial-gradient(ellipse 110% 85% at 50% 115%, #ea580c 0%, #c2410c 12%, #7c2d12 28%, #3a0a06 50%, #150302 78%, #050001 100%)",
    accent: "#fb923c", glow: "rgba(251,146,60,0.6)",
    particle: "ember", particleColor: "255,200,80",
  },
  vaporwave: {
    name: "Vaporwave",
    bg: "linear-gradient(180deg, #2a0c5a 0%, #4a0e7a 20%, #8a2096 40%, #d836a0 55%, #4ac6e0 75%, #1a4a9a 90%, #050a2c 100%)",
    accent: "#f472b6", glow: "rgba(244,114,182,0.5)",
    particle: "drift", particleColor: "255,180,230",
  },
  mint: {
    name: "Mint",
    bg: "radial-gradient(ellipse at 50% 35%, #0e4a44 0%, #082e30 35%, #04181a 70%, #010a0c 100%)",
    accent: "#6ee7b7", glow: "rgba(110,231,183,0.45)",
    particle: "snow", particleColor: "180,255,220",
  },
  rose: {
    name: "Rosé",
    bg: "radial-gradient(ellipse 90% 75% at 50% 100%, #c2185b 0%, #6a1238 22%, #3a0820 50%, #14040e 80%, #050104 100%)",
    accent: "#fda4af", glow: "rgba(253,164,175,0.5)",
    particle: "drift", particleColor: "255,200,200",
  },
  nebula: {
    name: "Nebula",
    bg: "radial-gradient(ellipse 70% 60% at 30% 35%, #6a1466 0%, #2a0850 25%, #150828 55%, #050010 100%), radial-gradient(ellipse 60% 50% at 80% 70%, #1a4a8a 0%, transparent 60%)",
    accent: "#d946ef", glow: "rgba(217,70,239,0.5)",
    particle: "twinkle", particleColor: "255,200,255",
  },
  arctic: {
    name: "Arctic",
    bg: "linear-gradient(180deg, #1a4a7a 0%, #103060 30%, #08203a 60%, #03101e 85%, #00060e 100%)",
    accent: "#bae6fd", glow: "rgba(186,230,253,0.5)",
    particle: "snow", particleColor: "230,245,255",
  },
  toxic: {
    name: "Toxic",
    bg: "radial-gradient(ellipse 90% 80% at 50% 105%, #84cc16 0%, #4a6a08 18%, #2a3a04 45%, #0c1402 75%, #020600 100%)",
    accent: "#a3e635", glow: "rgba(163,230,53,0.55)",
    particle: "bubble", particleColor: "180,255,80",
  },
  twilight: {
    name: "Twilight",
    bg: "linear-gradient(180deg, #1a0838 0%, #3a0a5a 22%, #6a185a 42%, #c63868 58%, #e8784a 75%, #4a0c3a 90%, #08020e 100%)",
    accent: "#fb7185", glow: "rgba(251,113,133,0.5)",
    particle: "drift", particleColor: "255,180,180",
  },
  amber: {
    name: "Amber",
    bg: "radial-gradient(ellipse 95% 75% at 50% 100%, #d97706 0%, #92400e 20%, #4a2008 45%, #200a02 75%, #060201 100%)",
    accent: "#fbbf24", glow: "rgba(251,191,36,0.55)",
    particle: "ember", particleColor: "255,210,100",
  },
  neon: {
    name: "Neon",
    bg: "linear-gradient(135deg, #000000 0%, #050a10 40%, #010612 70%, #000000 100%)",
    accent: "#00ffe7", glow: "rgba(0,255,231,0.6)",
    particle: "rain", particleColor: "0,255,200",
  },
  blood: {
    name: "Blood",
    bg: "radial-gradient(ellipse 100% 80% at 50% 120%, #700000 0%, #3a0000 18%, #1c0000 40%, #0a0000 70%, #030000 100%)",
    accent: "#dc2626", glow: "rgba(220,38,38,0.65)",
    particle: "ember", particleColor: "255,80,80",
  },
  sapphire: {
    name: "Sapphire",
    bg: "radial-gradient(ellipse 90% 70% at 50% 30%, #1e3a8a 0%, #0f2060 25%, #060f30 55%, #010510 80%, #000204 100%)",
    accent: "#3b82f6", glow: "rgba(59,130,246,0.5)",
    particle: "shooting", particleColor: "150,200,255",
  },
  jade: {
    name: "Jade",
    bg: "radial-gradient(ellipse 95% 80% at 50% 40%, #064e3b 0%, #022c24 28%, #011810 58%, #000804 85%, #000200 100%)",
    accent: "#10b981", glow: "rgba(16,185,129,0.5)",
    particle: "firefly", particleColor: "100,255,180",
  },
  copper: {
    name: "Copper",
    bg: "radial-gradient(ellipse 90% 75% at 50% 105%, #b45309 0%, #78350f 22%, #3a1a06 48%, #160800 78%, #050200 100%)",
    accent: "#f59e0b", glow: "rgba(245,158,11,0.55)",
    particle: "ember", particleColor: "255,170,60",
  },
  abyss: {
    name: "Abyss",
    bg: "linear-gradient(180deg, #000000 0%, #010408 30%, #020610 60%, #01030a 85%, #000000 100%)",
    accent: "#1d4ed8", glow: "rgba(29,78,216,0.5)",
    particle: "bubble", particleColor: "50,100,200",
  },
  lava: {
    name: "Lava",
    bg: "linear-gradient(180deg, #050000 0%, #1a0400 20%, #5c1400 38%, #c43c00 52%, #e86b10 62%, #5c1400 78%, #1a0400 92%, #050000 100%)",
    accent: "#f97316", glow: "rgba(249,115,22,0.65)",
    particle: "ember", particleColor: "255,150,50",
  },
  petal: {
    name: "Petal",
    bg: "linear-gradient(180deg, #2d0a2a 0%, #4a1844 28%, #1e0a1a 65%, #0c040e 90%, #03010a 100%)",
    accent: "#f472b6", glow: "rgba(244,114,182,0.5)",
    particle: "snow", particleColor: "255,200,230",
  },
  storm: {
    name: "Storm",
    bg: "linear-gradient(180deg, #111827 0%, #1f2937 25%, #0f172a 55%, #060b16 80%, #020609 100%)",
    accent: "#94a3b8", glow: "rgba(148,163,184,0.4)",
    particle: "rain", particleColor: "170,190,220",
  },
  coral: {
    name: "Coral",
    bg: "radial-gradient(ellipse 90% 70% at 50% 100%, #db4a3a 0%, #7a1a14 22%, #3c0c0a 50%, #160402 78%, #040100 100%)",
    accent: "#fb7185", glow: "rgba(251,113,133,0.55)",
    particle: "bubble", particleColor: "255,160,160",
  },
  obsidian: {
    name: "Obsidian",
    bg: "radial-gradient(ellipse at 50% 35%, #1a1a22 0%, #0e0e14 40%, #06060a 70%, #020204 100%)",
    accent: "#8b5cf6", glow: "rgba(139,92,246,0.45)",
    particle: "twinkle", particleColor: "200,180,255",
  },
  prism: {
    name: "Prism",
    bg: "linear-gradient(135deg, #0a0020 0%, #0e0040 25%, #0a1060 50%, #002050 70%, #001a20 90%, #000010 100%)",
    accent: "#e879f9", glow: "rgba(232,121,249,0.5)",
    particle: "shooting", particleColor: "200,150,255",
  },
  dusk: {
    name: "Dusk",
    bg: "linear-gradient(180deg, #0f0a1e 0%, #2d1654 18%, #5a2580 34%, #9a4060 50%, #d4763a 64%, #7a3020 78%, #1e0808 92%, #060204 100%)",
    accent: "#c084fc", glow: "rgba(192,132,252,0.5)",
    particle: "drift", particleColor: "240,180,220",
  },
  ultraviolet: {
    name: "UV",
    bg: "radial-gradient(ellipse 80% 60% at 50% 30%, #5b21b6 0%, #2e1065 25%, #130630 55%, #050116 80%, #010006 100%)",
    accent: "#7c3aed", glow: "rgba(124,58,237,0.6)",
    particle: "shooting", particleColor: "180,130,255",
  },
  terra: {
    name: "Terra",
    bg: "radial-gradient(ellipse 95% 75% at 50% 100%, #7c3d2a 0%, #4a1e10 22%, #2c0e06 50%, #100402 78%, #040100 100%)",
    accent: "#d97706", glow: "rgba(217,119,6,0.5)",
    particle: "drift", particleColor: "220,160,100",
  },
  carnival: {
    name: "Carnival",
    bg: "linear-gradient(135deg, #2a0040 0%, #500080 20%, #900050 38%, #c00020 55%, #600020 75%, #200040 90%, #080010 100%)",
    accent: "#f43f5e", glow: "rgba(244,63,94,0.55)",
    particle: "bubble", particleColor: "255,120,200",
  },
  hollow: {
    name: "Hollow",
    bg: "radial-gradient(ellipse at 50% 50%, #0d0d0d 0%, #060606 50%, #000000 100%)",
    accent: "#e5e7eb", glow: "rgba(229,231,235,0.2)",
    particle: "drift", particleColor: "200,200,200",
  },
  phoenix: {
    name: "Phoenix",
    bg: "radial-gradient(ellipse 100% 85% at 50% 110%, #c2410c 0%, #7c2d12 15%, #451a03 35%, #1e0a00 60%, #080300 85%, #020100 100%)",
    accent: "#f97316", glow: "rgba(249,115,22,0.7)",
    particle: "ember", particleColor: "255,180,60",
  },
  marble: {
    name: "Marble",
    bg: "linear-gradient(145deg, #1a1a1a 0%, #252525 20%, #1c1c1c 40%, #2a2a2a 60%, #1a1a1a 80%, #212121 100%)",
    accent: "#e5e7eb", glow: "rgba(229,231,235,0.3)",
    particle: "snow", particleColor: "255,255,255",
  },
  deepspace: {
    name: "Deep Space",
    bg: "radial-gradient(ellipse 60% 50% at 25% 30%, #2a0060 0%, transparent 60%), radial-gradient(ellipse 50% 40% at 80% 70%, #00206a 0%, transparent 60%), radial-gradient(ellipse at 50% 50%, #04020e 0%, #010008 100%)",
    accent: "#818cf8", glow: "rgba(129,140,248,0.5)",
    particle: "shooting", particleColor: "200,210,255",
  },
  noire: {
    name: "Noire",
    bg: "radial-gradient(ellipse at 40% 40%, #1a1a1a 0%, #0c0c0c 50%, #000000 100%)",
    accent: "#fbbf24", glow: "rgba(251,191,36,0.5)",
    particle: "rain", particleColor: "180,160,100",
  },
  gold: {
    name: "Gold",
    bg: "radial-gradient(ellipse 90% 75% at 50% 100%, #b7870a 0%, #7a5508 22%, #3c2804 50%, #170f02 78%, #060400 100%)",
    accent: "#fcd34d", glow: "rgba(252,211,77,0.6)",
    particle: "twinkle", particleColor: "255,230,100",
  },
  /* ── Yuki OS-inspired themes ── */
  "tokyo-night": {
    name: "Tokyo Night",
    bg: "linear-gradient(180deg, #1a1b26 0%, #12131e 60%, #0d0e18 100%)",
    accent: "#7dcfff", glow: "rgba(125,207,255,0.45)",
    particle: "twinkle", particleColor: "125,207,255",
  },
  catppuccin: {
    name: "Catppuccin",
    bg: "linear-gradient(180deg, #1e1e2e 0%, #181825 55%, #11111b 100%)",
    accent: "#cba6f7", glow: "rgba(203,166,247,0.45)",
    particle: "drift", particleColor: "203,166,247",
  },
  dracula: {
    name: "Dracula",
    bg: "linear-gradient(180deg, #282a36 0%, #21222c 55%, #191a23 100%)",
    accent: "#ff79c6", glow: "rgba(255,121,198,0.45)",
    particle: "twinkle", particleColor: "255,121,198",
  },
  oled: {
    name: "OLED",
    bg: "#000000",
    accent: "#e0e0e0", glow: "rgba(224,224,224,0.25)",
    particle: "twinkle", particleColor: "255,255,255",
  },
  nordic: {
    name: "Nordic",
    bg: "linear-gradient(180deg, #2e3440 0%, #252a33 55%, #1c2028 100%)",
    accent: "#88c0d0", glow: "rgba(136,192,208,0.45)",
    particle: "snow", particleColor: "136,192,208",
  },
  crt: {
    name: "CRT",
    bg: "linear-gradient(180deg, #000a00 0%, #000600 50%, #000200 100%)",
    accent: "#00ff41", glow: "rgba(0,255,65,0.5)",
    particle: "rain", particleColor: "0,255,65",
  },
  gameboy: {
    name: "Gameboy",
    bg: "linear-gradient(180deg, #3a4a1c 0%, #2c3810 55%, #1e2808 100%)",
    accent: "#9bbc0f", glow: "rgba(155,188,15,0.5)",
    particle: "firefly", particleColor: "155,188,15",
  },
  frutiger: {
    name: "Frutiger Aero",
    bg: "linear-gradient(180deg, #003a7a 0%, #005eb8 25%, #0080c7 50%, #003060 80%, #001830 100%)",
    accent: "#40d0ff", glow: "rgba(64,208,255,0.5)",
    particle: "bubble", particleColor: "100,210,255",
  },
  nier: {
    name: "NieR",
    bg: "linear-gradient(180deg, #1a1710 0%, #120f08 50%, #0a0906 100%)",
    accent: "#c8b882", glow: "rgba(200,184,130,0.45)",
    particle: "drift", particleColor: "200,184,130",
  },
  eva01: {
    name: "EVA Unit-01",
    bg: "linear-gradient(180deg, #1a0a2e 0%, #2a0a40 35%, #0a1a08 70%, #050a04 100%)",
    accent: "#00ff4c", glow: "rgba(0,255,76,0.55)",
    particle: "firefly", particleColor: "0,255,76",
  },
  eva02: {
    name: "EVA Unit-02",
    bg: "radial-gradient(ellipse at 50% 100%, #8b1a00 0%, #4a0c00 30%, #1a0400 65%, #050100 100%)",
    accent: "#ff4400", glow: "rgba(255,68,0,0.65)",
    particle: "ember", particleColor: "255,100,50",
  },
  y2k: {
    name: "Y2K",
    bg: "linear-gradient(135deg, #0a0a2e 0%, #1a1a5e 30%, #0e0e3a 65%, #050520 100%)",
    accent: "#00ffff", glow: "rgba(0,255,255,0.45)",
    particle: "shooting", particleColor: "0,255,255",
  },
  "aura-dark": {
    name: "Aura",
    bg: "linear-gradient(180deg, #15112a 0%, #1f1640 55%, #130f28 100%)",
    accent: "#a277ff", glow: "rgba(162,119,255,0.5)",
    particle: "twinkle", particleColor: "162,119,255",
  },
  miku: {
    name: "Hatsune Miku",
    bg: "linear-gradient(180deg, #001a1f 0%, #002830 40%, #001520 80%, #000a10 100%)",
    accent: "#39c5bb", glow: "rgba(57,197,187,0.55)",
    particle: "bubble", particleColor: "57,197,187",
  },
  solarized: {
    name: "Solarized",
    bg: "linear-gradient(180deg, #002b36 0%, #003847 55%, #001f2a 100%)",
    accent: "#268bd2", glow: "rgba(38,139,210,0.45)",
    particle: "twinkle", particleColor: "38,139,210",
  },
  "high-contrast": {
    name: "High Contrast",
    bg: "#000000",
    accent: "#ffff00", glow: "rgba(255,255,0,0.5)",
    particle: "rain", particleColor: "255,255,0",
  },
  sepia: {
    name: "Sepia",
    bg: "linear-gradient(180deg, #2c1a08 0%, #1a0e04 55%, #0e0802 100%)",
    accent: "#d4a96a", glow: "rgba(212,169,106,0.45)",
    particle: "drift", particleColor: "212,169,106",
  },
  starwars: {
    name: "Star Wars",
    bg: "#000000",
    accent: "#ffe81f", glow: "rgba(255,232,31,0.5)",
    particle: "shooting", particleColor: "255,232,31",
  },
  "windows-xp": {
    name: "Windows XP",
    bg: "linear-gradient(180deg, #1e6494 0%, #2b7abf 30%, #1a4e7a 70%, #0e2e4a 100%)",
    accent: "#4dc3ff", glow: "rgba(77,195,255,0.45)",
    particle: "bubble", particleColor: "150,200,255",
  },
  gruvbox: {
    name: "Gruvbox",
    bg: "linear-gradient(180deg, #282828 0%, #1d2021 60%, #141617 100%)",
    accent: "#fabd2f", glow: "rgba(250,189,47,0.5)",
    particle: "ember", particleColor: "250,189,47",
  },
  monokai: {
    name: "Monokai",
    bg: "linear-gradient(180deg, #272822 0%, #1e1f1c 60%, #141410 100%)",
    accent: "#e6db74", glow: "rgba(230,219,116,0.45)",
    particle: "twinkle", particleColor: "230,219,116",
  },
  hackerblue: {
    name: "Hacker Blue",
    bg: "linear-gradient(180deg, #001830 0%, #001020 55%, #000810 100%)",
    accent: "#00b4ff", glow: "rgba(0,180,255,0.55)",
    particle: "rain", particleColor: "0,180,255",
  },
  outrun: {
    name: "Outrun",
    bg: "linear-gradient(180deg, #0a0018 0%, #1a0038 25%, #3a0060 42%, #1a0038 65%, #08000e 100%)",
    accent: "#ff6ec7", glow: "rgba(255,110,199,0.55)",
    particle: "shooting", particleColor: "255,100,200",
  },
  rosepine: {
    name: "Rosé Pine",
    bg: "linear-gradient(180deg, #191724 0%, #1f1d2e 55%, #16141f 100%)",
    accent: "#ebbcba", glow: "rgba(235,188,186,0.45)",
    particle: "drift", particleColor: "235,188,186",
  },
  material: {
    name: "Material",
    bg: "linear-gradient(180deg, #212121 0%, #1a1a1a 55%, #121212 100%)",
    accent: "#bb86fc", glow: "rgba(187,134,252,0.45)",
    particle: "twinkle", particleColor: "187,134,252",
  },
  onedark: {
    name: "One Dark",
    bg: "linear-gradient(180deg, #282c34 0%, #21252b 55%, #181a1f 100%)",
    accent: "#61afef", glow: "rgba(97,175,239,0.45)",
    particle: "twinkle", particleColor: "97,175,239",
  },
  cobalt: {
    name: "Cobalt",
    bg: "linear-gradient(180deg, #002244 0%, #001a38 55%, #001228 100%)",
    accent: "#ffc600", glow: "rgba(255,198,0,0.5)",
    particle: "bubble", particleColor: "255,198,0",
  },
  snes: {
    name: "SNES",
    bg: "linear-gradient(180deg, #2c1e3f 0%, #1e1430 55%, #0e0a18 100%)",
    accent: "#e4e4e4", glow: "rgba(228,228,228,0.3)",
    particle: "snow", particleColor: "228,228,228",
  },
  horizon: {
    name: "Horizon",
    bg: "linear-gradient(180deg, #1c1e26 0%, #16181f 55%, #0e1018 100%)",
    accent: "#e95678", glow: "rgba(233,86,120,0.5)",
    particle: "drift", particleColor: "233,86,120",
  },
  synthwave: {
    name: "Synthwave",
    bg: "linear-gradient(180deg, #0d0221 0%, #190334 25%, #2b0050 45%, #0d0221 70%, #06010f 100%)",
    accent: "#ff00c8", glow: "rgba(255,0,200,0.55)",
    particle: "shooting", particleColor: "255,0,200",
  },
  ember: {
    name: "Ember", bg: "radial-gradient(ellipse at 50% 100%, #7c2d12 0%, #2c0d08 38%, #0b0503 100%)",
    accent: "#f97316", glow: "rgba(249,115,22,0.55)", particle: "ember", particleColor: "255,170,60",
  },
  "lavender-mist": {
    name: "Lavender Mist", bg: "linear-gradient(135deg, #24143f 0%, #17102b 48%, #080612 100%)",
    accent: "#c4b5fd", glow: "rgba(196,181,253,0.45)", particle: "drift", particleColor: "225,210,255",
  },
  "deep-ocean": {
    name: "Deep Ocean", bg: "radial-gradient(ellipse at 20% 0%, #164e63 0%, #082f49 28%, #031525 70%, #01060d 100%)",
    accent: "#38bdf8", glow: "rgba(56,189,248,0.45)", particle: "bubble", particleColor: "140,220,255",
  },
  terminal: {
    name: "Terminal", bg: "linear-gradient(180deg, #06120b 0%, #020803 60%, #000000 100%)",
    accent: "#86efac", glow: "rgba(134,239,172,0.35)", particle: "rain", particleColor: "100,255,140",
  },
  paper: {
    name: "Paper", bg: "linear-gradient(145deg, #3b3a36 0%, #242320 52%, #151513 100%)",
    accent: "#facc15", glow: "rgba(250,204,21,0.35)", particle: "snow", particleColor: "255,245,190",
  },
  plasma: {
    name: "Plasma", bg: "radial-gradient(ellipse at 70% 20%, #701a75 0%, #2e1065 35%, #10052d 72%, #03010a 100%)",
    accent: "#e879f9", glow: "rgba(232,121,249,0.55)", particle: "shooting", particleColor: "255,150,245",
  },
};
const THEME_ORDER: ThemeKey[] = [
  "default", "forest", "crimson", "lavendar",
  "monochrome", "midnight", "sunset", "ocean",
  "aurora", "sakura", "cyberpunk", "galaxy",
  "matrix", "volcano", "vaporwave", "mint",
  "rose", "nebula", "arctic", "toxic",
  "twilight", "amber",
  "neon", "blood", "sapphire", "jade", "copper", "abyss",
  "lava", "petal", "storm", "coral", "obsidian", "prism",
  "dusk", "ultraviolet", "terra", "carnival", "hollow",
  "phoenix", "marble", "deepspace", "noire", "gold",
  "tokyo-night", "catppuccin", "dracula", "oled", "nordic",
  "crt", "gameboy", "frutiger", "nier", "eva01", "eva02",
  "y2k", "aura-dark", "miku", "solarized", "high-contrast",
  "sepia", "starwars", "windows-xp", "synthwave",
  "gruvbox", "monokai", "hackerblue", "outrun", "rosepine",
  "material", "onedark", "cobalt", "snes", "horizon",
  "ember", "lavender-mist", "deep-ocean", "terminal", "paper", "plasma",
];

type AvatarDecoration = "none" | "sparkles" | "crown" | "flame" | "hearts" | "halo" | "diamond";
const AVATAR_DECORATIONS: Array<{ id: AvatarDecoration; name: string; emoji: string; color: string }> = [
  { id: "none", name: "None", emoji: "", color: "transparent" },
  { id: "sparkles", name: "Sparkles", emoji: "✦", color: "#f9a8d4" },
  { id: "crown", name: "Crown", emoji: "♛", color: "#facc15" },
  { id: "flame", name: "Flame", emoji: "🔥", color: "#fb923c" },
  { id: "hearts", name: "Hearts", emoji: "♥", color: "#fb7185" },
  { id: "halo", name: "Halo", emoji: "◌", color: "#fde68a" },
  { id: "diamond", name: "Diamond", emoji: "◆", color: "#67e8f9" },
];

/* ─── Cloak definitions ──────────────────────────────────── */
type CloakKey =
  | "none" | "google" | "google-classroom" | "google-drive"
  | "blooket" | "kahoot" | "edpuzzle" | "iready"
  | "canvas" | "schoology" | "khan" | "wikipedia" | "outlook";

const CLOAKS: { id: CloakKey; name: string; title: string; favicon: string | null }[] = [
  { id: "none",             name: "None",             title: "Phoenix",             favicon: null },
  { id: "google",           name: "Google",           title: "Google",              favicon: "https://www.google.com/favicon.ico" },
  { id: "google-classroom", name: "Classroom",        title: "Google Classroom",    favicon: "https://ssl.gstatic.com/classroom/favicon.png" },
  { id: "google-drive",     name: "Drive",            title: "My Drive - Google Drive", favicon: "https://ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png" },
  { id: "blooket",          name: "Blooket",          title: "Blooket",             favicon: "https://www.blooket.com/favicon.ico" },
  { id: "kahoot",           name: "Kahoot",           title: "Kahoot!",             favicon: "https://kahoot.com/wp-content/uploads/2019/01/cropped-favicon-32x32.png" },
  { id: "edpuzzle",         name: "Edpuzzle",         title: "Edpuzzle",            favicon: null },
  { id: "iready",           name: "i-Ready",          title: "i-Ready Dashboard",   favicon: null },
  { id: "canvas",           name: "Canvas",           title: "Dashboard",           favicon: "https://du11hjcvx0uqb.cloudfront.net/dist/images/favicon-e10d657a73.ico" },
  { id: "schoology",        name: "Schoology",        title: "Home | Schoology",    favicon: "https://www.schoology.com/sites/all/themes/schoology_theme/favicon.ico" },
  { id: "khan",             name: "Khan",             title: "Khan Academy",        favicon: "https://www.khanacademy.org/favicon.ico" },
  { id: "wikipedia",        name: "Wikipedia",        title: "Wikipedia",           favicon: "https://en.wikipedia.org/static/favicon/wikipedia.ico" },
  { id: "outlook",          name: "Outlook",          title: "Mail - Outlook",      favicon: "https://outlook.live.com/owa/favicon.ico" },
];

interface Bookmark { url: string; title: string; favicon?: string | null }

function applyCloak(cloak: CloakKey) {
  const def = CLOAKS.find(c => c.id === cloak)!;
  document.title = def.title;
  let link = document.querySelector<HTMLLinkElement>("link[rel~='icon']");
  if (!link) { link = document.createElement("link"); link.rel = "icon"; document.head.appendChild(link); }
  link.href = def.favicon ?? "/favicon.ico";
}

/* ─── Sidebar nav items ──────────────────────────────────── */
type NavId = "home" | "discover" | "library" | "activity" | "games" | "movies" | "tv" | "anime" | "music" | "ai" | "apps" | "friends" | "settings" | "credits" | "currency" | "incognito" | "html";

interface NavItem {
  id: NavId;
  icon: React.ReactNode;
  label: string;
  url?: string;
  bottom?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { id: "home",      icon: <HomeIcon2 size={18} />,     label: "Home" },
  { id: "discover",  icon: <Compass size={18} />,       label: "Discover" },
  { id: "library",   icon: <Library size={18} />,        label: "Library" },
  { id: "activity",  icon: <Activity size={18} />,       label: "Activity" },
  { id: "games",     icon: <GamesIcon size={18} />,     label: "Games" },
  { id: "movies",    icon: <MoviesIcon size={18} />,    label: "Movies" },
  { id: "tv",        icon: <TVIcon size={18} />,        label: "TV" },
  { id: "anime",     icon: <AnimeIcon size={18} />,     label: "Anime" },
  { id: "music",     icon: <MusicIcon2 size={18} />,    label: "Music" },
  { id: "ai",        icon: <AIIcon size={18} />,        label: "AI" },
  { id: "apps",      icon: <AppsIcon size={18} />,      label: "Tools",   url: "https://www.wolframalpha.com" },
  { id: "html",      icon: <HTMLIcon size={18} />,      label: "HTML" },
  { id: "friends",   icon: <ChatIcon size={18} />,      label: "Friends" },
  { id: "settings",  icon: <SettingsIcon2 size={18} />, label: "Settings" },
  { id: "credits",   icon: <Heart size={18} />,         label: "Credits" },
  { id: "currency",  icon: <Coins size={18} />,         label: "AtBucks" },
  { id: "incognito", icon: <IncognitoIcon size={18} />, label: "Incognito", bottom: true },
];

const QUICK_LINKS = [
  { label: "YouTube", icon: "▶", url: "https://www.youtube.com" },
  { label: "GitHub",  icon: "⚙", url: "https://github.com" },
  { label: "Google",  icon: "G", url: "https://www.google.com" },
  { label: "Reddit",  icon: "↑", url: "https://old.reddit.com" },
  { label: "Wikipedia", icon: "W", url: "https://en.wikipedia.org" },
];

const QUOTES = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "In the middle of difficulty lies opportunity.", author: "Albert Einstein" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
  { text: "Life is what happens when you're busy making other plans.", author: "John Lennon" },
  { text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt" },
  { text: "Strive not to be a success, but rather to be of value.", author: "Albert Einstein" },
  { text: "You miss 100% of the shots you don't take.", author: "Wayne Gretzky" },
  { text: "Whether you think you can or think you can't, you're right.", author: "Henry Ford" },
  { text: "The best time to plant a tree was 20 years ago. The second best time is now.", author: "Chinese Proverb" },
  { text: "An unexamined life is not worth living.", author: "Socrates" },
  { text: "Spread love everywhere you go. Let no one ever come to you without leaving happier.", author: "Mother Teresa" },
  { text: "When you reach the end of your rope, tie a knot in it and hang on.", author: "Franklin D. Roosevelt" },
];

const todayQuote = QUOTES[new Date().getDate() % QUOTES.length];

/* ─── Backdrop (themed particles) ────────────────────────── */
function Starfield({ particle = "twinkle", color = "255,255,255" }: { particle?: ParticleType; color?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext("2d"); if (!ctx) return;

    type P = { x: number; y: number; r: number; a: number; spd: number; dir: number; vx: number; vy: number };
    let particles: P[] = [];
    let raf = 0;

    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };

    const make = (): P => {
      const w = canvas.width, h = canvas.height;
      switch (particle) {
        case "ember":
          return {
            x: Math.random() * w, y: h + Math.random() * h * 0.4,
            r: Math.random() * 2 + 0.7, a: Math.random() * 0.6 + 0.3,
            spd: 0, dir: 1,
            vx: (Math.random() - 0.5) * 0.4, vy: -(Math.random() * 1.0 + 0.4),
          };
        case "bubble":
          return {
            x: Math.random() * w, y: h + Math.random() * h * 0.5,
            r: Math.random() * 4 + 1.2, a: Math.random() * 0.35 + 0.1,
            spd: 0, dir: 1, vx: 0, vy: -(Math.random() * 0.5 + 0.15),
          };
        case "firefly":
          return {
            x: Math.random() * w, y: Math.random() * h,
            r: Math.random() * 1.6 + 0.7, a: Math.random() * 0.7 + 0.15,
            spd: Math.random() * 0.015 + 0.005, dir: Math.random() > 0.5 ? 1 : -1,
            vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25,
          };
        case "snow":
          return {
            x: Math.random() * w, y: Math.random() * h,
            r: Math.random() * 1.6 + 0.4, a: Math.random() * 0.5 + 0.2,
            spd: 0, dir: 1, vx: (Math.random() - 0.5) * 0.15, vy: Math.random() * 0.4 + 0.1,
          };
        case "drift":
          return {
            x: Math.random() * w, y: Math.random() * h,
            r: Math.random() * 1.4 + 0.4, a: Math.random() * 0.5 + 0.1,
            spd: Math.random() * 0.003 + 0.001, dir: Math.random() > 0.5 ? 1 : -1,
            vx: (Math.random() - 0.3) * 0.18, vy: (Math.random() - 0.5) * 0.06,
          };
        case "rain":
          return {
            x: Math.random() * w, y: Math.random() * h,
            r: Math.random() * 14 + 6, a: Math.random() * 0.6 + 0.25,
            spd: 0, dir: 1,
            vx: 0, vy: Math.random() * 4 + 2.5,
          };
        case "shooting":
          return {
            x: Math.random() * w * 1.4 - w * 0.2, y: Math.random() * h * 0.6 - 50,
            r: Math.random() * 80 + 60, a: 0,
            spd: Math.random() * 0.02 + 0.018, dir: 1,
            vx: Math.random() * 3 + 2.5, vy: Math.random() * 2 + 1,
          };
        default:
          return {
            x: Math.random() * w, y: Math.random() * h,
            r: Math.random() * 1.4 + 0.3, a: Math.random() * 0.7 + 0.08,
            spd: Math.random() * 0.004 + 0.001, dir: Math.random() > 0.5 ? 1 : -1,
            vx: 0, vy: 0,
          };
      }
    };

    const seed = () => {
      const count =
        particle === "ember" ? 130 :
        particle === "bubble" ? 50 :
        particle === "firefly" ? 60 :
        particle === "snow" ? 110 :
        particle === "drift" ? 90 :
        particle === "rain" ? 140 :
        particle === "shooting" ? 8 : 200;
      particles = Array.from({ length: count }, make);
    };

    const update = (p: P) => {
      const w = canvas.width, h = canvas.height;
      if (particle === "shooting") {
        p.a += p.spd * p.dir;
        if (p.dir === 1 && p.a >= 0.8) p.dir = -1;
        if (p.dir === -1) {
          p.x += p.vx * 2; p.y += p.vy * 2;
          if (p.a <= 0) {
            const n = make(); p.x = n.x; p.y = n.y; p.r = n.r;
            p.a = 0; p.dir = 1; p.vx = n.vx; p.vy = n.vy; p.spd = n.spd;
          }
        }
        return;
      }
      if (particle === "rain") {
        p.y += p.vy;
        if (p.y - p.r > h) { p.y = -p.r; p.x = Math.random() * w; p.a = Math.random() * 0.6 + 0.25; }
      } else if (particle === "ember" || particle === "bubble" || particle === "snow") {
        p.x += p.vx; p.y += p.vy;
        if (particle === "snow") {
          if (p.y > h + 5) { p.y = -5; p.x = Math.random() * w; }
        } else {
          if (p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
        }
        if (p.x < -10) p.x = w + 5; else if (p.x > w + 10) p.x = -5;
        if (particle === "ember") {
          p.a += (Math.random() - 0.5) * 0.06;
          p.a = Math.max(0.1, Math.min(0.85, p.a));
        }
      } else if (particle === "firefly" || particle === "drift") {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = w; else if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h; else if (p.y > h) p.y = 0;
        p.a += p.spd * p.dir;
        if (p.a > 0.8) { p.a = 0.8; p.dir = -1; }
        if (p.a < 0.05) { p.a = 0.05; p.dir = 1; }
      } else {
        p.a += p.spd * p.dir;
        if (p.a > 0.85) { p.a = 0.85; p.dir = -1; }
        if (p.a < 0.05) { p.a = 0.05; p.dir = 1; }
      }
    };

    const render = (p: P) => {
      if (particle === "shooting") {
        const tail = p.r;
        const grad = ctx.createLinearGradient(p.x - p.vx * tail * 0.5, p.y - p.vy * tail * 0.5, p.x + p.vx * tail * 0.5, p.y + p.vy * tail * 0.5);
        grad.addColorStop(0, `rgba(${color},0)`);
        grad.addColorStop(0.7, `rgba(${color},${(p.a * 0.5).toFixed(3)})`);
        grad.addColorStop(1, `rgba(${color},${Math.min(1, p.a + 0.1).toFixed(3)})`);
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(p.x - p.vx * tail * 0.5, p.y - p.vy * tail * 0.5);
        ctx.lineTo(p.x + p.vx * tail * 0.5, p.y + p.vy * tail * 0.5);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(p.x + p.vx * tail * 0.5, p.y + p.vy * tail * 0.5, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${color},${Math.min(1, p.a + 0.2).toFixed(3)})`;
        ctx.fill();
        return;
      }
      if (particle === "rain") {
        const grad = ctx.createLinearGradient(p.x, p.y - p.r, p.x, p.y + p.r);
        grad.addColorStop(0, `rgba(${color},0)`);
        grad.addColorStop(0.7, `rgba(${color},${(p.a * 0.7).toFixed(3)})`);
        grad.addColorStop(1, `rgba(${color},${p.a.toFixed(3)})`);
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y - p.r);
        ctx.lineTo(p.x, p.y + p.r);
        ctx.stroke();
        return;
      }
      if (particle === "bubble") {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(${color},${p.a.toFixed(3)})`;
        ctx.lineWidth = 0.9;
        ctx.stroke();
      } else if (particle === "ember") {
        const haloR = p.r * 8;
        const halo = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, haloR);
        halo.addColorStop(0, `rgba(${color},${(p.a * 0.85).toFixed(3)})`);
        halo.addColorStop(0.4, `rgba(${color},${(p.a * 0.25).toFixed(3)})`);
        halo.addColorStop(1, `rgba(${color},0)`);
        ctx.fillStyle = halo;
        ctx.fillRect(p.x - haloR, p.y - haloR, haloR * 2, haloR * 2);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,240,200,${Math.min(1, p.a + 0.3).toFixed(3)})`;
        ctx.fill();
      } else if (particle === "firefly") {
        const halo = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5);
        halo.addColorStop(0, `rgba(${color},${(p.a * 0.7).toFixed(3)})`);
        halo.addColorStop(1, `rgba(${color},0)`);
        ctx.fillStyle = halo;
        ctx.fillRect(p.x - p.r * 5, p.y - p.r * 5, p.r * 10, p.r * 10);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${color},${Math.min(1, p.a + 0.25).toFixed(3)})`;
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${color},${p.a.toFixed(3)})`;
        ctx.fill();
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const p of particles) { update(p); render(p); }
      raf = requestAnimationFrame(draw);
    };

    resize(); seed(); draw();
    const onResize = () => { resize(); seed(); };
    window.addEventListener("resize", onResize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", onResize); };
  }, [particle, color]);

  return <canvas ref={canvasRef} style={{ position: "fixed", inset: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 0 }} />;
}

/* ─── Pixel Phoenix icon ─────────────────────────────────── */
function PhoenixPixelIcon({ size = 44 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" style={{ imageRendering: "pixelated" }} xmlns="http://www.w3.org/2000/svg">
      <rect x="7" y="14" width="2" height="1" fill="#f97316" />
      <rect x="6" y="13" width="4" height="1" fill="#fb923c" />
      <rect x="5" y="13" width="1" height="2" fill="#f97316" />
      <rect x="10" y="13" width="1" height="2" fill="#f97316" />
      <rect x="4" y="14" width="1" height="1" fill="#ea580c" />
      <rect x="11" y="14" width="1" height="1" fill="#ea580c" />
      <rect x="5" y="8" width="6" height="5" fill="#fb923c" />
      <rect x="4" y="9" width="1" height="3" fill="#fb923c" />
      <rect x="11" y="9" width="1" height="3" fill="#fb923c" />
      <rect x="6" y="8" width="4" height="1" fill="#fed7aa" />
      <rect x="1" y="7" width="4" height="3" fill="#f97316" />
      <rect x="11" y="7" width="4" height="3" fill="#f97316" />
      <rect x="1" y="10" width="3" height="1" fill="#ea580c" />
      <rect x="12" y="10" width="3" height="1" fill="#ea580c" />
      <rect x="2" y="6" width="3" height="1" fill="#fb923c" />
      <rect x="11" y="6" width="3" height="1" fill="#fb923c" />
      <rect x="6" y="9" width="4" height="2" fill="#fed7aa" />
      <rect x="7" y="11" width="2" height="1" fill="#fed7aa" />
      <rect x="6" y="4" width="4" height="4" fill="#fb923c" />
      <rect x="5" y="5" width="1" height="2" fill="#fb923c" />
      <rect x="10" y="5" width="1" height="2" fill="#fb923c" />
      <rect x="8" y="7" width="2" height="1" fill="#fde68a" />
      <rect x="6" y="3" width="1" height="2" fill="#fbbf24" />
      <rect x="8" y="1" width="1" height="3" fill="#f59e0b" />
      <rect x="10" y="2" width="1" height="2" fill="#fbbf24" />
      <rect x="7" y="2" width="2" height="1" fill="#fde68a" />
      <rect x="6" y="5" width="1" height="1" fill="#1c1c1c" />
      <rect x="9" y="5" width="1" height="1" fill="#1c1c1c" />
    </svg>
  );
}

function AvatarDisplay({ avatarUrl, name, decoration = "none", size = 34, accent }: { avatarUrl?: string | null; name: string; decoration?: string | null; size?: number; accent: string }) {
  const decor = AVATAR_DECORATIONS.find(item => item.id === decoration) || AVATAR_DECORATIONS[0];
  return (
    <div aria-label={`${name} avatar`} style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <div style={{ width: "100%", height: "100%", borderRadius: "50%", overflow: "hidden", background: `${accent}28`, color: accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: Math.max(11, Math.round(size * 0.38)), fontWeight: 700 }}>
        {avatarUrl ? <img src={avatarUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : name[0]?.toUpperCase() || "?"}
      </div>
      {decor.id !== "none" && (
        <>
          <div style={{ position: "absolute", inset: -3, borderRadius: "50%", border: `2px solid ${decor.color}`, boxShadow: `0 0 0 2px rgba(0,0,0,0.72), 0 0 10px ${decor.color}99`, pointerEvents: "none" }} />
          <span style={{ position: "absolute", top: -Math.max(7, size * 0.2), right: -Math.max(5, size * 0.12), color: decor.color, fontSize: Math.max(10, Math.round(size * 0.34)), lineHeight: 1, textShadow: `0 0 7px ${decor.color}` }}>{decor.emoji}</span>
        </>
      )}
    </div>
  );
}

/* ─── Card wrapper ───────────────────────────────────────── */
function Card({ children, width = 310 }: { children: React.ReactNode; width?: number }) {
  return (
    <div style={{
      position: "relative", zIndex: 1,
      background: "rgba(22,22,22,0.96)", borderRadius: "16px",
      border: "1px solid rgba(255,255,255,0.08)", width: `${width}px`,
      padding: "40px 32px 36px", display: "flex", flexDirection: "column",
      alignItems: "center", textAlign: "center", boxShadow: "0 12px 60px rgba(0,0,0,0.8)",
    }}>
      {children}
    </div>
  );
}

/* ─── Option grid button ─────────────────────────────────── */
function OptionBtn({ label, selected, accent, onClick }: { label: string; selected: boolean; accent: string; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{
      padding: "10px 0", borderRadius: "10px",
      border: selected ? `1px solid ${accent}` : "1px solid rgba(255,255,255,0.07)",
      background: selected ? accent : "rgba(255,255,255,0.04)",
      color: selected ? "#fff" : "rgba(255,255,255,0.7)",
      fontSize: "13px", fontWeight: selected ? 600 : 400,
      cursor: "pointer", transition: "all 0.15s", width: "100%",
    }}>
      {label}
    </button>
  );
}

/* ─── Settings modal ─────────────────────────────────────── */
const WALLPAPERS: { id: string; name: string; url: string; thumb: string }[] = [
  { id: "none", name: "None", url: "", thumb: "" },
  { id: "galaxy", name: "Galaxy", url: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=200&q=70" },
  { id: "aurora", name: "Aurora", url: "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=200&q=70" },
  { id: "mountain", name: "Mountain", url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=200&q=70" },
  { id: "ocean", name: "Ocean", url: "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=200&q=70" },
  { id: "forest", name: "Forest", url: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=200&q=70" },
  { id: "neon-city", name: "Neon City", url: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=200&q=70" },
  { id: "desert", name: "Desert", url: "https://images.unsplash.com/photo-1473854687745-7b7027f84f3d?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1473854687745-7b7027f84f3d?w=200&q=70" },
  { id: "stars", name: "Starfield", url: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=200&q=70" },
  { id: "waterfall", name: "Waterfall", url: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=200&q=70" },
  { id: "architecture", name: "City", url: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=200&q=70" },
  { id: "abstract-blue", name: "Abstract", url: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1920&q=80", thumb: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=200&q=70" },
];

interface SettingsModalProps {
  theme: ThemeKey; setTheme: (t: ThemeKey) => void;
  cloak: CloakKey; setCloak: (c: CloakKey) => void;
  autoCloak: boolean; setAutoCloak: (b: boolean) => void;
  panicKey: string; setPanicKey: (k: string) => void;
  panicUrl: string; setPanicUrl: (u: string) => void;
  wallpaper: string; setWallpaper: (w: string) => void;
  accent: string; onClose: () => void;
  onAboutBlank: () => void; onResetOnboarding: () => void;
}
function SettingsModal({
  theme, setTheme, cloak, setCloak, autoCloak, setAutoCloak,
  panicKey, setPanicKey, panicUrl, setPanicUrl,
  wallpaper, setWallpaper,
  accent, onClose, onAboutBlank, onResetOnboarding,
}: SettingsModalProps) {
  const [avatarPreview, setAvatarPreview] = useState(() => localStorage.getItem("phoenix.avatarUrl") || "");
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const [profileDisplayName, setProfileDisplayName] = useState(() => localStorage.getItem("phoenix.displayName") || localStorage.getItem("phoenix.username") || "");
  const [profileBio, setProfileBio] = useState(() => localStorage.getItem("phoenix.bio") || "");
  const [avatarDecoration, setAvatarDecoration] = useState<AvatarDecoration>(() => (localStorage.getItem("phoenix.avatarDecoration") as AvatarDecoration | null) || "none");
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);
  const [recordingKey, setRecordingKey] = useState(false);
  const [curPw, setCurPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [pwMsg, setPwMsg] = useState<{ text: string; ok: boolean } | null>(null);
  const [pwLoading, setPwLoading] = useState(false);
  const submitPw = async () => {
    if (!curPw || newPw.length < 4) { setPwMsg({ text: "New password must be at least 4 chars.", ok: false }); return; }
    setPwLoading(true);
    try {
      const token = localStorage.getItem("phoenix.token");
      if (!token) { setPwMsg({ text: "Not signed in.", ok: false }); setPwLoading(false); return; }
      const res = await fetch(`${API_BASE}/auth/change-password`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ currentPassword: curPw, newPassword: newPw }) });
      const d = await res.json() as { message?: string; error?: string };
      if (res.ok) { setPwMsg({ text: d.message || "Password updated!", ok: true }); setCurPw(""); setNewPw(""); }
      else { setPwMsg({ text: d.error || "Failed.", ok: false }); }
    } catch { setPwMsg({ text: "Network error.", ok: false }); }
    setPwLoading(false);
  };
  const saveAvatar = (file: File) => {
    if (!file.type.startsWith("image/")) { setPwMsg({ text: "Choose an image file.", ok: false }); return; }
    if (file.size > 1_000_000) { setPwMsg({ text: "Profile pictures must be smaller than 1 MB.", ok: false }); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      const value = String(reader.result || "");
      setAvatarPreview(value);
      localStorage.setItem("phoenix.avatarUrl", value);
      window.dispatchEvent(new Event("phoenix-avatar-changed"));
      const token = localStorage.getItem("phoenix.token");
      if (token) await fetch(`${API_BASE}/auth/profile`, { method: "PATCH", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ avatarUrl: value }) });
    };
    reader.readAsDataURL(file);
  };
  const removeAvatar = async () => {
    setAvatarPreview("");
    localStorage.removeItem("phoenix.avatarUrl");
    window.dispatchEvent(new Event("phoenix-avatar-changed"));
    const token = localStorage.getItem("phoenix.token");
    if (token) await fetch(`${API_BASE}/auth/profile`, { method: "PATCH", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ avatarUrl: null }) });
  };
  const saveProfile = async () => {
    const displayName = profileDisplayName.trim();
    if (!displayName || displayName.length > 32) { setProfileMsg("Display name must be 1–32 characters."); return; }
    if (profileBio.length > 190) { setProfileMsg("About me must be 190 characters or fewer."); return; }
    const token = localStorage.getItem("phoenix.token");
    if (!token) { setProfileMsg("Sign in to save your profile."); return; }
    setProfileSaving(true);
    setProfileMsg(null);
    try {
      const res = await fetch(`${API_BASE}/auth/profile`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ displayName, bio: profileBio, avatarDecoration }),
      });
      const data = await res.json() as { displayName?: string; bio?: string; avatarDecoration?: AvatarDecoration; error?: string };
      if (!res.ok) { setProfileMsg(data.error || "Could not save profile."); return; }
      localStorage.setItem("phoenix.displayName", data.displayName || displayName);
      localStorage.setItem("phoenix.bio", data.bio || "");
      localStorage.setItem("phoenix.avatarDecoration", data.avatarDecoration || avatarDecoration);
      window.dispatchEvent(new Event("phoenix-profile-changed"));
      setProfileMsg("Profile saved.");
    } catch {
      setProfileMsg("Network error. Try again.");
    } finally {
      setProfileSaving(false);
    }
  };
  const sectionLabel: React.CSSProperties = { margin: "0 0 10px", fontSize: "12px", fontWeight: 600, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", letterSpacing: "0.08em" };
  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 100,
      background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center",
      backdropFilter: "blur(4px)",
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        background: "rgba(18,18,18,0.98)", borderRadius: "18px",
        border: "1px solid rgba(255,255,255,0.09)", padding: "28px 28px 24px",
        width: "440px", maxHeight: "88vh", overflowY: "auto",
        boxShadow: "0 20px 80px rgba(0,0,0,0.9)",
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "22px" }}>
          <h2 style={{ margin: 0, fontSize: "18px", fontWeight: 600, color: "#fff" }}>Settings</h2>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex" }}>
            <X size={18} />
          </button>
        </div>

        <p style={sectionLabel}>Profile picture</p>
        <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "22px" }}>
          <div style={{ width: "52px", height: "52px", borderRadius: "50%", overflow: "hidden", background: `${accent}22`, border: `1px solid ${accent}55`, display: "flex", alignItems: "center", justifyContent: "center", color: accent, fontWeight: 700, fontSize: "18px" }}>
            {avatarPreview ? <img src={avatarPreview} alt="Profile preview" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : (localStorage.getItem("phoenix.username")?.[0]?.toUpperCase() || "?")}
          </div>
          <input ref={avatarInputRef} type="file" accept="image/*" hidden onChange={e => { const file = e.target.files?.[0]; if (file) saveAvatar(file); e.currentTarget.value = ""; }} />
          <div style={{ display: "flex", gap: "7px" }}>
            <button onClick={() => avatarInputRef.current?.click()} style={{ padding: "8px 12px", borderRadius: "8px", border: `1px solid ${accent}44`, background: `${accent}14`, color: accent, cursor: "pointer", fontSize: "12px" }}>Choose image</button>
            {avatarPreview && <button onClick={() => void removeAvatar()} style={{ padding: "8px 10px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.55)", cursor: "pointer", fontSize: "12px" }}>Remove</button>}
          </div>
        </div>

        <div style={{ marginBottom: "22px", padding: "14px", borderRadius: "13px", border: "1px solid rgba(255,255,255,0.08)", background: "linear-gradient(145deg, rgba(255,255,255,0.07), rgba(255,255,255,0.025))" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "13px" }}>
            <AvatarDisplay avatarUrl={avatarPreview} name={profileDisplayName} decoration={avatarDecoration} size={34} accent={accent} />
            <div style={{ minWidth: 0 }}>
              <div style={{ color: "#fff", fontSize: "13px", fontWeight: 650, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{profileDisplayName || "Your display name"}</div>
              <div style={{ color: "rgba(255,255,255,0.35)", fontSize: "10px", marginTop: "2px" }}>Your Phoenix profile</div>
            </div>
          </div>
          <label style={{ display: "block", color: "rgba(255,255,255,0.38)", fontSize: "10px", margin: "14px 0 7px", textTransform: "uppercase", letterSpacing: "0.08em" }}>Avatar decor</label>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "6px" }}>
            {AVATAR_DECORATIONS.map(decor => (
              <button key={decor.id} onClick={() => setAvatarDecoration(decor.id)} title={decor.name} style={{ minHeight: "54px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "4px", borderRadius: "9px", border: avatarDecoration === decor.id ? `1px solid ${decor.color === "transparent" ? accent : decor.color}` : "1px solid rgba(255,255,255,0.08)", background: avatarDecoration === decor.id ? `${decor.color === "transparent" ? accent : decor.color}18` : "rgba(255,255,255,0.04)", color: decor.color === "transparent" ? "rgba(255,255,255,0.45)" : decor.color, cursor: "pointer", fontSize: "17px" }}>
                <span>{decor.emoji || "•"}</span><span style={{ fontSize: "9px", color: "rgba(255,255,255,0.48)" }}>{decor.name}</span>
              </button>
            ))}
          </div>
          <p style={{ margin: "8px 0 0", color: "rgba(255,255,255,0.27)", fontSize: "10px" }}>Decorations show around your avatar in Phoenix chat.</p>
          <label style={{ display: "block", color: "rgba(255,255,255,0.38)", fontSize: "10px", marginBottom: "5px", textTransform: "uppercase", letterSpacing: "0.08em" }}>Display name</label>
          <input value={profileDisplayName} onChange={e => setProfileDisplayName(e.target.value)} maxLength={32} placeholder="How people see you" style={{ width: "100%", boxSizing: "border-box", padding: "9px 11px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(0,0,0,0.22)", color: "#fff", outline: "none", fontSize: "12px", fontFamily: "inherit" }} />
          <label style={{ display: "flex", justifyContent: "space-between", color: "rgba(255,255,255,0.38)", fontSize: "10px", margin: "12px 0 5px", textTransform: "uppercase", letterSpacing: "0.08em" }}><span>About me</span><span>{profileBio.length}/190</span></label>
          <textarea value={profileBio} onChange={e => setProfileBio(e.target.value)} maxLength={190} rows={3} placeholder="Tell people a little about yourself" style={{ width: "100%", boxSizing: "border-box", resize: "vertical", padding: "9px 11px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(0,0,0,0.22)", color: "#fff", outline: "none", fontSize: "12px", lineHeight: 1.45, fontFamily: "inherit" }} />
          <div style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "10px" }}>
            <button onClick={() => void saveProfile()} disabled={profileSaving} style={{ padding: "8px 12px", borderRadius: "8px", border: "none", background: accent, color: "#fff", cursor: profileSaving ? "wait" : "pointer", fontSize: "11px", fontWeight: 650 }}>{profileSaving ? "Saving…" : "Save profile"}</button>
            {profileMsg && <span style={{ color: profileMsg === "Profile saved." ? "#4ade80" : "#f87171", fontSize: "10px" }}>{profileMsg}</span>}
          </div>
        </div>

        <p style={sectionLabel}>Theme</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "6px", marginBottom: "22px" }}>
          {THEME_ORDER.map(key => {
            const td = THEMES[key];
            const sel = theme === key;
            return (
              <button key={key} onClick={() => setTheme(key)} title={td.name}
                style={{
                  position: "relative", borderRadius: "10px", border: sel ? `2px solid ${td.accent}` : "2px solid transparent",
                  padding: "3px", background: "transparent", cursor: "pointer",
                  boxShadow: sel ? `0 0 10px ${td.glow}` : "none", transition: "all 0.15s",
                }}
                onMouseEnter={e => { if (!sel) e.currentTarget.style.borderColor = "rgba(255,255,255,0.2)"; }}
                onMouseLeave={e => { if (!sel) e.currentTarget.style.borderColor = "transparent"; }}
              >
                <div style={{
                  height: "44px", borderRadius: "7px", overflow: "hidden",
                  background: td.bg, position: "relative",
                }}>
                  <div style={{
                    position: "absolute", bottom: "5px", right: "5px",
                    width: "12px", height: "12px", borderRadius: "50%",
                    background: td.accent, boxShadow: `0 0 6px ${td.glow}`,
                  }} />
                </div>
                <div style={{
                  fontSize: "10px", color: sel ? td.accent : "rgba(255,255,255,0.6)",
                  textAlign: "center", marginTop: "4px", fontWeight: sel ? 600 : 400,
                  lineHeight: 1, letterSpacing: "0.01em",
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                  padding: "0 2px",
                }}>
                  {td.name}
                </div>
              </button>
            );
          })}
        </div>

        <p style={{ ...sectionLabel, marginTop: "22px" }}>Wallpaper</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "7px", marginBottom: "22px" }}>
          {WALLPAPERS.map(wp => {
            const sel = wallpaper === wp.url;
            return (
              <button key={wp.id} onClick={() => setWallpaper(wp.url)} title={wp.name}
                style={{ position: "relative", borderRadius: "10px", border: sel ? `2px solid ${accent}` : "2px solid rgba(255,255,255,0.07)", padding: "3px", background: "transparent", cursor: "pointer", transition: "all 0.15s" }}>
                <div style={{ height: "40px", borderRadius: "7px", overflow: "hidden", background: wp.url ? "transparent" : "rgba(255,255,255,0.04)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                  {wp.url ? (
                    <img src={wp.thumb} alt={wp.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} loading="lazy" onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
                  ) : (
                    <span style={{ fontSize: "16px" }}>🚫</span>
                  )}
                  {sel && <div style={{ position: "absolute", inset: 0, background: `${accent}30`, display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ fontSize: "14px" }}>✓</span></div>}
                </div>
                <div style={{ fontSize: "10px", color: sel ? accent : "rgba(255,255,255,0.5)", textAlign: "center", marginTop: "4px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", padding: "0 2px" }}>{wp.name}</div>
              </button>
            );
          })}
        </div>

        <p style={sectionLabel}>Tab Cloak</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "7px" }}>
          {CLOAKS.map(c => (
            <OptionBtn key={c.id} label={c.name} selected={cloak === c.id} accent={accent} onClick={() => setCloak(c.id)} />
          ))}
        </div>

        <div style={{ marginTop: "16px", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", background: "rgba(255,255,255,0.03)", borderRadius: "10px", border: "1px solid rgba(255,255,255,0.06)" }}>
          <div>
            <p style={{ margin: 0, fontSize: "13px", color: "#fff" }}>Auto-cloak</p>
            <p style={{ margin: "2px 0 0", fontSize: "11px", color: "rgba(255,255,255,0.35)" }}>Disguise tab when you switch away</p>
          </div>
          <button onClick={() => setAutoCloak(!autoCloak)} style={{
            width: "36px", height: "20px", borderRadius: "999px", border: "none", cursor: "pointer", position: "relative",
            background: autoCloak ? accent : "rgba(255,255,255,0.12)", transition: "background 0.15s",
          }}>
            <span style={{ position: "absolute", top: "2px", left: autoCloak ? "18px" : "2px", width: "16px", height: "16px", borderRadius: "50%", background: "#fff", transition: "left 0.15s" }} />
          </button>
        </div>

        <p style={{ ...sectionLabel, marginTop: "22px" }}>Panic Button</p>
        <div style={{ display: "flex", gap: "8px", alignItems: "center", marginBottom: "8px" }}>
          <button onClick={() => setRecordingKey(true)} style={{
            padding: "9px 14px", borderRadius: "9px", minWidth: "80px",
            border: "1px solid rgba(255,255,255,0.1)", background: recordingKey ? `${accent}22` : "rgba(255,255,255,0.05)",
            color: "#fff", fontSize: "13px", fontFamily: "monospace", cursor: "pointer",
          }} onKeyDown={e => {
            if (!recordingKey) return;
            e.preventDefault();
            if (e.key === "Escape") { setRecordingKey(false); return; }
            setPanicKey(e.key);
            setRecordingKey(false);
          }}>
            {recordingKey ? "Press a key…" : (panicKey === " " ? "Space" : panicKey)}
          </button>
          <input value={panicUrl} onChange={e => setPanicUrl(e.target.value)} placeholder="https://classroom.google.com" style={{
            flex: 1, padding: "9px 12px", borderRadius: "9px",
            border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)",
            color: "rgba(255,255,255,0.85)", fontSize: "12.5px", outline: "none", fontFamily: "inherit",
          }} />
        </div>
        <p style={{ margin: "0 0 22px", fontSize: "11px", color: "rgba(255,255,255,0.3)" }}>
          Press your chosen key anywhere to instantly redirect this tab.
        </p>

        <p style={sectionLabel}>Stealth</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginBottom: "8px" }}>
          <button onClick={onAboutBlank} style={{
            display: "flex", alignItems: "center", justifyContent: "center", gap: "8px",
            padding: "11px", borderRadius: "10px", border: "1px solid rgba(255,255,255,0.1)",
            background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.85)", fontSize: "12.5px", cursor: "pointer",
          }}>
            <ExternalLink size={13} /> Open in about:blank
          </button>
          <button onClick={onResetOnboarding} style={{
            display: "flex", alignItems: "center", justifyContent: "center", gap: "8px",
            padding: "11px", borderRadius: "10px", border: "1px solid rgba(255,255,255,0.1)",
            background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.85)", fontSize: "12.5px", cursor: "pointer",
          }}>
            <RefreshCw size={13} /> Reset onboarding
          </button>
        </div>

        <p style={{ ...sectionLabel, marginTop: "22px" }}>Change Password</p>
        <div style={{ display: "flex", flexDirection: "column", gap: "8px", marginBottom: "16px" }}>
          <input type="password" value={curPw} onChange={e => setCurPw(e.target.value)} placeholder="Current password" style={{ padding: "9px 12px", borderRadius: "9px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#fff", fontSize: "12.5px", outline: "none" }} />
          <input type="password" value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="New password (min 4 chars)" style={{ padding: "9px 12px", borderRadius: "9px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#fff", fontSize: "12.5px", outline: "none" }} />
          {pwMsg && <p style={{ margin: 0, fontSize: "11px", color: pwMsg.ok ? "#4ade80" : "#f87171" }}>{pwMsg.text}</p>}
          <button onClick={submitPw} disabled={pwLoading} style={{ padding: "9px", borderRadius: "9px", border: "none", background: "rgba(255,255,255,0.07)", color: "rgba(255,255,255,0.8)", fontSize: "12.5px", cursor: "pointer", fontWeight: 500 }}>
            {pwLoading ? "Updating…" : "Update Password"}
          </button>
        </div>

        <p style={sectionLabel}>Data</p>
        <div style={{ display: "flex", flexDirection: "column", gap: "6px", marginBottom: "16px" }}>
          <button onClick={() => { if (confirm("Clear all bookmarks?")) { localStorage.removeItem("phoenix.bookmarks"); window.location.reload(); } }}
            style={{ display: "flex", alignItems: "center", gap: "8px", padding: "9px 12px", borderRadius: "9px", border: "1px solid rgba(239,68,68,0.2)", background: "rgba(239,68,68,0.05)", color: "#f87171", fontSize: "12.5px", cursor: "pointer" }}>
            <Trash2 size={12} /> Clear bookmarks
          </button>
          <button onClick={() => { if (confirm("Clear notepad and to-do list?")) { localStorage.removeItem("phoenix.notepad"); localStorage.removeItem("phoenix.todos"); localStorage.removeItem("phoenix.gameFavorites"); localStorage.removeItem("phoenix.gameRecent"); window.location.reload(); } }}
            style={{ display: "flex", alignItems: "center", gap: "8px", padding: "9px 12px", borderRadius: "9px", border: "1px solid rgba(239,68,68,0.2)", background: "rgba(239,68,68,0.05)", color: "#f87171", fontSize: "12.5px", cursor: "pointer" }}>
            <Trash2 size={12} /> Clear personal data
          </button>
        </div>

        <button onClick={onClose} style={{
          marginTop: "4px", width: "100%", padding: "11px", borderRadius: "10px",
          background: accent, border: "none", color: "#fff",
          fontSize: "14px", fontWeight: 600, cursor: "pointer",
        }}>
          Save & Close
        </button>
      </div>
    </div>
  );
}

interface CommandAction {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  run: () => void;
}

function CommandPalette({
  accent, actions, onClose,
}: { accent: string; actions: CommandAction[]; onClose: () => void }) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? actions.filter(action => `${action.title} ${action.description}`.toLowerCase().includes(q)) : actions;
  }, [actions, query]);

  useEffect(() => {
    inputRef.current?.focus();
    setSelected(0);
  }, []);

  useEffect(() => {
    if (selected >= results.length) setSelected(Math.max(0, results.length - 1));
  }, [results.length, selected]);

  const choose = (action: CommandAction | undefined) => {
    if (!action) return;
    onClose();
    action.run();
  };

  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 200, background: "rgba(0,0,0,0.68)", backdropFilter: "blur(8px)", display: "flex", justifyContent: "center", alignItems: "flex-start", paddingTop: "clamp(72px, 14vh, 150px)" }}>
      <div onClick={e => e.stopPropagation()} style={{ width: "min(620px, calc(100vw - 28px))", overflow: "hidden", borderRadius: "18px", background: "rgba(18,18,18,0.98)", border: "1px solid rgba(255,255,255,0.12)", boxShadow: "0 24px 90px rgba(0,0,0,0.8)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "11px", padding: "15px 18px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <Search size={18} color={accent} />
          <input
            ref={inputRef}
            value={query}
            onChange={e => { setQuery(e.target.value); setSelected(0); }}
            onKeyDown={e => {
              if (e.key === "Escape") { e.preventDefault(); onClose(); }
              else if (e.key === "ArrowDown") { e.preventDefault(); setSelected(i => Math.min(i + 1, results.length - 1)); }
              else if (e.key === "ArrowUp") { e.preventDefault(); setSelected(i => Math.max(i - 1, 0)); }
              else if (e.key === "Enter") { e.preventDefault(); choose(results[selected]); }
            }}
            placeholder="Search Phoenix or jump to…"
            autoComplete="off"
            style={{ flex: 1, minWidth: 0, border: "none", outline: "none", background: "transparent", color: "#fff", font: "inherit", fontSize: "15px" }}
          />
          <kbd style={{ color: "rgba(255,255,255,0.35)", fontSize: "11px", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "6px", padding: "3px 6px" }}>ESC</kbd>
        </div>
        <div style={{ maxHeight: "min(58vh, 470px)", overflowY: "auto", padding: "8px" }}>
          {results.length === 0 ? (
            <div style={{ padding: "34px 18px", textAlign: "center", color: "rgba(255,255,255,0.35)", fontSize: "13px" }}>No matching commands</div>
          ) : results.map((action, index) => (
            <button
              key={action.id}
              onMouseEnter={() => setSelected(index)}
              onClick={() => choose(action)}
              style={{ width: "100%", display: "flex", alignItems: "center", gap: "12px", padding: "11px 12px", border: "1px solid transparent", borderRadius: "11px", background: index === selected ? `${accent}18` : "transparent", borderColor: index === selected ? `${accent}35` : "transparent", color: "#fff", textAlign: "left", cursor: "pointer" }}
            >
              <span style={{ width: "30px", height: "30px", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", borderRadius: "9px", background: index === selected ? `${accent}22` : "rgba(255,255,255,0.06)", color: index === selected ? accent : "rgba(255,255,255,0.55)" }}>{action.icon}</span>
              <span style={{ minWidth: 0, flex: 1 }}>
                <span style={{ display: "block", fontSize: "13px", fontWeight: 600 }}>{action.title}</span>
                <span style={{ display: "block", marginTop: "3px", color: "rgba(255,255,255,0.38)", fontSize: "11px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{action.description}</span>
              </span>
              {index === selected && <ArrowUp size={12} color={accent} style={{ transform: "rotate(180deg)" }} />}
            </button>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "14px", padding: "10px 16px", borderTop: "1px solid rgba(255,255,255,0.07)", color: "rgba(255,255,255,0.28)", fontSize: "10px" }}>
          <span><ArrowUp size={10} /> <ArrowDown size={10} /> Navigate</span><span>↵ Open</span><span style={{ marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: "4px" }}><CommandIcon size={10} /> K to open</span>
        </div>
      </div>
    </div>
  );
}

/* ─── Types ──────────────────────────────────────────────── */
type Stage = "boot" | "login" | "welcome" | "theme" | "cloak" | "autocloak" | "home" | "discover" | "library" | "activity" | "browser" | "games" | "movies" | "anime" | "music" | "chat" | "ai" | "html" | "credits" | "currency";

/* ═══════════════════════════════════════════════════════════
   MAIN COMPONENT
═══════════════════════════════════════════════════════════ */
function loadLS<T>(key: string, fallback: T): T {
  try { const v = localStorage.getItem(key); return v == null ? fallback : JSON.parse(v) as T; }
  catch { return fallback; }
}
function saveLS<T>(key: string, val: T) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* quota */ }
}

export default function Home() {
  const [stage, setStage] = useState<Stage>("boot");
  const [postBootStage, setPostBootStage] = useState<Stage>(() => {
    const token = localStorage.getItem("phoenix.token");
    const guest = loadLS("phoenix.guest", false);
    if (!token && !guest) return "login";
    return loadLS("phoenix.onboarded", false) ? "home" : "welcome";
  });
  const [authUser, setAuthUser] = useState<string>(() => localStorage.getItem("phoenix.username") || "");
  const [accountId, setAccountId] = useState<string>(() => localStorage.getItem("phoenix.accountId") || "");
  const [avatarUrl, setAvatarUrl] = useState<string>(() => localStorage.getItem("phoenix.avatarUrl") || "");
  const [avatarDecoration, setAvatarDecoration] = useState<AvatarDecoration>(() => (localStorage.getItem("phoenix.avatarDecoration") as AvatarDecoration | null) || "none");
  const [displayName, setDisplayName] = useState<string>(() => localStorage.getItem("phoenix.displayName") || localStorage.getItem("phoenix.username") || "");
  const [profileBio, setProfileBio] = useState<string>(() => localStorage.getItem("phoenix.bio") || "");
  const [loginTab, setLoginTab] = useState<"signin" | "signup">("signin");
  const [loginUsername, setLoginUsername] = useState("");
  const [signupDisplayName, setSignupDisplayName] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginShowPw, setLoginShowPw] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);
  const [theme, setTheme] = useState<ThemeKey>(() => loadLS<ThemeKey>("phoenix.theme", "default"));
  const [cloak, setCloak] = useState<CloakKey>(() => loadLS<CloakKey>("phoenix.cloak", "none"));
  const [autoCloak, setAutoCloak] = useState(() => loadLS("phoenix.autoCloak", false));
  const [incognito, setIncognito] = useState(false);
  const [activeNav, setActiveNav] = useState<NavId>("home");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [bookmarksOpen, setBookmarksOpen] = useState(false);
  const [urlInput, setUrlInput] = useState("");
  const [currentResult, setCurrentResult] = useState<ProxyFetchResult | null>(null);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => loadLS<Bookmark[]>("phoenix.bookmarks", []));
  const [panicKey, setPanicKey] = useState(() => loadLS("phoenix.panicKey", "`"));
  const [panicUrl, setPanicUrl] = useState(() => loadLS("phoenix.panicUrl", "https://classroom.google.com"));
  const [gameUrl, setGameUrl] = useState<string | null>(null);
  const [gameTitle, setGameTitle] = useState<string>("");
  const [gameSearch, setGameSearch] = useState("");
  const [gameGenre, setGameGenre] = useState<string>("all");

  useEffect(() => {
    const syncAvatar = () => setAvatarUrl(localStorage.getItem("phoenix.avatarUrl") || "");
    const syncProfile = () => {
      setDisplayName(localStorage.getItem("phoenix.displayName") || localStorage.getItem("phoenix.username") || "");
      setProfileBio(localStorage.getItem("phoenix.bio") || "");
      setAvatarDecoration((localStorage.getItem("phoenix.avatarDecoration") as AvatarDecoration | null) || "none");
    };
    window.addEventListener("phoenix-avatar-changed", syncAvatar);
    window.addEventListener("phoenix-profile-changed", syncProfile);
    return () => {
      window.removeEventListener("phoenix-avatar-changed", syncAvatar);
      window.removeEventListener("phoenix-profile-changed", syncProfile);
    };
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("phoenix.token");
    if (!token) return;
    fetch(`${API_BASE}/auth/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.ok ? res.json() as Promise<{ accountId?: string }> : null)
      .then(data => {
        if (data?.accountId) {
          localStorage.setItem("phoenix.accountId", data.accountId);
          setAccountId(data.accountId);
        }
      })
      .catch(() => {});
  }, []);

  const [clock, setClock] = useState(() => new Date());
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [notepadOpen, setNotepadOpen] = useState(false);
  const [notepadText, setNotepadText] = useState(() => loadLS("phoenix.notepad", ""));
  const [todos, setTodos] = useState<{ id: string; text: string; done: boolean }[]>(() => loadLS("phoenix.todos", []));
  const [todoInput, setTodoInput] = useState("");
  const [todoOpen, setTodoOpen] = useState(false);
  const [gameFavorites, setGameFavorites] = useState<GameEntry[]>(() => getGameFavorites());
  const [historySearch, setHistorySearch] = useState("");
  const [calcOpen, setCalcOpen] = useState(false);
  const [calcDisplay, setCalcDisplay] = useState("0");
  const [calcPrev, setCalcPrev] = useState("");
  const [calcOp, setCalcOp] = useState("");
  const [calcFresh, setCalcFresh] = useState(false);
  const [pomOpen, setPomOpen] = useState(false);
  const [pomMode, setPomMode] = useState<"work" | "break">("work");
  const [pomSecs, setPomSecs] = useState(25 * 60);
  const [pomRunning, setPomRunning] = useState(false);
  const [pomCycles, setPomCycles] = useState(0);
  const [wallpaper, setWallpaperState] = useState<string>(() => loadLS("phoenix.wallpaper", ""));
  const setWallpaper = (w: string) => { setWallpaperState(w); saveLS("phoenix.wallpaper", w); };

  const searchInputRef = useRef<HTMLInputElement>(null);

  const queryClient = useQueryClient();
  useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 30000 } });
  const { data: historyData } = useGetProxyHistory({ query: { queryKey: getGetProxyHistoryQueryKey() } });
  const proxyFetch = useProxyFetch();
  const clearHistory = useClearProxyHistory();

  const t = THEMES[theme];

  /* persistence */
  useEffect(() => { saveLS("phoenix.theme", theme); }, [theme]);
  useEffect(() => { saveLS("phoenix.cloak", cloak); }, [cloak]);
  useEffect(() => { saveLS("phoenix.autoCloak", autoCloak); }, [autoCloak]);
  useEffect(() => { saveLS("phoenix.bookmarks", bookmarks); }, [bookmarks]);
  useEffect(() => { saveLS("phoenix.panicKey", panicKey); }, [panicKey]);
  useEffect(() => { saveLS("phoenix.panicUrl", panicUrl); }, [panicUrl]);
  useEffect(() => { if (stage === "home" || stage === "discover" || stage === "library" || stage === "activity" || stage === "browser" || stage === "games" || stage === "movies" || stage === "anime" || stage === "music" || stage === "chat" || stage === "ai" || stage === "html" || stage === "credits" || stage === "currency") saveLS("phoenix.onboarded", true); }, [stage]);

  useEffect(() => { applyCloak(cloak); }, [cloak]);

  // Auto-cloak: disguise tab when hidden
  useEffect(() => {
    if (!autoCloak || cloak === "none") return;
    const handler = () => {
      if (document.hidden) applyCloak(cloak);
      else applyCloak("none");
    };
    document.addEventListener("visibilitychange", handler);
    return () => document.removeEventListener("visibilitychange", handler);
  }, [autoCloak, cloak]);

  // Pomodoro timer tick
  useEffect(() => {
    if (!pomRunning) return;
    const id = setInterval(() => {
      setPomSecs(s => {
        if (s <= 1) {
          setPomRunning(false);
          setPomMode(m => {
            const next = m === "work" ? "break" : "work";
            setPomSecs(next === "work" ? 25 * 60 : 5 * 60);
            if (next === "work") setPomCycles(c => c + 1);
            return next;
          });
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [pomRunning]);

  // Calculator helpers
  const calcPress = useCallback((val: string) => {
    if (val === "C") { setCalcDisplay("0"); setCalcPrev(""); setCalcOp(""); setCalcFresh(false); return; }
    if (val === "⌫") { setCalcDisplay(d => d.length > 1 ? d.slice(0, -1) : "0"); return; }
    if (["+", "-", "×", "÷"].includes(val)) {
      setCalcPrev(calcDisplay); setCalcOp(val); setCalcFresh(true); return;
    }
    if (val === "=") {
      if (!calcOp || !calcPrev) return;
      const a = parseFloat(calcPrev), b = parseFloat(calcDisplay);
      let r = 0;
      if (calcOp === "+") r = a + b;
      else if (calcOp === "-") r = a - b;
      else if (calcOp === "×") r = a * b;
      else if (calcOp === "÷") r = b === 0 ? NaN : a / b;
      setCalcDisplay(isNaN(r) ? "Error" : String(parseFloat(r.toFixed(10))));
      setCalcOp(""); setCalcPrev(""); setCalcFresh(false);
      return;
    }
    if (val === "." && calcDisplay.includes(".")) return;
    setCalcDisplay(d => {
      if (calcFresh || d === "0") { setCalcFresh(false); return val === "." ? "0." : val; }
      return d.length < 12 ? d + val : d;
    });
  }, [calcDisplay, calcOp, calcPrev, calcFresh]);

  const navigate = useCallback((url: string) => {
    let u = url.trim();
    if (!/^https?:\/\//i.test(u)) u = "https://" + u;
    setUrlInput(u);
    setHistoryOpen(false);
    setBookmarksOpen(false);
     proxyFetch.mutate({ data: { url: u } }, {
      onSuccess: (data) => {
        setCurrentResult(data);
        setStage("browser");
        if (!incognito) queryClient.invalidateQueries({ queryKey: getGetProxyHistoryQueryKey() });
       },
       onError: () => {
         setCurrentResult(null);
         setStage("browser");
       },
    });
  }, [proxyFetch, queryClient, incognito]);

  // Listen for navigation events from inside the proxied iframe
  useEffect(() => {
    const handler = (e: MessageEvent) => {
      const d = e.data as { type?: string; url?: string } | null;
      if (d && d.type === "phoenix-navigate" && typeof d.url === "string") {
        navigate(d.url);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, [navigate]);

  // Panic key: instantly redirect tab away
  useEffect(() => {
    if (!panicKey) return;
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === panicKey) {
        e.preventDefault();
        let u = panicUrl.trim() || "https://www.google.com";
        if (!/^https?:\/\//i.test(u)) u = "https://" + u;
        window.location.href = u;
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [panicKey, panicUrl]);

  // Keyboard shortcut: '/' focuses search bar on home
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCommandOpen(true);
        return;
      }
      if (e.key === "/" && stage === "home") {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
      if (e.key === "?" && !shortcutsOpen) {
        e.preventDefault();
        setShortcutsOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [stage, shortcutsOpen]);

  // Live clock ticker
  useEffect(() => {
    const interval = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  // Notepad persistence
  useEffect(() => { saveLS("phoenix.notepad", notepadText); }, [notepadText]);
  useEffect(() => { saveLS("phoenix.todos", todos); }, [todos]);

  const isCurrentBookmarked = !!currentResult && bookmarks.some(b => b.url === (currentResult.finalUrl || currentResult.url));

  const toggleBookmark = useCallback(() => {
    if (!currentResult) return;
    const url = currentResult.finalUrl || currentResult.url;
    setBookmarks(prev => prev.some(b => b.url === url)
      ? prev.filter(b => b.url !== url)
      : [...prev, { url, title: currentResult.title || url, favicon: currentResult.favicon }]);
  }, [currentResult]);

  const removeBookmark = (url: string) => setBookmarks(prev => prev.filter(b => b.url !== url));

  const openInAboutBlank = () => {
    const w = window.open("about:blank", "_blank");
    if (!w) { alert("Popup blocked. Allow popups for this site."); return; }
    const cdef = CLOAKS.find(c => c.id === cloak)!;
    const safeTitle = cdef.title.replace(/</g, "&lt;");
    const fav = cdef.favicon || "/favicon.ico";
    w.document.write(`<!doctype html><html><head><title>${safeTitle}</title><link rel="icon" href="${fav}"><style>html,body,iframe{margin:0;padding:0;border:0;width:100%;height:100%;overflow:hidden;}</style></head><body><iframe src="${window.location.href}" allow="autoplay; clipboard-read; clipboard-write"></iframe></body></html>`);
    w.document.close();
  };

  const resetOnboarding = () => {
    saveLS("phoenix.onboarded", false);
    setSettingsOpen(false);
    setStage("welcome");
  };

  const handleSearchSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    const raw = urlInput.trim();
    if (!raw) return;
    // If it looks like a search query (no dot or spaces), go to Google search
    const isUrl = /^https?:\/\//i.test(raw) || (/\./.test(raw) && !/\s/.test(raw));
    navigate(isUrl ? raw : `https://www.google.com/search?q=${encodeURIComponent(raw)}`);
  }, [urlInput, navigate]);

  const handleNavClick = (item: NavItem) => {
    if (item.id === "settings") { setSettingsOpen(true); return; }
    if (item.id === "incognito") { setIncognito(p => !p); return; }
    if (item.id === "home") { setActiveNav("home"); setStage("home"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "discover" || item.id === "library" || item.id === "activity") { setActiveNav(item.id); setStage(item.id); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "games") { setActiveNav("games"); setStage("games"); setGameUrl(null); setCurrentResult(null); proxyFetch.reset(); return; }
    if (item.id === "movies" || item.id === "tv") { setActiveNav(item.id); setStage("movies"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "friends") { setActiveNav("friends"); setStage("chat"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "ai") { setActiveNav("ai"); setStage("ai"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "anime") { setActiveNav("anime"); setStage("anime"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "music") { setActiveNav("music"); setStage("music"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "html") { setActiveNav("html"); setStage("html"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "credits") { setActiveNav("credits"); setStage("credits"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.id === "currency") { setActiveNav("currency"); setStage("currency"); setCurrentResult(null); setGameUrl(null); proxyFetch.reset(); return; }
    if (item.url) { setActiveNav(item.id); navigate(item.url); }
  };

  const launchGame = (g: GameEntry) => {
    setGameTitle(g.t);
    setGameUrl(g.u);
    addToRecentGames(g);
  };
  const exitGame = () => { setGameUrl(null); setGameTitle(""); };

  const handleClearHistory = () => {
    clearHistory.mutate(undefined, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetProxyHistoryQueryKey() }),
    });
  };

  const exitBrowser = () => {
    setCurrentResult(null); proxyFetch.reset(); setUrlInput(""); setStage("home"); setActiveNav("home");
  };

  const openWorkspaceSearch = () => {
    setActiveNav("home");
    setStage("home");
    setTimeout(() => searchInputRef.current?.focus(), 50);
  };

  const openWorkspaceDestination = (destination: "browser" | "movies" | "tv" | "anime" | "games" | "music" | "ai" | "html") => {
    handleNavClick(NAV_ITEMS.find(item => item.id === destination) ?? NAV_ITEMS[0]);
  };

  const WorkspaceShell = (mode: "discover" | "library" | "activity") => (
    <div style={{ position: "relative", width: "100%", height: "100vh", background: t.bg, color: "#fff", display: "flex", overflow: "hidden" }}>
      {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
      <Starfield particle={t.particle} color={t.particleColor} />
      {Sidebar()}
      <WorkspaceView mode={mode} accent={t.accent} onNavigate={openWorkspaceDestination} onSearch={openWorkspaceSearch} />
      {settingsOpen && (
        <SettingsModal
          theme={theme} setTheme={setTheme}
          cloak={cloak} setCloak={setCloak}
          autoCloak={autoCloak} setAutoCloak={setAutoCloak}
          panicKey={panicKey} setPanicKey={setPanicKey}
          panicUrl={panicUrl} setPanicUrl={setPanicUrl}
          wallpaper={wallpaper} setWallpaper={setWallpaper}
          accent={t.accent}
          onClose={() => setSettingsOpen(false)}
          onAboutBlank={openInAboutBlank}
          onResetOnboarding={resetOnboarding}
        />
      )}
    </div>
  );

  /* ── LOGIN ───────────────────────────────────────────────── */
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);
    const u = loginUsername.trim();
    const p = loginPassword;
    try {
      const res = await fetch(`${API_BASE}/${loginTab === "signin" ? "auth/login" : "auth/register"}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: u, password: p, ...(loginTab === "signup" && signupDisplayName.trim() ? { displayName: signupDisplayName.trim() } : {}) }),
      });
      const body = await res.text();
      let data: { accountId?: string; username?: string; displayName?: string; bio?: string; token?: string; avatarUrl?: string | null; avatarDecoration?: AvatarDecoration; error?: string } = {};
      try {
        data = JSON.parse(body) as typeof data;
      } catch {
        setLoginError(res.ok ? "The server returned an invalid response." : `Server error (${res.status}). Try again shortly.`);
        return;
      }
      if (!res.ok || !data.token) {
        setLoginError(data.error || "Something went wrong");
      } else {
        localStorage.setItem("phoenix.token", data.token!);
        localStorage.setItem("phoenix.username", data.username!);
        if (data.accountId) localStorage.setItem("phoenix.accountId", data.accountId);
        localStorage.setItem("phoenix.displayName", data.displayName || data.username!);
        localStorage.setItem("phoenix.bio", data.bio || "");
        if (data.avatarUrl) localStorage.setItem("phoenix.avatarUrl", data.avatarUrl);
        localStorage.setItem("phoenix.avatarDecoration", data.avatarDecoration || "none");
        setAvatarUrl(data.avatarUrl || "");
        setAvatarDecoration(data.avatarDecoration || "none");
        setAuthUser(data.username!);
        setAccountId(data.accountId || "");
        setDisplayName(data.displayName || data.username!);
        setProfileBio(data.bio || "");
        setLoginUsername("");
        setSignupDisplayName("");
        setLoginPassword("");
        setStage(loadLS("phoenix.onboarded", false) ? "home" : "welcome");
      }
    } catch {
      setLoginError("Unable to reach the server. Check your connection and try again.");
    } finally {
      setLoginLoading(false);
    }
  };

  if (stage === "boot") return (
    <BootScreen onDone={() => setStage(postBootStage)} />
  );

  if (stage === "login") return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: t.bg, overflow: "hidden" }}>
      <Starfield particle={t.particle} color={t.particleColor} />
      <div style={{ position: "relative", zIndex: 1, width: "360px", maxWidth: "92vw" }}>
        <div style={{ textAlign: "center", marginBottom: "24px" }}>
          <PhoenixPixelIcon size={44} />
          <h1 style={{ margin: "14px 0 4px", fontSize: "24px", fontWeight: 700, color: "#fff", letterSpacing: "-0.02em" }}>Phoenix</h1>
          <p style={{ margin: 0, fontSize: "12px", color: "rgba(255,255,255,0.3)" }}>Your portal to the open web</p>
        </div>

        <div style={{ background: "rgba(18,18,18,0.97)", borderRadius: "16px", border: "1px solid rgba(255,255,255,0.09)", boxShadow: "0 16px 64px rgba(0,0,0,0.8)", overflow: "hidden" }}>
          {/* Tabs */}
          <div style={{ display: "flex", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
            {(["signin", "signup"] as const).map(tab => (
              <button key={tab} onClick={() => { setLoginTab(tab); setLoginError(null); }}
                style={{
                  flex: 1, padding: "14px", border: "none", background: "none", cursor: "pointer",
                  fontSize: "13px", fontWeight: loginTab === tab ? 600 : 400,
                  color: loginTab === tab ? t.accent : "rgba(255,255,255,0.4)",
                  borderBottom: loginTab === tab ? `2px solid ${t.accent}` : "2px solid transparent",
                  transition: "all 0.15s",
                }}>
                {tab === "signin" ? "Sign In" : "Create Account"}
              </button>
            ))}
          </div>

          {/* Form */}
          <form onSubmit={handleAuthSubmit} style={{ padding: "24px 22px" }}>
            {loginTab === "signup" && (
              <div style={{ marginBottom: "14px" }}>
                <label style={{ display: "block", fontSize: "11px", color: "rgba(255,255,255,0.4)", marginBottom: "6px", letterSpacing: "0.05em" }}>DISPLAY NAME</label>
                <input
                  value={signupDisplayName} onChange={e => setSignupDisplayName(e.target.value)}
                  placeholder="What should people call you?"
                  autoComplete="nickname" maxLength={32}
                  style={{ width: "100%", padding: "10px 13px", borderRadius: "9px", boxSizing: "border-box", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", fontSize: "14px", outline: "none", fontFamily: "inherit" }}
                  onFocus={e => (e.currentTarget.style.borderColor = `${t.accent}66`)}
                  onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                />
                <p style={{ margin: "5px 0 0", fontSize: "10px", color: "rgba(255,255,255,0.28)" }}>You can change this later in your profile.</p>
              </div>
            )}
            <div style={{ marginBottom: "14px" }}>
              <label style={{ display: "block", fontSize: "11px", color: "rgba(255,255,255,0.4)", marginBottom: "6px", letterSpacing: "0.05em" }}>USERNAME</label>
              <input
                value={loginUsername} onChange={e => setLoginUsername(e.target.value)}
                placeholder="e.g. phoenix_user"
                autoComplete="username"
                autoFocus
                required
                style={{
                  width: "100%", padding: "10px 13px", borderRadius: "9px", boxSizing: "border-box",
                  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
                  color: "#fff", fontSize: "14px", outline: "none", fontFamily: "inherit",
                }}
                onFocus={e => (e.currentTarget.style.borderColor = `${t.accent}66`)}
                onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
              />
            </div>

            <div style={{ marginBottom: "20px" }}>
              <label style={{ display: "block", fontSize: "11px", color: "rgba(255,255,255,0.4)", marginBottom: "6px", letterSpacing: "0.05em" }}>PASSWORD</label>
              <div style={{ position: "relative" }}>
                <input
                  type={loginShowPw ? "text" : "password"}
                  value={loginPassword} onChange={e => setLoginPassword(e.target.value)}
                  placeholder={loginTab === "signup" ? "Min. 4 characters" : "Your password"}
                  autoComplete={loginTab === "signin" ? "current-password" : "new-password"}
                  required
                  style={{
                    width: "100%", padding: "10px 40px 10px 13px", borderRadius: "9px", boxSizing: "border-box",
                    background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
                    color: "#fff", fontSize: "14px", outline: "none", fontFamily: "inherit",
                  }}
                  onFocus={e => (e.currentTarget.style.borderColor = `${t.accent}66`)}
                  onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                />
                <button type="button" onClick={() => setLoginShowPw(p => !p)}
                  style={{ position: "absolute", right: "10px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex", padding: "4px" }}>
                  {loginShowPw ? <EyeOffIcon size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {loginError && (
              <div style={{ marginBottom: "14px", padding: "9px 13px", borderRadius: "8px", background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.3)", fontSize: "12px", color: "#f87171" }}>
                {loginError}
              </div>
            )}

            <button type="submit" disabled={loginLoading || !loginUsername.trim() || !loginPassword}
              style={{
                width: "100%", padding: "11px", borderRadius: "10px", border: "none",
                background: loginUsername.trim() && loginPassword ? t.accent : "rgba(255,255,255,0.08)",
                color: loginUsername.trim() && loginPassword ? "#fff" : "rgba(255,255,255,0.3)",
                fontSize: "14px", fontWeight: 600, cursor: loginUsername.trim() && loginPassword ? "pointer" : "default",
                display: "flex", alignItems: "center", justifyContent: "center", gap: "8px",
                boxShadow: loginUsername.trim() && loginPassword ? `0 0 20px ${t.glow}` : "none",
                transition: "all 0.15s",
              }}>
              {loginLoading ? (
                <div className="animate-spin" style={{ width: "16px", height: "16px", borderRadius: "50%", border: "2px solid transparent", borderTopColor: "#fff" }} />
              ) : loginTab === "signin" ? (
                <><LogIn size={15} /> Sign In</>
              ) : (
                <><UserPlus size={15} /> Create Account</>
              )}
            </button>
          </form>

          <div style={{ padding: "0 22px 20px", textAlign: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
              <div style={{ flex: 1, height: "1px", background: "rgba(255,255,255,0.07)" }} />
              <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.2)" }}>or</span>
              <div style={{ flex: 1, height: "1px", background: "rgba(255,255,255,0.07)" }} />
            </div>
            <button
              onClick={() => {
                saveLS("phoenix.guest", true);
                setStage(loadLS("phoenix.onboarded", false) ? "home" : "welcome");
              }}
              style={{
                width: "100%", padding: "10px", borderRadius: "10px",
                background: "transparent", border: "1px solid rgba(255,255,255,0.1)",
                color: "rgba(255,255,255,0.45)", fontSize: "13px", cursor: "pointer",
                transition: "all 0.15s",
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.25)"; e.currentTarget.style.color = "rgba(255,255,255,0.7)"; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; e.currentTarget.style.color = "rgba(255,255,255,0.45)"; }}
            >
              Continue as Guest
            </button>
            <p style={{ margin: "10px 0 0", fontSize: "10.5px", color: "rgba(255,255,255,0.18)", lineHeight: 1.4 }}>
              Guests can browse and watch — chat requires an account.
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  /* ── WELCOME ─────────────────────────────────────────────── */
  if (stage === "welcome") return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: t.bg, overflow: "hidden" }}>
      <Starfield particle={t.particle} color={t.particleColor} />
      <Card>
        <PhoenixPixelIcon size={48} />
        <h1 style={{ marginTop: "20px", fontSize: "22px", fontWeight: 600, color: "#fff", letterSpacing: "-0.01em" }}>Welcome to Phoenix</h1>
        <p style={{ marginTop: "10px", fontSize: "12.5px", color: "rgba(255,255,255,0.38)", lineHeight: 1.55, maxWidth: "210px" }}>
          The settings you choose can always be changed later.
        </p>
        <button onClick={() => setStage("theme")} style={{
          marginTop: "26px", padding: "9px 28px", borderRadius: "9px",
          background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.1)",
          color: "rgba(255,255,255,0.85)", fontSize: "13.5px", fontWeight: 500, cursor: "pointer",
        }}>Get Started</button>
      </Card>
    </div>
  );

  /* ── CHOOSE THEME ────────────────────────────────────────── */
  if (stage === "theme") return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: t.bg, overflow: "hidden", transition: "background 0.4s" }}>
      <Starfield particle={t.particle} color={t.particleColor} />
      <div style={{ position: "relative", zIndex: 1, background: "rgba(22,22,22,0.96)", borderRadius: "16px", border: "1px solid rgba(255,255,255,0.08)", width: "560px", maxWidth: "95vw", padding: "32px 28px 28px", boxShadow: "0 12px 60px rgba(0,0,0,0.8)" }}>
        <h1 style={{ textAlign: "center", fontSize: "22px", fontWeight: 600, color: "#fff", letterSpacing: "-0.01em", margin: "0 0 22px" }}>Choose a Theme</h1>
        <div style={{ maxHeight: "55vh", overflowY: "auto", paddingRight: "4px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "8px" }}>
            {THEME_ORDER.map(key => {
              const td = THEMES[key];
              const sel = theme === key;
              return (
                <button key={key} onClick={() => setTheme(key)} title={td.name}
                  style={{
                    borderRadius: "10px", border: sel ? `2px solid ${td.accent}` : "2px solid transparent",
                    padding: "3px", background: "transparent", cursor: "pointer",
                    boxShadow: sel ? `0 0 12px ${td.glow}` : "none", transition: "all 0.15s",
                  }}
                  onMouseEnter={e => { if (!sel) e.currentTarget.style.borderColor = "rgba(255,255,255,0.2)"; }}
                  onMouseLeave={e => { if (!sel) e.currentTarget.style.borderColor = "transparent"; }}
                >
                  <div style={{ height: "46px", borderRadius: "7px", overflow: "hidden", background: td.bg, position: "relative" }}>
                    <div style={{ position: "absolute", bottom: "5px", right: "5px", width: "12px", height: "12px", borderRadius: "50%", background: td.accent, boxShadow: `0 0 6px ${td.glow}` }} />
                  </div>
                  <div style={{ fontSize: "10px", color: sel ? td.accent : "rgba(255,255,255,0.6)", textAlign: "center", marginTop: "4px", fontWeight: sel ? 600 : 400, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", padding: "0 2px" }}>
                    {td.name}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
        <button onClick={() => setStage("cloak")} style={{
          display: "block", margin: "20px auto 0", padding: "9px 28px", borderRadius: "9px",
          background: t.accent, border: "none",
          color: "#fff", fontSize: "13.5px", fontWeight: 600, cursor: "pointer",
        }}>Continue</button>
      </div>
    </div>
  );

  /* ── CHOOSE CLOAK ────────────────────────────────────────── */
  if (stage === "cloak") return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: t.bg, overflow: "hidden" }}>
      <Starfield particle={t.particle} color={t.particleColor} />
      <Card width={340}>
        <h1 style={{ fontSize: "22px", fontWeight: 600, color: "#fff", letterSpacing: "-0.01em" }}>Choose a Cloak</h1>
        <p style={{ marginTop: "8px", fontSize: "11.5px", color: "rgba(255,255,255,0.3)", lineHeight: 1.5 }}>
          Disguise this tab as another site.
        </p>
        <div style={{ marginTop: "18px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", width: "100%" }}>
          {CLOAKS.map(c => (
            <OptionBtn key={c.id} label={c.name} selected={cloak === c.id} accent={t.accent} onClick={() => setCloak(c.id)} />
          ))}
        </div>
        <button onClick={() => setStage("autocloak")} style={{
          marginTop: "20px", padding: "9px 28px", borderRadius: "9px",
          background: "transparent", border: "none",
          color: "rgba(255,255,255,0.6)", fontSize: "13.5px", fontWeight: 500, cursor: "pointer",
        }}>Continue</button>
      </Card>
    </div>
  );

  /* ── AUTO CLOAK ──────────────────────────────────────────── */
  if (stage === "autocloak") return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: t.bg, overflow: "hidden" }}>
      <Starfield particle={t.particle} color={t.particleColor} />
      <Card width={300}>
        <h1 style={{ fontSize: "20px", fontWeight: 600, color: "#fff", letterSpacing: "-0.01em", lineHeight: 1.3 }}>Would you like to Auto Cloak?</h1>
        <p style={{ marginTop: "10px", fontSize: "12px", color: "rgba(255,255,255,0.32)", lineHeight: 1.5 }}>
          Automatically disguise this tab when you switch away from it.
        </p>
        <button onClick={() => { setAutoCloak(true); setStage("home"); }} style={{
          marginTop: "24px", width: "100%", padding: "11px 0", borderRadius: "10px",
          background: t.accent, border: "none", color: "#fff",
          fontSize: "14px", fontWeight: 600, cursor: "pointer",
        }}>Yes</button>
        <button onClick={() => { setAutoCloak(false); setStage("home"); }} style={{
          marginTop: "12px", background: "none", border: "none",
          color: "rgba(255,255,255,0.5)", fontSize: "13.5px", fontWeight: 500, cursor: "pointer",
        }}>Skip</button>
      </Card>
    </div>
  );

  /* ── SIDEBAR (shared between home and browser) ───────────── */
  const navStage = stage as Stage;
  const commandActions: CommandAction[] = [
    { id: "home", title: "Go home", description: "Open the Phoenix dashboard", icon: <HomeIcon2 size={16} />, run: () => handleNavClick(NAV_ITEMS[0]) },
    { id: "discover", title: "Discover", description: "Explore tools, media, and ideas", icon: <Compass size={16} />, run: () => handleNavClick(NAV_ITEMS[1]) },
    { id: "library", title: "Open library", description: "Continue watching and view saved items", icon: <Library size={16} />, run: () => handleNavClick(NAV_ITEMS[2]) },
    { id: "activity", title: "View activity", description: "See recent games and watch activity", icon: <Activity size={16} />, run: () => handleNavClick(NAV_ITEMS[3]) },
    { id: "movies", title: "Browse movies", description: "Search movies and TV shows", icon: <MoviesIcon size={16} />, run: () => handleNavClick(NAV_ITEMS[5]) },
    { id: "anime", title: "Browse anime", description: "Find anime series and episodes", icon: <AnimeIcon size={16} />, run: () => handleNavClick(NAV_ITEMS[7]) },
    { id: "games", title: "Play games", description: "Open your games library", icon: <GamesIcon size={16} />, run: () => handleNavClick(NAV_ITEMS[4]) },
    { id: "ai", title: "Ask PhoenixGPT", description: "Open the AI assistant", icon: <AIIcon size={16} />, run: () => handleNavClick(NAV_ITEMS[9]) },
    { id: "browser", title: "Search the web", description: "Open the browser and search bar", icon: <Search size={16} />, run: () => { setActiveNav("home"); setStage("home"); setTimeout(() => searchInputRef.current?.focus(), 50); } },
    { id: "focus", title: "Start focus timer", description: "Open the 25-minute focus timer", icon: <Timer size={16} />, run: () => { setActiveNav("home"); setStage("home"); setPomOpen(true); setTodoOpen(false); setNotepadOpen(false); } },
    { id: "notepad", title: "Open notepad", description: "Jot down a quick note", icon: <StickyNote size={16} />, run: () => { setActiveNav("home"); setStage("home"); setNotepadOpen(true); setTodoOpen(false); } },
    { id: "settings", title: "Open settings", description: "Themes, profile picture, privacy, and data", icon: <SettingsIcon2 size={16} />, run: () => setSettingsOpen(true) },
    { id: "credits", title: "Open credits", description: "See who made Phoenix", icon: <Heart size={16} />, run: () => handleNavClick(NAV_ITEMS.find(item => item.id === "credits")!) },
    { id: "currency", title: "Open AtBucks", description: "Claim rewards and shop for decorations", icon: <Coins size={16} />, run: () => handleNavClick(NAV_ITEMS.find(item => item.id === "currency")!) },
  ];
  const Sidebar = () => (
    <>
    <div className="phoenix-sidebar" style={{
      position: "relative", zIndex: 10, width: "214px", flexShrink: 0,
      background: "linear-gradient(180deg, rgba(18,18,18,0.96), rgba(9,9,9,0.94))", borderRight: "1px solid rgba(255,255,255,0.08)",
      display: "flex", flexDirection: "column", alignItems: "stretch",
      padding: "18px 12px 14px", gap: "4px",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "0 8px 18px", borderBottom: "1px solid rgba(255,255,255,0.07)", marginBottom: "8px" }}>
        <div style={{ width: "30px", height: "30px", borderRadius: "9px", background: `${t.accent}20`, border: `1px solid ${t.accent}55`, color: t.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "17px", fontWeight: 800, boxShadow: `0 0 18px ${t.accent}25` }}>✦</div>
          <div className="phoenix-sidebar-brand-copy" style={{ minWidth: 0 }}>
          <div style={{ color: "#fff", fontSize: "14px", fontWeight: 750, letterSpacing: "-0.02em" }}>Phoenix</div>
          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: "10px", marginTop: "2px" }}>{authUser ? `Signed in as ${displayName || authUser}` : "Private workspace"}</div>
          {authUser && accountId && <div style={{ color: "rgba(255,255,255,0.18)", fontSize: "9px", marginTop: "2px", letterSpacing: "0.08em" }}>{accountId}</div>}
        </div>
      </div>
      {authUser && (
        <div onClick={() => setSettingsOpen(true)} role="button" tabIndex={0} onKeyDown={e => { if (e.key === "Enter" || e.key === " ") setSettingsOpen(true); }} title="Edit profile" style={{ display: "flex", alignItems: "center", gap: "9px", padding: "8px 9px 12px", marginBottom: "4px", cursor: "pointer", borderRadius: "10px" }}>
          <AvatarDisplay avatarUrl={avatarUrl} name={displayName || authUser} decoration={avatarDecoration} size={28} accent={t.accent} />
          <span className="phoenix-sidebar-user-copy" style={{ color: "rgba(255,255,255,0.5)", fontSize: "11px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{displayName || "Personal space"}</span>
        </div>
      )}
      <div style={{ padding: "4px 10px 5px", color: "rgba(255,255,255,0.25)", fontSize: "9px", letterSpacing: "0.14em", fontWeight: 700 }}>NAVIGATION</div>
      {NAV_ITEMS.map(item => {
        const isFriends = item.id === "friends";
        const isActive =
          (item.id === activeNav && navStage === "home" && item.id === "home") ||
          (item.id === activeNav && navStage === "browser" && item.id !== "home") ||
          (item.id === "games" && navStage === "games") ||
          (item.id === "discover" && navStage === "discover") ||
          (item.id === "library" && navStage === "library") ||
          (item.id === "activity" && navStage === "activity") ||
          ((item.id === "movies" || item.id === "tv") && navStage === "movies" && item.id === activeNav) ||
          (item.id === "friends" && navStage === "chat") ||
          (item.id === "ai" && navStage === "ai") ||
          (item.id === "anime" && navStage === "anime") ||
          (item.id === "music" && navStage === "music") ||
          (item.id === "html" && navStage === "html") ||
          (item.id === "credits" && navStage === "credits") ||
          (item.id === "currency" && navStage === "currency");
        const isIncognito = item.id === "incognito" && incognito;
        return (
          <button key={item.id} title={item.label}
            onClick={() => handleNavClick(item)}
            style={{
                width: "100%", height: "39px", borderRadius: "10px", border: "1px solid transparent",
              background: isActive ? t.accent : isIncognito ? "rgba(255,255,255,0.1)" : "transparent",
              color: isActive ? "#fff" : isIncognito ? "#fff" : "rgba(255,255,255,0.35)",
                display: "flex", alignItems: "center", justifyContent: "flex-start", gap: "11px", padding: "0 11px",
              cursor: "pointer", transition: "all 0.15s",
              marginTop: item.bottom ? "auto" : 0,
              position: "relative",
            }}
            onMouseEnter={e => { if (!isActive) { e.currentTarget.style.color = "rgba(255,255,255,0.8)"; e.currentTarget.style.background = "rgba(255,255,255,0.06)"; } }}
            onMouseLeave={e => { if (!isActive) { e.currentTarget.style.color = isIncognito ? "#fff" : "rgba(255,255,255,0.35)"; e.currentTarget.style.background = isActive ? t.accent : isIncognito ? "rgba(255,255,255,0.1)" : "transparent"; } }}
          >
            {item.icon}
             <span className="phoenix-sidebar-label" style={{ fontSize: 12, fontWeight: 550, letterSpacing: "-0.01em" }}>{item.label}</span>
            {isIncognito && (
              <span style={{ position: "absolute", top: "4px", right: "4px", width: "6px", height: "6px", borderRadius: "50%", background: t.accent }} />
            )}
            {isFriends && authUser && stage !== "chat" && (
              <span style={{ position: "absolute", top: "5px", right: "5px", width: "7px", height: "7px", borderRadius: "50%", background: "#4ade80", boxShadow: "0 0 5px #4ade8099", animation: "pulse 2s infinite" }} />
            )}
          </button>
        );
      })}
    </div>
    {commandOpen && <CommandPalette accent={t.accent} actions={commandActions} onClose={() => setCommandOpen(false)} />}
    </>
  );

  if (stage === "credits") return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", overflow: "hidden", background: t.bg, color: "#fff" }}>
      {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
      <Starfield particle={t.particle} color={t.particleColor} />
      {Sidebar()}
      <main style={{ position: "relative", zIndex: 1, flex: 1, minWidth: 0, overflowY: "auto", padding: "clamp(30px, 7vh, 80px) clamp(22px, 7vw, 100px)" }}>
        <div style={{ maxWidth: "760px", margin: "0 auto" }}>
          <button onClick={() => handleNavClick(NAV_ITEMS[0])} style={{ display: "inline-flex", alignItems: "center", gap: "7px", marginBottom: "28px", padding: "8px 12px", borderRadius: "9px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.58)", cursor: "pointer", fontSize: "12px" }}>
            <ChevronLeft size={14} /> Back to Phoenix
          </button>
          <section style={{ padding: "clamp(26px, 5vw, 52px)", borderRadius: "24px", border: `1px solid ${t.accent}35`, background: "linear-gradient(145deg, rgba(30,30,30,0.92), rgba(12,12,12,0.82))", boxShadow: `0 24px 80px ${t.accent}12`, textAlign: "center" }}>
            <div style={{ width: "76px", height: "76px", margin: "0 auto 22px", borderRadius: "24px", display: "flex", alignItems: "center", justifyContent: "center", background: `${t.accent}18`, border: `1px solid ${t.accent}55`, color: t.accent, boxShadow: `0 0 34px ${t.accent}30` }}>
              <PhoenixPixelIcon size={52} />
            </div>
            <div style={{ color: t.accent, fontSize: "10px", fontWeight: 700, letterSpacing: "0.2em", textTransform: "uppercase" }}>Phoenix credits</div>
            <h1 style={{ margin: "12px 0 10px", fontSize: "clamp(30px, 5vw, 48px)", lineHeight: 1, letterSpacing: "-0.04em" }}>Made with curiosity.</h1>
            <p style={{ maxWidth: "520px", margin: "0 auto", color: "rgba(255,255,255,0.48)", fontSize: "14px", lineHeight: 1.7 }}>
              Phoenix is a personal web workspace for browsing, watching, playing, creating, and connecting in one place.
            </p>
            <div style={{ width: "100%", height: "1px", margin: "30px 0", background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.14), transparent)" }} />
            <div style={{ display: "inline-flex", alignItems: "center", gap: "10px", padding: "13px 18px", borderRadius: "14px", background: `${t.accent}12`, border: `1px solid ${t.accent}30` }}>
              <Heart size={17} fill={t.accent} color={t.accent} />
              <div style={{ textAlign: "left" }}>
                <div style={{ color: "rgba(255,255,255,0.38)", fontSize: "10px", textTransform: "uppercase", letterSpacing: "0.1em" }}>Created by</div>
                <div style={{ marginTop: "2px", color: "#fff", fontSize: "15px", fontWeight: 650 }}>PhoenixDrizz</div>
              </div>
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "8px", marginTop: "30px" }}>
              {["Smart Browser", "PhoenixGPT", "Global Chat", "Games & Media"].map(item => (
                <span key={item} style={{ padding: "7px 10px", borderRadius: "999px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.42)", fontSize: "11px" }}>{item}</span>
              ))}
            </div>
            <p style={{ margin: "28px 0 0", color: "rgba(255,255,255,0.2)", fontSize: "11px" }}>Phoenix OS · Built for the open web</p>
          </section>
        </div>
      </main>
      {settingsOpen && (
        <SettingsModal
          theme={theme} setTheme={setTheme}
          cloak={cloak} setCloak={setCloak}
          autoCloak={autoCloak} setAutoCloak={setAutoCloak}
          panicKey={panicKey} setPanicKey={setPanicKey}
          panicUrl={panicUrl} setPanicUrl={setPanicUrl}
          wallpaper={wallpaper} setWallpaper={setWallpaper}
          accent={t.accent}
          onClose={() => setSettingsOpen(false)}
          onAboutBlank={openInAboutBlank}
          onResetOnboarding={resetOnboarding}
        />
      )}
    </div>
  );

  if (stage === "currency") return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", overflow: "hidden", background: t.bg, color: "#fff" }}>
      {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
      <Starfield particle={t.particle} color={t.particleColor} />
      {Sidebar()}
      <CurrencyView
        accent={t.accent}
        glow={t.glow}
        onBack={() => handleNavClick(NAV_ITEMS[0])}
        onSignIn={() => { saveLS("phoenix.guest", false); setStage("login"); }}
        onOpenChat={() => handleNavClick(NAV_ITEMS.find(item => item.id === "friends")!)}
        onOpenProfile={() => setSettingsOpen(true)}
      />
      {settingsOpen && (
        <SettingsModal
          theme={theme} setTheme={setTheme}
          cloak={cloak} setCloak={setCloak}
          autoCloak={autoCloak} setAutoCloak={setAutoCloak}
          panicKey={panicKey} setPanicKey={setPanicKey}
          panicUrl={panicUrl} setPanicUrl={setPanicUrl}
          wallpaper={wallpaper} setWallpaper={setWallpaper}
          accent={t.accent}
          onClose={() => setSettingsOpen(false)}
          onAboutBlank={openInAboutBlank}
          onResetOnboarding={resetOnboarding}
        />
      )}
    </div>
  );

  if (stage === "discover" || stage === "library" || stage === "activity") {
    return WorkspaceShell(stage);
  }

  /* ── HOME DASHBOARD ──────────────────────────────────────── */
  if (stage === "home") return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", overflow: "hidden", background: t.bg }}>
      {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
      <Starfield particle={t.particle} color={t.particleColor} />
      {Sidebar()}

      {settingsOpen && (
        <SettingsModal
          theme={theme} setTheme={setTheme}
          cloak={cloak} setCloak={setCloak}
          autoCloak={autoCloak} setAutoCloak={setAutoCloak}
          panicKey={panicKey} setPanicKey={setPanicKey}
          panicUrl={panicUrl} setPanicUrl={setPanicUrl}
          wallpaper={wallpaper} setWallpaper={setWallpaper}
          accent={t.accent}
          onClose={() => setSettingsOpen(false)}
          onAboutBlank={openInAboutBlank}
          onResetOnboarding={resetOnboarding}
        />
      )}

      <div style={{ position: "relative", zIndex: 5, flex: 1, minWidth: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-start", padding: "clamp(34px, 7vh, 72px) clamp(20px, 5vw, 72px) 52px", overflowY: "auto" }}>
        {/* Glow behind brand */}
        <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%) translateY(-40px)", width: "400px", height: "200px", background: t.glow, borderRadius: "50%", filter: "blur(60px)", pointerEvents: "none" }} />

        {/* Live clock + greeting */}
        <div style={{ position: "relative", textAlign: "center", marginBottom: "6px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", color: "rgba(255,255,255,0.15)", fontSize: "11px", marginBottom: "2px" }}>
            <Clock size={11} />
            <span style={{ fontVariantNumeric: "tabular-nums" }}>
              {clock.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}
            </span>
          </div>
          <div style={{ fontSize: "clamp(42px, 5vw, 58px)", fontWeight: 200, color: "rgba(255,255,255,0.85)", letterSpacing: "-2px", lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>
            {clock.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </div>
          <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.3)", marginTop: "4px" }}>
            {(() => { const h = clock.getHours(); return h < 12 ? `Good morning${displayName ? ", " + displayName : ""}` : h < 17 ? `Good afternoon${displayName ? ", " + displayName : ""}` : `Good evening${displayName ? ", " + displayName : ""}`; })()}
          </div>
        </div>

        <h1 style={{
          fontSize: "clamp(52px, 8vw, 86px)", fontWeight: 800, color: t.accent,
          letterSpacing: "-0.03em", lineHeight: 1, position: "relative",
          textShadow: `0 0 80px ${t.accent}88, 0 0 120px ${t.accent}44`,
        }}>Phoenix</h1>

        <p style={{ marginTop: "8px", fontSize: "14px", color: "rgba(255,255,255,0.3)", position: "relative" }}>
          Browse the open web — freely.
          {incognito && <span style={{ marginLeft: "10px", fontSize: "11px", padding: "2px 8px", borderRadius: "20px", background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }}>Incognito</span>}
        </p>

        {/* Quote of the day */}
        <div style={{ position: "relative", marginTop: "10px", maxWidth: "400px", textAlign: "center" }}>
          <p style={{ margin: 0, fontSize: "12px", color: "rgba(255,255,255,0.2)", fontStyle: "italic", lineHeight: 1.5 }}>
            "{todayQuote.text}"
          </p>
          <p style={{ margin: "3px 0 0", fontSize: "11px", color: "rgba(255,255,255,0.12)" }}>— {todayQuote.author}</p>
        </div>

        {/* Search bar */}
        <form onSubmit={handleSearchSubmit} style={{ marginTop: "30px", width: "100%", maxWidth: "680px", position: "relative", display: "flex", alignItems: "center" }}>
          <Search style={{ position: "absolute", left: "14px", color: "rgba(255,255,255,0.3)", width: "16px", height: "16px", pointerEvents: "none" }} />
          <input
            ref={searchInputRef}
            value={urlInput}
            onChange={e => setUrlInput(e.target.value)}
            placeholder="Search or enter a URL...   ( press / )"
            autoComplete="off" spellCheck={false}
            style={{
              width: "100%", paddingLeft: "42px", paddingRight: "14px",
              paddingTop: "12px", paddingBottom: "12px",
              borderRadius: "15px", border: "1px solid rgba(255,255,255,0.12)",
              background: "rgba(10,10,10,0.5)", color: "rgba(255,255,255,0.85)",
              fontSize: "14px", outline: "none", fontFamily: "inherit", transition: "border-color 0.15s, box-shadow 0.15s", boxShadow: `0 12px 36px ${t.accent}10`,
            }}
            onFocus={e => (e.currentTarget.style.borderColor = `${t.accent}88`)}
            onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
          />
        </form>

        {/* Bookmarks row (only when present) */}
        {bookmarks.length > 0 && (
          <div style={{ marginTop: "18px", display: "flex", gap: "8px", flexWrap: "wrap", justifyContent: "center", maxWidth: "640px", position: "relative" }}>
            {bookmarks.slice(0, 12).map(b => (
              <button key={b.url} onClick={() => navigate(b.url)} disabled={proxyFetch.isPending}
                title={b.title}
                style={{
                  display: "flex", alignItems: "center", gap: "8px",
                  padding: "7px 12px", borderRadius: "999px",
                  background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)",
                  color: "rgba(255,255,255,0.75)", fontSize: "12px", cursor: "pointer",
                  maxWidth: "180px", overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis",
                  opacity: proxyFetch.isPending ? 0.5 : 1, transition: "all 0.15s",
                }}
                onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.1)"; e.currentTarget.style.borderColor = `${t.accent}55`; }}
                onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.05)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; }}
              >
                {b.favicon
                  ? <img src={b.favicon} alt="" style={{ width: "12px", height: "12px", flexShrink: 0 }} onError={e => (e.currentTarget.style.display = "none")} />
                  : <Globe size={12} style={{ flexShrink: 0, opacity: 0.5 }} />}
                <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{b.title.replace(/^https?:\/\/(www\.)?/, "")}</span>
              </button>
            ))}
          </div>
        )}

        {/* Quick links */}
        <div style={{ marginTop: "22px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(86px, 1fr))", gap: "10px", width: "100%", maxWidth: "680px", position: "relative" }}>
          {QUICK_LINKS.map(link => (
            <button key={link.label} onClick={() => navigate(link.url)}
              disabled={proxyFetch.isPending}
              style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: "6px",
                 padding: "14px 10px", borderRadius: "13px",
                background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)",
                color: "rgba(255,255,255,0.65)", fontSize: "12px", cursor: "pointer",
                transition: "all 0.15s", minWidth: "76px",
                opacity: proxyFetch.isPending ? 0.5 : 1,
              }}
              onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.08)"; e.currentTarget.style.color = "#fff"; e.currentTarget.style.borderColor = `${t.accent}44`; }}
              onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.04)"; e.currentTarget.style.color = "rgba(255,255,255,0.65)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.07)"; }}
            >
              <span style={{ fontSize: "20px" }}>{link.icon}</span>
              {link.label}
            </button>
          ))}

          {/* History button */}
          <button onClick={() => setHistoryOpen(o => !o)}
            style={{
              display: "flex", flexDirection: "column", alignItems: "center", gap: "6px",
              padding: "14px 18px", borderRadius: "14px",
              background: historyOpen ? `${t.accent}18` : "rgba(255,255,255,0.04)",
              border: historyOpen ? `1px solid ${t.accent}44` : "1px solid rgba(255,255,255,0.07)",
              color: historyOpen ? t.accent : "rgba(255,255,255,0.65)",
              fontSize: "12px", cursor: "pointer", transition: "all 0.15s", minWidth: "76px",
            }}
          >
            <History size={20} />
            History
          </button>

          {/* Calculator button */}
          <button onClick={() => setCalcOpen(o => !o)}
            style={{
              display: "flex", flexDirection: "column", alignItems: "center", gap: "6px",
              padding: "14px 18px", borderRadius: "14px",
              background: calcOpen ? `${t.accent}18` : "rgba(255,255,255,0.04)",
              border: calcOpen ? `1px solid ${t.accent}44` : "1px solid rgba(255,255,255,0.07)",
              color: calcOpen ? t.accent : "rgba(255,255,255,0.65)",
              fontSize: "12px", cursor: "pointer", transition: "all 0.15s", minWidth: "76px",
            }}
          >
            <Calculator size={20} />
            Calc
          </button>

          {/* Pomodoro button */}
          <button onClick={() => setPomOpen(o => !o)}
            style={{
              display: "flex", flexDirection: "column", alignItems: "center", gap: "6px",
              padding: "14px 18px", borderRadius: "14px",
              background: pomOpen ? `${t.accent}18` : "rgba(255,255,255,0.04)",
              border: pomOpen ? `1px solid ${t.accent}44` : "1px solid rgba(255,255,255,0.07)",
              color: pomOpen ? t.accent : "rgba(255,255,255,0.65)",
              fontSize: "12px", cursor: "pointer", transition: "all 0.15s", minWidth: "76px",
              position: "relative",
            }}
          >
            <Timer size={20} />
            Focus
            {pomRunning && <span style={{ position: "absolute", top: "6px", right: "6px", width: "7px", height: "7px", borderRadius: "50%", background: "#4ade80", boxShadow: "0 0 6px #4ade80" }} />}
          </button>
        </div>

        {/* Stats row */}
        <div style={{ marginTop: "20px", display: "flex", gap: "20px", position: "relative" }}>
          {[
            { label: "Bookmarks", value: bookmarks.length },
            { label: "Visits", value: historyData?.items?.length ?? 0 },
            { label: "Favorites", value: gameFavorites.length },
          ].map(s => (
            <div key={s.label} style={{ textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: 700, color: t.accent, lineHeight: 1 }}>{s.value}</div>
              <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.25)", marginTop: "2px", textTransform: "uppercase", letterSpacing: "0.06em" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Loading indicator */}
        {proxyFetch.isPending && (
          <div style={{ marginTop: "20px", display: "flex", alignItems: "center", gap: "10px", color: "rgba(255,255,255,0.4)", fontSize: "13px" }}>
            <div className="animate-spin" style={{ width: "14px", height: "14px", border: `2px solid ${t.accent}33`, borderTopColor: t.accent, borderRadius: "50%" }} />
            Loading...
          </div>
        )}

        {proxyFetch.isError && (
          <div style={{ marginTop: "16px", padding: "10px 16px", borderRadius: "10px", background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", display: "flex", alignItems: "center", gap: "8px" }}>
            <AlertCircle size={14} color="#ef4444" />
            <span style={{ fontSize: "12.5px", color: "rgba(255,100,100,0.9)" }}>
              {(proxyFetch.error as { error?: string })?.error ?? "Could not load that page."}
            </span>
            <button onClick={() => proxyFetch.reset()} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex", marginLeft: "4px" }}>
              <X size={12} />
            </button>
          </div>
        )}

        <p style={{ position: "absolute", bottom: "20px", fontSize: "12px", color: "rgba(255,255,255,0.15)" }}>Ready</p>
      </div>

      {/* History panel */}
      {historyOpen && (
        <div style={{
          position: "absolute", bottom: "60px", left: "50%", transform: "translateX(-50%)",
          zIndex: 20, width: "340px", borderRadius: "14px", overflow: "hidden",
          background: "rgba(16,16,16,0.98)", border: "1px solid rgba(255,255,255,0.09)",
          boxShadow: "0 8px 40px rgba(0,0,0,0.8)",
        }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
            <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)", fontWeight: 500 }}>Browsing History</span>
            <div style={{ display: "flex", gap: "10px" }}>
              <button onClick={handleClearHistory} title="Clear all" style={{ background: "none", border: "none", color: "rgba(255,255,255,0.25)", cursor: "pointer", display: "flex" }}>
                <Trash2 size={13} />
              </button>
              <button onClick={() => setHistoryOpen(false)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.25)", cursor: "pointer", display: "flex" }}>
                <X size={13} />
              </button>
            </div>
          </div>
          {/* History search */}
          <div style={{ padding: "8px 12px", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
            <input
              value={historySearch}
              onChange={e => setHistorySearch(e.target.value)}
              placeholder="Filter history..."
              style={{ width: "100%", padding: "6px 10px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "#fff", fontSize: "11px", outline: "none" }}
            />
          </div>
          <div style={{ maxHeight: "240px", overflowY: "auto" }}>
            {historyData?.items?.filter(item => !historySearch || item.title?.toLowerCase().includes(historySearch.toLowerCase()) || item.url.toLowerCase().includes(historySearch.toLowerCase())).length ? historyData!.items!.filter(item => !historySearch || item.title?.toLowerCase().includes(historySearch.toLowerCase()) || item.url.toLowerCase().includes(historySearch.toLowerCase())).map(item => (
              <button key={item.id} onClick={() => { setHistoryOpen(false); navigate(item.url); }}
                style={{ width: "100%", display: "flex", alignItems: "center", gap: "10px", padding: "10px 16px", background: "none", border: "none", borderBottom: "1px solid rgba(255,255,255,0.03)", textAlign: "left", cursor: "pointer" }}
                onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.04)")}
                onMouseLeave={e => (e.currentTarget.style.background = "none")}
              >
                <div style={{ width: "22px", height: "22px", borderRadius: "6px", background: "rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  {item.favicon ? <img src={item.favicon} alt="" style={{ width: "14px", height: "14px" }} onError={e => (e.currentTarget.style.display = "none")} /> : <Globe size={10} color="rgba(255,255,255,0.2)" />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: "12px", color: "rgba(255,255,255,0.6)", margin: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {item.title || item.url.replace(/^https?:\/\//, "")}
                  </p>
                  <p style={{ fontSize: "10px", color: "rgba(255,255,255,0.2)", margin: 0 }}>
                    {formatDistanceToNow(new Date(item.visitedAt), { addSuffix: true })}
                  </p>
                </div>
              </button>
            )) : (
              <div style={{ padding: "24px", textAlign: "center", fontSize: "12px", color: "rgba(255,255,255,0.2)" }}>No history yet</div>
            )}
          </div>
        </div>
      )}

      {/* Calculator panel */}
      {calcOpen && (
        <div style={{ position: "absolute", bottom: "60px", left: "50%", transform: "translateX(-50%) translateX(200px)", zIndex: 25, width: "220px", borderRadius: "16px", background: "rgba(14,14,14,0.98)", border: "1px solid rgba(255,255,255,0.1)", boxShadow: "0 12px 48px rgba(0,0,0,0.85)" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px 6px" }}>
            <span style={{ fontSize: "11px", fontWeight: 600, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.08em" }}>Calculator</span>
            <button onClick={() => setCalcOpen(false)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex" }}><X size={13} /></button>
          </div>
          <div style={{ padding: "4px 12px 8px", textAlign: "right" }}>
            <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.25)", minHeight: "16px" }}>{calcPrev} {calcOp}</div>
            <div style={{ fontSize: "28px", fontWeight: 300, color: "#fff", letterSpacing: "-0.02em", fontVariantNumeric: "tabular-nums", overflow: "hidden", textOverflow: "ellipsis" }}>{calcDisplay}</div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "4px", padding: "0 10px 12px" }}>
            {["C","⌫","%","÷","7","8","9","×","4","5","6","-","1","2","3","+",".",0,"=","+"].slice(0,19).map((k, i) => {
              const key = String(k);
              const isOp = ["÷","×","-","+"].includes(key);
              const isEq = key === "=";
              const isClear = key === "C" || key === "⌫";
              return (
                <button key={i} onClick={() => calcPress(key === "%" ? (String(parseFloat(calcDisplay) / 100)) : key)}
                  style={{
                    padding: "12px 0", borderRadius: "8px", border: "none", cursor: "pointer", fontSize: "14px", fontWeight: isEq ? 700 : 400,
                    background: isEq ? t.accent : isOp ? `${t.accent}28` : isClear ? "rgba(255,100,100,0.15)" : "rgba(255,255,255,0.07)",
                    color: isEq ? "#fff" : isOp ? t.accent : isClear ? "#ff8888" : "rgba(255,255,255,0.85)",
                    transition: "all 0.1s",
                  }}
                  onMouseEnter={e => { e.currentTarget.style.opacity = "0.75"; }}
                  onMouseLeave={e => { e.currentTarget.style.opacity = "1"; }}
                >{key}</button>
              );
            })}
            <button onClick={() => calcPress("0")} style={{ gridColumn: "span 1", padding: "12px 0", borderRadius: "8px", border: "none", cursor: "pointer", fontSize: "14px", background: "rgba(255,255,255,0.07)", color: "rgba(255,255,255,0.85)" }}>0</button>
            <button onClick={() => calcPress(".")} style={{ padding: "12px 0", borderRadius: "8px", border: "none", cursor: "pointer", fontSize: "14px", background: "rgba(255,255,255,0.07)", color: "rgba(255,255,255,0.85)" }}>.</button>
            <button onClick={() => calcPress("=")} style={{ gridColumn: "span 2", padding: "12px 0", borderRadius: "8px", border: "none", cursor: "pointer", fontSize: "14px", fontWeight: 700, background: t.accent, color: "#fff" }}>=</button>
          </div>
        </div>
      )}

      {/* Pomodoro / Focus timer panel */}
      {pomOpen && (
        <div style={{ position: "absolute", bottom: "60px", left: "50%", transform: "translateX(-50%) translateX(-240px)", zIndex: 25, width: "220px", borderRadius: "16px", background: "rgba(14,14,14,0.98)", border: "1px solid rgba(255,255,255,0.1)", boxShadow: "0 12px 48px rgba(0,0,0,0.85)", padding: "14px 16px 16px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}>
            <span style={{ fontSize: "11px", fontWeight: 600, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.08em" }}>Focus Timer</span>
            <button onClick={() => setPomOpen(false)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex" }}><X size={13} /></button>
          </div>
          <div style={{ display: "flex", gap: "6px", marginBottom: "14px" }}>
            {(["work", "break"] as const).map(m => (
              <button key={m} onClick={() => { setPomMode(m); setPomSecs(m === "work" ? 25 * 60 : 5 * 60); setPomRunning(false); }}
                style={{ flex: 1, padding: "6px 0", borderRadius: "8px", border: "none", cursor: "pointer", fontSize: "11px", fontWeight: 600,
                  background: pomMode === m ? t.accent : "rgba(255,255,255,0.07)",
                  color: pomMode === m ? "#fff" : "rgba(255,255,255,0.4)" }}>
                {m === "work" ? "Work" : "Break"}
              </button>
            ))}
          </div>
          <div style={{ textAlign: "center", marginBottom: "14px" }}>
            <div style={{ fontSize: "48px", fontWeight: 200, color: pomRunning ? t.accent : "rgba(255,255,255,0.85)", letterSpacing: "-2px", fontVariantNumeric: "tabular-nums", transition: "color 0.3s" }}>
              {String(Math.floor(pomSecs / 60)).padStart(2, "0")}:{String(pomSecs % 60).padStart(2, "0")}
            </div>
            <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.25)", marginTop: "4px" }}>{pomMode === "work" ? "Focus session" : "Short break"} · {pomCycles} cycles</div>
          </div>
          <div style={{ display: "flex", gap: "8px" }}>
            <button onClick={() => setPomRunning(r => !r)}
              style={{ flex: 1, padding: "10px 0", borderRadius: "10px", border: "none", cursor: "pointer", fontSize: "13px", fontWeight: 700, background: t.accent, color: "#fff" }}>
              {pomRunning ? "⏸ Pause" : "▶ Start"}
            </button>
            <button onClick={() => { setPomRunning(false); setPomSecs(pomMode === "work" ? 25 * 60 : 5 * 60); }}
              style={{ padding: "10px 14px", borderRadius: "10px", border: "none", cursor: "pointer", fontSize: "13px", background: "rgba(255,255,255,0.07)", color: "rgba(255,255,255,0.5)" }}>
              ↺
            </button>
          </div>
        </div>
      )}

      {/* Floating widget buttons (bottom-right) */}
      <div style={{ position: "absolute", bottom: "24px", right: "18px", zIndex: 20, display: "flex", flexDirection: "column", gap: "8px", alignItems: "flex-end" }}>
        <button onClick={() => setShortcutsOpen(true)} title="Keyboard shortcuts (?)"
          style={{ width: "36px", height: "36px", borderRadius: "10px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(20,20,20,0.9)", color: "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Keyboard size={15} />
        </button>
        <button onClick={() => { setTodoOpen(o => !o); setNotepadOpen(false); }} title="To-do list"
          style={{ width: "36px", height: "36px", borderRadius: "10px", border: `1px solid ${todoOpen ? t.accent + "66" : "rgba(255,255,255,0.1)"}`, background: todoOpen ? `${t.accent}22` : "rgba(20,20,20,0.9)", color: todoOpen ? t.accent : "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <CheckSquare size={15} />
        </button>
        <button onClick={() => { setNotepadOpen(o => !o); setTodoOpen(false); }} title="Notepad"
          style={{ width: "36px", height: "36px", borderRadius: "10px", border: `1px solid ${notepadOpen ? t.accent + "66" : "rgba(255,255,255,0.1)"}`, background: notepadOpen ? `${t.accent}22` : "rgba(20,20,20,0.9)", color: notepadOpen ? t.accent : "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <StickyNote size={15} />
        </button>
      </div>

      {/* Notepad widget */}
      {notepadOpen && (
        <div style={{ position: "absolute", bottom: "100px", right: "18px", zIndex: 30, width: "280px", borderRadius: "12px", background: "rgba(16,16,16,0.98)", border: "1px solid rgba(255,255,255,0.09)", boxShadow: "0 8px 40px rgba(0,0,0,0.8)" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
            <span style={{ fontSize: "12px", fontWeight: 600, color: "rgba(255,255,255,0.6)" }}>Notepad</span>
            <button onClick={() => setNotepadOpen(false)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex" }}><X size={13} /></button>
          </div>
          <textarea
            value={notepadText}
            onChange={e => setNotepadText(e.target.value)}
            placeholder="Jot something down..."
            style={{ width: "100%", height: "160px", padding: "12px 14px", background: "transparent", border: "none", color: "rgba(255,255,255,0.8)", fontSize: "12px", resize: "none", outline: "none", fontFamily: "inherit", lineHeight: 1.6, boxSizing: "border-box" }}
          />
        </div>
      )}

      {/* Todo widget */}
      {todoOpen && (
        <div style={{ position: "absolute", bottom: "100px", right: "18px", zIndex: 30, width: "280px", borderRadius: "12px", background: "rgba(16,16,16,0.98)", border: "1px solid rgba(255,255,255,0.09)", boxShadow: "0 8px 40px rgba(0,0,0,0.8)" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
            <span style={{ fontSize: "12px", fontWeight: 600, color: "rgba(255,255,255,0.6)" }}>To-Do  <span style={{ fontSize: "10px", fontWeight: 400, color: "rgba(255,255,255,0.25)" }}>{todos.filter(x => x.done).length}/{todos.length}</span></span>
            <button onClick={() => setTodoOpen(false)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex" }}><X size={13} /></button>
          </div>
          <div style={{ maxHeight: "180px", overflowY: "auto" }}>
            {todos.map(todo => (
              <div key={todo.id} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "8px 14px", borderBottom: "1px solid rgba(255,255,255,0.03)" }}>
                <button onClick={() => setTodos(prev => prev.map(x => x.id === todo.id ? { ...x, done: !x.done } : x))}
                  style={{ width: "16px", height: "16px", borderRadius: "4px", border: `1px solid ${todo.done ? t.accent : "rgba(255,255,255,0.2)"}`, background: todo.done ? t.accent : "transparent", cursor: "pointer", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {todo.done && <span style={{ color: "#fff", fontSize: "10px" }}>✓</span>}
                </button>
                <span style={{ fontSize: "12px", color: todo.done ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.7)", textDecoration: todo.done ? "line-through" : "none", flex: 1 }}>{todo.text}</span>
                <button onClick={() => setTodos(prev => prev.filter(x => x.id !== todo.id))} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.15)", cursor: "pointer", display: "flex" }}><X size={10} /></button>
              </div>
            ))}
            {todos.length === 0 && <div style={{ padding: "16px", textAlign: "center", fontSize: "11px", color: "rgba(255,255,255,0.2)" }}>No tasks yet</div>}
          </div>
          <form onSubmit={e => { e.preventDefault(); if (todoInput.trim()) { setTodos(prev => [...prev, { id: Date.now().toString(), text: todoInput.trim(), done: false }]); setTodoInput(""); } }} style={{ padding: "8px 10px", borderTop: "1px solid rgba(255,255,255,0.06)", display: "flex", gap: "6px" }}>
            <input value={todoInput} onChange={e => setTodoInput(e.target.value)} placeholder="Add task..." style={{ flex: 1, padding: "6px 10px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "#fff", fontSize: "11px", outline: "none" }} />
            <button type="submit" style={{ padding: "6px 10px", borderRadius: "6px", border: "none", background: t.accent, color: "#fff", fontSize: "11px", cursor: "pointer", fontWeight: 600 }}>+</button>
          </form>
        </div>
      )}

      {/* Keyboard shortcuts modal */}
      {shortcutsOpen && (
        <div onClick={() => setShortcutsOpen(false)} style={{ position: "fixed", inset: 0, zIndex: 50, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(6px)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div onClick={e => e.stopPropagation()} style={{ background: "rgba(16,16,16,0.99)", borderRadius: "16px", border: "1px solid rgba(255,255,255,0.09)", padding: "24px 28px", width: "360px", boxShadow: "0 20px 80px rgba(0,0,0,0.9)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "18px" }}>
              <h2 style={{ margin: 0, fontSize: "16px", fontWeight: 600, color: "#fff", display: "flex", alignItems: "center", gap: "8px" }}>
                <Keyboard size={16} color={t.accent} /> Keyboard Shortcuts
              </h2>
              <button onClick={() => setShortcutsOpen(false)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex" }}><X size={16} /></button>
            </div>
            {[
              { key: "/", desc: "Focus search bar" },
              { key: "?", desc: "Open this shortcuts panel" },
              { key: panicKey, desc: "Panic button — instant redirect" },
              { key: "Esc", desc: "Close modals / go back" },
            ].map(({ key, desc }) => (
              <div key={key} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.55)" }}>{desc}</span>
                <kbd style={{ padding: "3px 8px", borderRadius: "5px", background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)", fontSize: "12px", color: "#fff", fontFamily: "monospace" }}>{key}</kbd>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  /* ── MOVIES & TV ─────────────────────────────────────────── */
  if (stage === "movies") {
    return (
      <div style={{ position: "relative", width: "100%", height: "100vh", background: t.bg, color: "#fff", display: "flex", overflow: "hidden" }}>
        {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
        <Starfield particle={t.particle} color={t.particleColor} />
        {Sidebar()}
        <MoviesView accent={t.accent} bg="transparent" defaultTab={activeNav === "tv" ? "tv" : "movies"} />
        {settingsOpen && (
          <SettingsModal
            theme={theme} setTheme={setTheme}
            cloak={cloak} setCloak={setCloak}
            autoCloak={autoCloak} setAutoCloak={setAutoCloak}
            panicKey={panicKey} setPanicKey={setPanicKey}
            panicUrl={panicUrl} setPanicUrl={setPanicUrl}
            wallpaper={wallpaper} setWallpaper={setWallpaper}
            accent={t.accent}
            onClose={() => setSettingsOpen(false)}
            onAboutBlank={openInAboutBlank}
            onResetOnboarding={resetOnboarding}
          />
        )}
      </div>
    );
  }

  /* ── MUSIC ───────────────────────────────────────────────── */
  if (stage === "music") {
    return (
      <div style={{ position: "relative", width: "100%", height: "100vh", background: t.bg, color: "#fff", display: "flex", overflow: "hidden" }}>
        {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
        <Starfield particle={t.particle} color={t.particleColor} />
        {Sidebar()}
        <MusicView accent={t.accent} bg="transparent" />
        {settingsOpen && (
          <SettingsModal
            theme={theme} setTheme={setTheme}
            cloak={cloak} setCloak={setCloak}
            autoCloak={autoCloak} setAutoCloak={setAutoCloak}
            panicKey={panicKey} setPanicKey={setPanicKey}
            panicUrl={panicUrl} setPanicUrl={setPanicUrl}
            wallpaper={wallpaper} setWallpaper={setWallpaper}
            accent={t.accent}
            onClose={() => setSettingsOpen(false)}
            onAboutBlank={openInAboutBlank}
            onResetOnboarding={resetOnboarding}
          />
        )}
      </div>
    );
  }

  /* ── ANIME ───────────────────────────────────────────────── */
  if (stage === "anime") {
    return (
      <div style={{ position: "relative", width: "100%", height: "100vh", background: t.bg, color: "#fff", display: "flex", overflow: "hidden" }}>
        {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
        <Starfield particle={t.particle} color={t.particleColor} />
        {Sidebar()}
        <AnimeView accent={t.accent} bg="transparent" />
        {settingsOpen && (
          <SettingsModal
            theme={theme} setTheme={setTheme}
            cloak={cloak} setCloak={setCloak}
            autoCloak={autoCloak} setAutoCloak={setAutoCloak}
            panicKey={panicKey} setPanicKey={setPanicKey}
            panicUrl={panicUrl} setPanicUrl={setPanicUrl}
            wallpaper={wallpaper} setWallpaper={setWallpaper}
            accent={t.accent}
            onClose={() => setSettingsOpen(false)}
            onAboutBlank={openInAboutBlank}
            onResetOnboarding={resetOnboarding}
          />
        )}
      </div>
    );
  }

  /* ── PHOENIX GPT ─────────────────────────────────────────── */
  if (stage === "ai") {
    return (
      <div style={{ position: "relative", width: "100%", height: "100vh", background: t.bg, color: "#fff", display: "flex", overflow: "hidden" }}>
        {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
        <Starfield particle={t.particle} color={t.particleColor} />
        {Sidebar()}
        <PhoenixGPT
          accent={t.accent}
          glow={t.glow}
          onBack={() => { setStage("home"); setActiveNav("home"); }}
        />
        {settingsOpen && (
          <SettingsModal
            theme={theme} setTheme={setTheme}
            cloak={cloak} setCloak={setCloak}
            autoCloak={autoCloak} setAutoCloak={setAutoCloak}
            panicKey={panicKey} setPanicKey={setPanicKey}
            panicUrl={panicUrl} setPanicUrl={setPanicUrl}
            wallpaper={wallpaper} setWallpaper={setWallpaper}
            accent={t.accent}
            onClose={() => setSettingsOpen(false)}
            onAboutBlank={openInAboutBlank}
            onResetOnboarding={resetOnboarding}
          />
        )}
      </div>
    );
  }

  /* ── GLOBAL CHAT ─────────────────────────────────────────── */
  if (stage === "chat") {
    return (
      <div style={{ position: "relative", width: "100%", height: "100vh", background: t.bg, color: "#fff", display: "flex", overflow: "hidden" }}>
        {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
        <Starfield particle={t.particle} color={t.particleColor} />
        {Sidebar()}
        <ChatView
          accent={t.accent}
          glow={t.glow}
          onBack={() => { setStage("home"); setActiveNav("home"); }}
          onSignIn={() => { saveLS("phoenix.guest", false); setStage("login"); }}
        />
        {settingsOpen && (
          <SettingsModal
            theme={theme} setTheme={setTheme}
            cloak={cloak} setCloak={setCloak}
            autoCloak={autoCloak} setAutoCloak={setAutoCloak}
            panicKey={panicKey} setPanicKey={setPanicKey}
            panicUrl={panicUrl} setPanicUrl={setPanicUrl}
            wallpaper={wallpaper} setWallpaper={setWallpaper}
            accent={t.accent}
            onClose={() => setSettingsOpen(false)}
            onAboutBlank={openInAboutBlank}
            onResetOnboarding={resetOnboarding}
          />
        )}
      </div>
    );
  }

  /* ── HTML VIEWER ─────────────────────────────────────────── */
  if (stage === "html") {
    return (
      <div style={{ position: "relative", width: "100%", height: "100vh", background: t.bg, color: "#fff", display: "flex", overflow: "hidden" }}>
        {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
        <Starfield particle={t.particle} color={t.particleColor} />
        {Sidebar()}
        <HtmlView accent={t.accent} bg="transparent" />
        {settingsOpen && (
          <SettingsModal
            theme={theme} setTheme={setTheme}
            cloak={cloak} setCloak={setCloak}
            autoCloak={autoCloak} setAutoCloak={setAutoCloak}
            panicKey={panicKey} setPanicKey={setPanicKey}
            panicUrl={panicUrl} setPanicUrl={setPanicUrl}
            wallpaper={wallpaper} setWallpaper={setWallpaper}
            accent={t.accent}
            onClose={() => setSettingsOpen(false)}
            onAboutBlank={openInAboutBlank}
            onResetOnboarding={resetOnboarding}
          />
        )}
      </div>
    );
  }

  /* ── GAMES LIBRARY ───────────────────────────────────────── */
  if (stage === "games") {
    const q = gameSearch.trim().toLowerCase();
    const filtered = GAMES.filter(g =>
      (gameGenre === "all" || g.g === gameGenre) &&
      (q === "" || g.t.toLowerCase().includes(q))
    );
    return (
      <div style={{ position: "relative", width: "100%", height: "100vh", background: t.bg, color: "#fff", display: "flex", overflow: "hidden" }}>
        {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
        <Starfield particle={t.particle} color={t.particleColor} />
        {Sidebar()}

        <div style={{ flex: 1, position: "relative", display: "flex", flexDirection: "column", minWidth: 0 }}>
          {/* Header bar */}
          <div style={{ padding: "16px 22px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", gap: "12px", background: "rgba(0,0,0,0.35)", backdropFilter: "blur(10px)", zIndex: 5 }}>
            {gameUrl && (
              <button onClick={exitGame} title="Back to library"
                style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", fontSize: "12px", cursor: "pointer" }}>
                <X size={13} /> Back
              </button>
            )}
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <GamesIcon size={20} color={t.accent} />
              <span style={{ fontSize: "16px", fontWeight: 600, letterSpacing: "0.3px" }}>
                {gameUrl ? gameTitle : "Games"}
              </span>
              {!gameUrl && (
                <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)", marginLeft: "4px" }}>
                  {filtered.length} of {GAMES.length}
                </span>
              )}
            </div>

            {!gameUrl && (
              <>
                <div style={{ flex: 1, position: "relative", maxWidth: "360px", marginLeft: "auto" }}>
                  <Search style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.3)", width: "14px", height: "14px", pointerEvents: "none" }} />
                  <input
                    value={gameSearch}
                    onChange={e => setGameSearch(e.target.value)}
                    placeholder="Search games..."
                    autoComplete="off" spellCheck={false}
                    style={{
                      width: "100%", padding: "8px 12px 8px 34px",
                      borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)",
                      background: "rgba(255,255,255,0.04)", color: "#fff", outline: "none", fontSize: "12px",
                    }}
                    onFocus={e => (e.currentTarget.style.borderColor = `${t.accent}66`)}
                    onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                  />
                </div>
                <select value={gameGenre} onChange={e => setGameGenre(e.target.value)}
                  style={{
                    padding: "8px 10px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)",
                    background: "rgba(255,255,255,0.04)", color: "#fff", fontSize: "12px",
                    cursor: "pointer", outline: "none",
                  }}>
                  {GENRES.map(g => (
                    <option key={g} value={g} style={{ background: "#1a1a1a" }}>
                      {g === "all" ? "All genres" : g.charAt(0).toUpperCase() + g.slice(1)}
                    </option>
                  ))}
                </select>
              </>
            )}
            {gameUrl && (
              <button onClick={() => window.open(gameUrl, "_blank", "noopener,noreferrer")} title="Open in new tab"
                style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", fontSize: "12px", cursor: "pointer" }}>
                <ExternalLink size={12} /> New tab
              </button>
            )}
          </div>

          {/* Body */}
          {gameUrl ? (
            <div style={{ flex: 1, position: "relative", background: "#000" }}>
              <iframe
                src={gameUrl}
                style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: "none", background: "#000" }}
                allow="autoplay; fullscreen; gamepad; pointer-lock; clipboard-read; clipboard-write"
                allowFullScreen
                title={gameTitle}
              />
            </div>
          ) : (
            <div style={{ flex: 1, overflowY: "auto", padding: "20px 22px", position: "relative" }}>
              {/* Favorites shelf */}
              {gameFavorites.length > 0 && !gameSearch && gameGenre === "all" && (
                <div style={{ marginBottom: "28px" }}>
                  <p style={{ margin: "0 0 10px", fontSize: "13px", fontWeight: 600, color: "rgba(255,255,255,0.7)", display: "flex", alignItems: "center", gap: "6px" }}>
                    <Star size={13} fill={t.accent} color={t.accent} /> Favorites
                  </p>
                  <div style={{ display: "flex", gap: "10px", overflowX: "auto", paddingBottom: "4px" }}>
                    {gameFavorites.map(g => (
                      <button key={g.u} onClick={() => launchGame(g)} title={g.t}
                        style={{ flexShrink: 0, width: "120px", aspectRatio: "1 / 1", borderRadius: "10px", overflow: "hidden", background: (g as GameEntry & { i?: string }).i ? "#111" : `linear-gradient(135deg, ${t.accent}33, ${t.accent}11)`, border: `1px solid ${t.accent}44`, cursor: "pointer", padding: 0, display: "flex", flexDirection: "column", justifyContent: "flex-end", position: "relative" }}>
                        {(g as GameEntry & { i?: string }).i && <img src={(g as GameEntry & { i?: string }).i} alt="" loading="lazy" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />}
                        <div style={{ position: "relative", zIndex: 1, padding: "6px 8px", background: "linear-gradient(to top, rgba(0,0,0,0.85), transparent)", color: "#fff", fontSize: "11px", fontWeight: 500, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>{g.t}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {/* Recently Played shelf */}
              {getRecentGames().length > 0 && !gameSearch && gameGenre === "all" && (
                <div style={{ marginBottom: "28px" }}>
                  <p style={{ margin: "0 0 10px", fontSize: "13px", fontWeight: 600, color: "rgba(255,255,255,0.7)", display: "flex", alignItems: "center", gap: "6px" }}>
                    <Clock size={13} color="rgba(255,255,255,0.5)" /> Recently Played
                  </p>
                  <div style={{ display: "flex", gap: "10px", overflowX: "auto", paddingBottom: "4px" }}>
                    {getRecentGames().map(g => (
                      <button key={g.u} onClick={() => launchGame(g)} title={g.t}
                        style={{ flexShrink: 0, width: "120px", aspectRatio: "1 / 1", borderRadius: "10px", overflow: "hidden", background: (g as GameEntry & { i?: string }).i ? "#111" : `linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.03))`, border: "1px solid rgba(255,255,255,0.1)", cursor: "pointer", padding: 0, display: "flex", flexDirection: "column", justifyContent: "flex-end", position: "relative" }}>
                        {(g as GameEntry & { i?: string }).i && <img src={(g as GameEntry & { i?: string }).i} alt="" loading="lazy" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />}
                        <div style={{ position: "relative", zIndex: 1, padding: "6px 8px", background: "linear-gradient(to top, rgba(0,0,0,0.85), transparent)", color: "#fff", fontSize: "11px", fontWeight: 500, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>{g.t}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {filtered.length === 0 ? (
                <div style={{ textAlign: "center", padding: "60px 20px", color: "rgba(255,255,255,0.4)", fontSize: "13px" }}>
                  No games match "{gameSearch}".
                </div>
              ) : (
                <>
                  {(gameSearch || gameGenre !== "all") ? null : (
                    <p style={{ margin: "0 0 10px", fontSize: "13px", fontWeight: 600, color: "rgba(255,255,255,0.7)" }}>All Games</p>
                  )}
                  <div style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
                    gap: "12px",
                  }}>
                    {filtered.map(g => {
                      const isFav = gameFavorites.some(f => f.u === g.u);
                      return (
                        <div key={g.u} style={{ position: "relative" }}>
                          <button onClick={() => launchGame(g)}
                            title={g.t}
                            style={{
                              width: "100%", position: "relative", aspectRatio: "1 / 1",
                              borderRadius: "10px", overflow: "hidden",
                              background: g.i ? `#111` : `linear-gradient(135deg, ${t.accent}33, ${t.accent}11)`,
                              border: isFav ? `1px solid ${t.accent}66` : "1px solid rgba(255,255,255,0.08)",
                              cursor: "pointer", padding: 0, display: "flex",
                              flexDirection: "column", justifyContent: "flex-end",
                              transition: "transform 0.15s, border-color 0.15s, box-shadow 0.15s",
                            }}
                            onMouseEnter={e => {
                              e.currentTarget.style.transform = "translateY(-2px)";
                              e.currentTarget.style.borderColor = `${t.accent}88`;
                              e.currentTarget.style.boxShadow = `0 8px 24px ${t.accent}33`;
                            }}
                            onMouseLeave={e => {
                              e.currentTarget.style.transform = "none";
                              e.currentTarget.style.borderColor = isFav ? `${t.accent}66` : "rgba(255,255,255,0.08)";
                              e.currentTarget.style.boxShadow = "none";
                            }}
                          >
                            {g.i && (
                              <img src={g.i} alt="" loading="lazy"
                                style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
                                onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
                            )}
                            <div style={{
                              position: "relative", zIndex: 1,
                              padding: "8px 10px",
                              background: "linear-gradient(to top, rgba(0,0,0,0.85), rgba(0,0,0,0))",
                              color: "#fff", fontSize: "12px", fontWeight: 500,
                              textAlign: "left", textTransform: "capitalize",
                              textOverflow: "ellipsis", overflow: "hidden", whiteSpace: "nowrap",
                            }}>
                              {g.t}
                            </div>
                          </button>
                          {/* Favorite star button */}
                          <button
                            onClick={e => { e.stopPropagation(); const nowFav = toggleGameFavorite(g); setGameFavorites(getGameFavorites()); void nowFav; }}
                            title={isFav ? "Remove from favorites" : "Add to favorites"}
                            style={{
                              position: "absolute", top: "6px", right: "6px", zIndex: 5,
                              width: "26px", height: "26px", borderRadius: "6px",
                              background: "rgba(0,0,0,0.6)", border: `1px solid ${isFav ? t.accent + "88" : "rgba(255,255,255,0.15)"}`,
                              cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
                            }}>
                            <Star size={12} fill={isFav ? t.accent : "none"} color={isFav ? t.accent : "rgba(255,255,255,0.5)"} />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {settingsOpen && (
          <SettingsModal
            theme={theme} setTheme={setTheme}
            cloak={cloak} setCloak={setCloak}
            autoCloak={autoCloak} setAutoCloak={setAutoCloak}
            panicKey={panicKey} setPanicKey={setPanicKey}
            panicUrl={panicUrl} setPanicUrl={setPanicUrl}
            wallpaper={wallpaper} setWallpaper={setWallpaper}
            accent={t.accent}
            onClose={() => setSettingsOpen(false)}
            onAboutBlank={openInAboutBlank}
            onResetOnboarding={resetOnboarding}
          />
        )}
      </div>
    );
  }

  /* ── BROWSER VIEW ────────────────────────────────────────── */
  const isLoaded = !!currentResult && !proxyFetch.isPending && !proxyFetch.isError;

  return (
    <div style={{ position: "relative", width: "100%", height: "100vh", display: "flex", overflow: "hidden", background: t.bg }}>
      {wallpaper && <div style={{ position: "fixed", inset: 0, zIndex: 0, backgroundImage: `url(${wallpaper})`, backgroundSize: "cover", backgroundPosition: "center", filter: "brightness(0.35) saturate(1.2)", pointerEvents: "none" }} />}
      <Starfield particle={t.particle} color={t.particleColor} />
      {Sidebar()}

      {settingsOpen && (
        <SettingsModal
          theme={theme} setTheme={setTheme}
          cloak={cloak} setCloak={setCloak}
          autoCloak={autoCloak} setAutoCloak={setAutoCloak}
          panicKey={panicKey} setPanicKey={setPanicKey}
          panicUrl={panicUrl} setPanicUrl={setPanicUrl}
          wallpaper={wallpaper} setWallpaper={setWallpaper}
          accent={t.accent}
          onClose={() => setSettingsOpen(false)}
          onAboutBlank={openInAboutBlank}
          onResetOnboarding={resetOnboarding}
        />
      )}

      <div style={{ position: "relative", zIndex: 5, flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Address bar */}
        <div style={{
          height: "48px", flexShrink: 0, display: "flex", alignItems: "center", gap: "10px", padding: "0 14px",
          background: "rgba(14,14,14,0.98)", borderBottom: "1px solid rgba(255,255,255,0.07)",
        }}>
          <button onClick={exitBrowser} title="Home" style={{ background: "none", border: "none", cursor: "pointer", display: "flex", padding: "4px", flexShrink: 0 }}>
            <PhoenixPixelIcon size={22} />
          </button>

          <div style={{
            flex: 1, display: "flex", alignItems: "center", gap: "8px", padding: "5px 12px",
            borderRadius: "9px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)",
            minWidth: 0, overflow: "hidden",
          }}>
            <Lock size={13} color={`${t.accent}cc`} style={{ flexShrink: 0 }} />
            <span style={{ fontSize: "12px", fontFamily: "monospace", color: "rgba(255,255,255,0.35)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {currentResult?.finalUrl ?? urlInput}
            </span>
          </div>

          <form onSubmit={handleSearchSubmit} style={{ display: "flex", gap: "8px", alignItems: "center", flexShrink: 0 }}>
            <input value={urlInput} onChange={e => setUrlInput(e.target.value)} placeholder="Go to URL or search..."
              style={{
                width: "180px", padding: "6px 12px", borderRadius: "8px",
                border: "1px solid rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.04)",
                color: "rgba(255,255,255,0.7)", fontSize: "12px", fontFamily: "monospace", outline: "none",
              }} />
            <button type="submit" disabled={proxyFetch.isPending} style={{
              padding: "6px 14px", borderRadius: "8px", border: `1px solid ${t.accent}55`,
              background: `${t.accent}18`, color: t.accent, fontSize: "12px", fontWeight: 500, cursor: "pointer",
              opacity: proxyFetch.isPending ? 0.6 : 1,
            }}>Go</button>
          </form>

          <button onClick={() => proxyFetch.isPending ? undefined : navigate(urlInput)} title="Reload"
            style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.3)", display: "flex" }}>
            <RefreshCw size={15} className={proxyFetch.isPending ? "animate-spin" : ""} />
          </button>

          <button onClick={toggleBookmark} title={isCurrentBookmarked ? "Remove bookmark" : "Bookmark this page"} disabled={!currentResult}
            style={{ background: "none", border: "none", cursor: currentResult ? "pointer" : "default", color: isCurrentBookmarked ? t.accent : "rgba(255,255,255,0.3)", display: "flex" }}>
            <Star size={15} fill={isCurrentBookmarked ? t.accent : "none"} />
          </button>

          <button onClick={() => { setBookmarksOpen(o => !o); setHistoryOpen(false); }} title="Bookmarks"
            style={{ background: "none", border: "none", cursor: "pointer", color: bookmarksOpen ? t.accent : "rgba(255,255,255,0.3)", display: "flex" }}>
            <BookmarkIcon size={15} />
          </button>

          <button onClick={() => { setHistoryOpen(o => !o); setBookmarksOpen(false); }} title="History"
            style={{ background: "none", border: "none", cursor: "pointer", color: historyOpen ? t.accent : "rgba(255,255,255,0.3)", display: "flex" }}>
            <History size={15} />
          </button>

          {incognito && (
            <div style={{ display: "flex", alignItems: "center", gap: "4px", padding: "3px 8px", borderRadius: "20px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}>
              <EyeOff size={10} color="rgba(255,255,255,0.4)" />
              <span style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)" }}>Incognito</span>
            </div>
          )}
        </div>

        {/* Bookmarks dropdown */}
        {bookmarksOpen && (
          <div style={{
            position: "absolute", top: "50px", right: "14px", zIndex: 20, width: "300px",
            borderRadius: "12px", overflow: "hidden", background: "rgba(16,16,16,0.98)",
            border: "1px solid rgba(255,255,255,0.09)", boxShadow: "0 8px 40px rgba(0,0,0,0.8)",
          }}>
            <div style={{ padding: "9px 14px", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
              <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.35)" }}>Bookmarks ({bookmarks.length})</span>
            </div>
            <div style={{ maxHeight: "260px", overflowY: "auto" }}>
              {bookmarks.length === 0 && (
                <div style={{ padding: "20px", textAlign: "center", fontSize: "12px", color: "rgba(255,255,255,0.2)" }}>
                  No bookmarks yet — click the star to save the current page.
                </div>
              )}
              {bookmarks.map(b => (
                <div key={b.url} style={{ display: "flex", alignItems: "center", borderBottom: "1px solid rgba(255,255,255,0.03)" }}>
                  <button onClick={() => { setBookmarksOpen(false); navigate(b.url); }}
                    style={{ flex: 1, display: "flex", alignItems: "center", gap: "8px", padding: "9px 14px", background: "none", border: "none", textAlign: "left", cursor: "pointer", overflow: "hidden" }}
                    onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.04)")}
                    onMouseLeave={e => (e.currentTarget.style.background = "none")}
                  >
                    {b.favicon
                      ? <img src={b.favicon} alt="" style={{ width: "12px", height: "12px", flexShrink: 0 }} onError={e => (e.currentTarget.style.display = "none")} />
                      : <Globe size={12} color="rgba(255,255,255,0.25)" style={{ flexShrink: 0 }} />}
                    <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.55)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {b.title.replace(/^https?:\/\//, "")}
                    </span>
                  </button>
                  <button onClick={() => removeBookmark(b.url)} title="Remove"
                    style={{ background: "none", border: "none", padding: "8px 12px", color: "rgba(255,255,255,0.25)", cursor: "pointer", display: "flex" }}>
                    <X size={11} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* History dropdown */}
        {historyOpen && (
          <div style={{
            position: "absolute", top: "50px", right: "14px", zIndex: 20, width: "280px",
            borderRadius: "12px", overflow: "hidden", background: "rgba(16,16,16,0.98)",
            border: "1px solid rgba(255,255,255,0.09)", boxShadow: "0 8px 40px rgba(0,0,0,0.8)",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 14px", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
              <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.35)" }}>History</span>
              <button onClick={handleClearHistory} style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.2)", display: "flex" }}>
                <Trash2 size={12} />
              </button>
            </div>
            <div style={{ maxHeight: "240px", overflowY: "auto" }}>
              {historyData?.items?.map(item => (
                <button key={item.id} onClick={() => { setHistoryOpen(false); navigate(item.url); }}
                  style={{ width: "100%", display: "flex", alignItems: "center", gap: "8px", padding: "9px 14px", background: "none", border: "none", borderBottom: "1px solid rgba(255,255,255,0.03)", textAlign: "left", cursor: "pointer" }}
                  onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.04)")}
                  onMouseLeave={e => (e.currentTarget.style.background = "none")}
                >
                  <Globe size={12} color="rgba(255,255,255,0.2)" style={{ flexShrink: 0 }} />
                  <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.45)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {item.title || item.url.replace(/^https?:\/\//, "")}
                  </span>
                </button>
              ))}
              {!historyData?.items?.length && (
                <div style={{ padding: "20px", textAlign: "center", fontSize: "12px", color: "rgba(255,255,255,0.2)" }}>No history</div>
              )}
            </div>
          </div>
        )}

        {/* Page content */}
        <div style={{ flex: 1, overflow: "hidden", position: "relative" }}>
          {proxyFetch.isPending && (
            <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
              <div style={{ position: "relative", width: "52px", height: "52px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div style={{ position: "absolute", inset: 0, borderRadius: "50%", border: `2px solid ${t.accent}20` }} />
                <div className="animate-spin" style={{ position: "absolute", inset: 0, borderRadius: "50%", border: "2px solid transparent", borderTopColor: t.accent }} />
                <PhoenixPixelIcon size={24} />
              </div>
              <p style={{ marginTop: "14px", fontSize: "13px", color: "rgba(255,255,255,0.5)" }}>Loading...</p>
              <p style={{ marginTop: "4px", fontSize: "11px", color: "rgba(255,255,255,0.2)", maxWidth: "200px", textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{urlInput}</p>
            </div>
          )}

          {proxyFetch.isError && (
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <div style={{ background: "rgba(20,20,20,0.96)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "14px", padding: "36px", textAlign: "center", width: "320px" }}>
                <AlertCircle size={32} color="#ef4444" style={{ margin: "0 auto" }} />
                <p style={{ marginTop: "14px", fontSize: "15px", fontWeight: 600, color: "#fff" }}>Could Not Load Page</p>
                <p style={{ marginTop: "8px", fontSize: "12px", color: "rgba(255,255,255,0.35)", lineHeight: 1.5 }}>
                  {(proxyFetch.error as { error?: string })?.error ?? "This site couldn't be proxied."}
                </p>
                <div style={{ display: "flex", gap: "10px", justifyContent: "center", marginTop: "20px" }}>
                  <button onClick={() => navigate(urlInput)} style={{ display: "flex", alignItems: "center", gap: "6px", padding: "8px 16px", borderRadius: "8px", background: `${t.accent}18`, border: `1px solid ${t.accent}44`, color: t.accent, fontSize: "12px", cursor: "pointer" }}>
                    <RefreshCw size={12} /> Retry
                  </button>
                  <button onClick={exitBrowser} style={{ display: "flex", alignItems: "center", gap: "6px", padding: "8px 16px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.09)", color: "rgba(255,255,255,0.6)", fontSize: "12px", cursor: "pointer" }}>
                    <X size={12} /> Back
                  </button>
                </div>
              </div>
            </div>
          )}

          {isLoaded && (
            <iframe srcDoc={currentResult.html}
              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: "none", background: "#fff" }}
              allow="autoplay; clipboard-read; clipboard-write; fullscreen; payment; microphone; camera; geolocation; accelerometer; gyroscope"
              allowFullScreen
              title="Proxied Content"
            />
          )}
        </div>
      </div>
    </div>
  );
}
