import { useState, useEffect, useCallback, useRef } from "react";
import { Search, X, ExternalLink, Star, Film, Tv2, Play, ChevronLeft, ChevronRight, RefreshCw, Download, Heart, Shuffle } from "lucide-react";
import { saveToHistory, getWatchHistory, removeFromHistory, formatProgress, type WatchEntry } from "../lib/watch-history";
import { toggleMovieWatchlist, isInMovieWatchlist, getMovieWatchlist, type WatchlistItem } from "../lib/watchlist";

const API_BASE = `${import.meta.env.BASE_URL || "/"}api`.replace("//api", "/api");

export interface MediaItem {
  id: number;
  imdb_id?: string | null;
  title: string;
  poster: string | null;
  backdrop: string | null;
  year: string;
  rating: number;
  overview: string;
  kind: "movie" | "tv";
}

interface SeasonInfo {
  season_number: number;
  name: string;
  episode_count: number;
  poster: string | null;
}
interface EpisodeInfo {
  episode_number: number;
  name: string;
  overview: string;
  still: string | null;
  runtime: number | null;
  air_date: string | null;
}

const MOVIE_CATEGORIES: { id: string; label: string; endpoint: string }[] = [
  { id: "trending", label: "Trending Now", endpoint: "/movies/trending" },
  { id: "popular", label: "Popular Movies", endpoint: "/movies/discover?cat=popular" },
  { id: "top_rated", label: "Top Rated", endpoint: "/movies/discover?cat=top_rated" },
  { id: "now_playing", label: "Now Playing", endpoint: "/movies/discover?cat=now_playing" },
  { id: "upcoming", label: "Upcoming", endpoint: "/movies/discover?cat=upcoming" },
];

const TV_CATEGORIES: { id: string; label: string; endpoint: string }[] = [
  { id: "tv_popular", label: "Popular TV Shows", endpoint: "/tv/discover?cat=popular" },
  { id: "tv_top_rated", label: "Top Rated TV", endpoint: "/tv/discover?cat=top_rated" },
  { id: "tv_on_air", label: "On The Air", endpoint: "/tv/discover?cat=on_the_air" },
  { id: "tv_today", label: "Airing Today", endpoint: "/tv/discover?cat=airing_today" },
];

const MOVIE_GENRES: { id: number; name: string }[] = [
  { id: 28, name: "Action" }, { id: 12, name: "Adventure" }, { id: 16, name: "Animation" },
  { id: 35, name: "Comedy" }, { id: 80, name: "Crime" }, { id: 99, name: "Documentary" },
  { id: 18, name: "Drama" }, { id: 10751, name: "Family" }, { id: 14, name: "Fantasy" },
  { id: 36, name: "History" }, { id: 27, name: "Horror" }, { id: 10402, name: "Music" },
  { id: 9648, name: "Mystery" }, { id: 10749, name: "Romance" }, { id: 878, name: "Sci-Fi" },
  { id: 53, name: "Thriller" }, { id: 10752, name: "War" }, { id: 37, name: "Western" },
];

interface MoviesViewProps {
  accent: string;
  bg: string;
  defaultTab?: "movies" | "tv";
}

interface PlayerState {
  item: MediaItem;
  season?: number;
  episode?: number;
  providerIdx: number;
}

const PROVIDERS = [
  { name: "Videasy", build: (i: MediaItem, s?: number, e?: number, color = "ff4ecd") =>
      i.kind === "movie"
        ? `https://player.videasy.to/movie/${i.id}?color=${color}&autoplay=true`
        : `https://player.videasy.to/tv/${i.id}/${s ?? 1}/${e ?? 1}?color=${color}&autoplay=true&nextEpisode=true` },
  { name: "VidSrc", build: (i: MediaItem, s?: number, e?: number) =>
      i.kind === "movie"
        ? `https://vidsrc.to/embed/movie/${i.id}`
        : `https://vidsrc.to/embed/tv/${i.id}/${s ?? 1}/${e ?? 1}` },
  { name: "VidSrc Mirror", build: (i: MediaItem, s?: number, e?: number) =>
      i.kind === "movie"
        ? `https://vidsrc.tw/embed/movie/${i.id}`
        : `https://vidsrc.tw/embed/tv/${i.id}/${s ?? 1}/${e ?? 1}` },
  { name: "VidLink", build: (i: MediaItem, s?: number, e?: number, color = "ff4ecd") =>
      i.kind === "movie"
        ? `https://vidlink.pro/movie/${i.id}?primaryColor=${color}&autoplay=true`
        : `https://vidlink.pro/tv/${i.id}/${s ?? 1}/${e ?? 1}?primaryColor=${color}&autoplay=true` },
  { name: "MultiEmbed", build: (i: MediaItem, s?: number, e?: number) =>
      i.kind === "movie"
        ? `https://multiembed.mov/?video_id=${i.id}&tmdb=1`
        : `https://multiembed.mov/?video_id=${i.id}&tmdb=1&s=${s ?? 1}&e=${e ?? 1}` },
];

export default function MoviesView({ accent, bg, defaultTab }: MoviesViewProps) {
  const [tab, setTab] = useState<"movies" | "tv" | "search" | "genre">(defaultTab ?? "movies");
  const [rows, setRows] = useState<Record<string, MediaItem[]>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQ, setSearchQ] = useState("");
  const [searchResults, setSearchResults] = useState<MediaItem[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [genreId, setGenreId] = useState<number | null>(null);
  const [genreItems, setGenreItems] = useState<MediaItem[]>([]);
  const [genrePage, setGenrePage] = useState(1);
  const [genreTotal, setGenreTotal] = useState(1);
  const [player, setPlayer] = useState<PlayerState | null>(null);
  const [details, setDetails] = useState<{ item: MediaItem; recs: MediaItem[]; seasons?: SeasonInfo[] } | null>(null);
  const [season, setSeason] = useState<number>(1);
  const [episodes, setEpisodes] = useState<EpisodeInfo[]>([]);
  const [episodesLoading, setEpisodesLoading] = useState(false);
  const [continueWatching, setContinueWatching] = useState<WatchEntry[]>([]);
  const [movieWatchlist, setMovieWatchlist] = useState<WatchlistItem[]>(() => getMovieWatchlist());

  const searchAbort = useRef<AbortController | null>(null);

  // Load movie/tv shelves
  useEffect(() => {
    const cats = tab === "movies" ? MOVIE_CATEGORIES : tab === "tv" ? TV_CATEGORIES : null;
    if (!cats) return;
    setLoading(true);
    setError(null);
    Promise.all(
      cats.map(c =>
        fetch(`${API_BASE}${c.endpoint}`)
          .then(r => r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`)))
          .then(j => [c.id, (j.results || []).filter((x: MediaItem) => x.poster)] as [string, MediaItem[]])
          .catch(() => [c.id, []] as [string, MediaItem[]])
      )
    ).then(arr => {
      const r: Record<string, MediaItem[]> = {};
      arr.forEach(([id, items]) => { r[id] = items; });
      setRows(r);
      setLoading(false);
    }).catch(e => {
      setError(String(e));
      setLoading(false);
    });
  }, [tab]);

  // Search debounce
  useEffect(() => {
    if (!searchQ.trim()) { setSearchResults([]); return; }
    setSearchLoading(true);
    if (searchAbort.current) searchAbort.current.abort();
    const ctrl = new AbortController();
    searchAbort.current = ctrl;
    const t = setTimeout(() => {
      fetch(`${API_BASE}/movies/search?q=${encodeURIComponent(searchQ.trim())}`, { signal: ctrl.signal })
        .then(r => r.json())
        .then(j => {
          setSearchResults(j.results || []);
          setSearchLoading(false);
        })
        .catch(() => { if (!ctrl.signal.aborted) setSearchLoading(false); });
    }, 350);
    return () => { clearTimeout(t); ctrl.abort(); };
  }, [searchQ]);

  // Load genre
  useEffect(() => {
    if (genreId == null) return;
    setLoading(true);
    fetch(`${API_BASE}/movies/genre/${genreId}?page=${genrePage}`)
      .then(r => r.json())
      .then(j => {
        setGenreItems((j.results || []).filter((x: MediaItem) => x.poster));
        setGenreTotal(j.total_pages || 1);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [genreId, genrePage]);

  const toggleWl = useCallback((item: MediaItem) => {
    toggleMovieWatchlist({ id: item.id, title: item.title, poster: item.poster || undefined, type: item.kind });
    setMovieWatchlist(getMovieWatchlist());
  }, []);

  // Load TV details (seasons) when item is selected for details
  const openDetails = useCallback(async (item: MediaItem) => {
    setDetails({ item, recs: [], seasons: [] });
    try {
      const url = item.kind === "movie"
        ? `${API_BASE}/movies/details/${item.id}`
        : `${API_BASE}/tv/details/${item.id}`;
      const r = await fetch(url);
      const j = await r.json();
      const enriched: MediaItem = { ...item, imdb_id: j.item?.imdb_id || null };
      setDetails({ item: enriched, recs: j.recommendations || [], seasons: j.seasons });
      if (item.kind === "tv" && j.seasons?.length) {
        setSeason(j.seasons[0].season_number);
      }
    } catch {/* ignore */}
  }, []);

  // Load episodes
  useEffect(() => {
    if (!details || details.item.kind !== "tv" || !details.seasons?.length) return;
    setEpisodesLoading(true);
    fetch(`${API_BASE}/tv/season/${details.item.id}/${season}`)
      .then(r => r.json())
      .then(j => { setEpisodes(j.episodes || []); setEpisodesLoading(false); })
      .catch(() => setEpisodesLoading(false));
  }, [details, season]);

  // Load continue watching (movies + TV), refresh when player closes
  useEffect(() => {
    setContinueWatching(getWatchHistory().filter(e => e.type === "movie" || e.type === "tv"));
  }, [player]);

  const closePlayer = () => setPlayer(null);
  const closeDetails = () => { setDetails(null); setEpisodes([]); };

  const playMovie = (item: MediaItem) => {
    setPlayer({ item, season: item.kind === "tv" ? 1 : undefined, episode: item.kind === "tv" ? 1 : undefined, providerIdx: 0 });
    saveToHistory({ id: item.id, type: item.kind, title: item.title, poster: item.poster, season: item.kind === "tv" ? 1 : undefined, episode: item.kind === "tv" ? 1 : undefined });
  };
  const playEpisode = (s: number, e: number) => {
    if (!details) return;
    setPlayer({ item: details.item, season: s, episode: e, providerIdx: 0 });
    saveToHistory({ id: details.item.id, type: details.item.kind, title: details.item.title, poster: details.item.poster, season: s, episode: e });
  };

  const tryNextProvider = () => {
    if (!player) return;
    setPlayer({ ...player, providerIdx: (player.providerIdx + 1) % PROVIDERS.length });
  };

  const playerColor = accent.replace("#", "");
  const playerUrl = player ? PROVIDERS[player.providerIdx].build(player.item, player.season, player.episode, playerColor) : "";

  return (
    <div style={{ flex: 1, position: "relative", display: "flex", flexDirection: "column", minWidth: 0, background: bg }}>
      {/* Header */}
      <div style={{
        padding: "16px 22px", borderBottom: "1px solid rgba(255,255,255,0.06)",
        display: "flex", alignItems: "center", gap: "12px",
        background: "rgba(0,0,0,0.4)", backdropFilter: "blur(10px)", zIndex: 5,
      }}>
        <Film size={20} style={{ color: accent, filter: `drop-shadow(0 0 8px ${accent})` }} />
        <span style={{ fontSize: "16px", fontWeight: 600, letterSpacing: "0.3px", color: "#fff" }}>Movies & TV</span>

        <div style={{ display: "flex", gap: "4px", marginLeft: "12px" }}>
          {[
            { id: "movies", label: "Movies", icon: <Film size={13} /> },
            { id: "tv", label: "TV", icon: <Tv2 size={13} /> },
            { id: "genre", label: "Genres", icon: null },
          ].map(t => (
            <button key={t.id} onClick={() => { setTab(t.id as "movies" | "tv" | "genre"); if (t.id === "genre" && genreId == null) setGenreId(28); }}
              style={{
                display: "flex", alignItems: "center", gap: "6px",
                padding: "7px 12px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)",
                background: tab === t.id ? accent : "rgba(255,255,255,0.04)",
                color: tab === t.id ? "#fff" : "rgba(255,255,255,0.7)",
                fontSize: "12px", cursor: "pointer", fontWeight: 500,
              }}>
              {t.icon}{t.label}
            </button>
          ))}
        </div>
        <button onClick={() => { const all = Object.values(rows).flat().filter(x => x.poster); if (all.length) openDetails(all[Math.floor(Math.random() * all.length)]); }} title="Pick something random"
          style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", border: `1px solid ${accent}44`, background: `${accent}15`, color: accent, fontSize: "12px", cursor: "pointer", fontWeight: 500 }}>
          <Shuffle size={13} /> Surprise Me
        </button>

        <div style={{ flex: 1, position: "relative", maxWidth: "360px", marginLeft: "auto" }}>
          <Search style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.3)", width: "14px", height: "14px", pointerEvents: "none" }} />
          <input
            value={searchQ}
            onChange={e => { setSearchQ(e.target.value); if (e.target.value.trim()) setTab("search"); }}
            placeholder="Search movies & TV..."
            autoComplete="off" spellCheck={false}
            style={{
              width: "100%", padding: "8px 12px 8px 34px",
              borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)",
              background: "rgba(255,255,255,0.04)", color: "#fff", outline: "none", fontSize: "12px",
            }}
            onFocus={e => (e.currentTarget.style.borderColor = `${accent}66`)}
            onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
          />
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px 22px", position: "relative" }}>
        {tab === "search" ? (
          <SearchResults q={searchQ} loading={searchLoading} results={searchResults} onPick={openDetails} accent={accent} />
        ) : tab === "genre" ? (
          <GenreView genreId={genreId} setGenreId={setGenreId} items={genreItems} loading={loading} page={genrePage} totalPages={genreTotal} setPage={setGenrePage} onPick={openDetails} accent={accent} />
        ) : loading ? (
          <LoadingSkel />
        ) : error ? (
          <div style={{ color: "rgba(255,255,255,0.5)", padding: "40px", textAlign: "center" }}>{error}</div>
        ) : (
          <>
            {/* Continue Watching */}
            {continueWatching.length > 0 && (
              <ContinueWatchingShelf
                items={continueWatching}
                accent={accent}
                onPlay={entry => {
                  const allItems = Object.values(rows).flat();
                  const found = allItems.find(i => i.id === Number(entry.id));
                  if (found) {
                    if (entry.type === "tv" && entry.season != null && entry.episode != null) {
                      setPlayer({ item: found, season: entry.season, episode: entry.episode, providerIdx: 0 });
                    } else {
                      playMovie(found);
                    }
                  }
                }}
                onRemove={entry => {
                  removeFromHistory(entry.id, entry.type as "movie" | "tv");
                  setContinueWatching(getWatchHistory().filter(e => e.type === "movie" || e.type === "tv"));
                }}
              />
            )}

            {/* Hero */}
            {(() => {
              const cats = tab === "movies" ? MOVIE_CATEGORIES : TV_CATEGORIES;
              const heroList = rows[cats[0].id] || [];
              const hero = heroList[0];
              if (!hero) return null;
              return (
                <Hero item={hero} accent={accent} onPlay={() => playMovie(hero)} onInfo={() => openDetails(hero)} />
              );
            })()}

            {movieWatchlist.length > 0 && (
              <Shelf title="❤️ My List" items={movieWatchlist.map(w => ({ id: Number(w.id), kind: (w.type || "movie") as "movie" | "tv", title: w.title, poster: w.poster || null, year: "", rating: 0, overview: "", backdrop: null }))} onPick={openDetails} accent={accent} />
            )}
            {(tab === "movies" ? MOVIE_CATEGORIES : TV_CATEGORIES).map(cat => (
              <Shelf key={cat.id} title={cat.label} items={rows[cat.id] || []} onPick={openDetails} accent={accent} watchlist={movieWatchlist} onToggleWatchlist={toggleWl} />
            ))}
          </>
        )}
      </div>

      {/* Details modal */}
      {details && (
        <DetailsModal
          state={details}
          accent={accent}
          season={season}
          setSeason={setSeason}
          episodes={episodes}
          episodesLoading={episodesLoading}
          onClose={closeDetails}
          onPlay={() => playMovie(details.item)}
          onPlayEpisode={playEpisode}
          onPickRec={openDetails}
        />
      )}

      {/* Player */}
      {player && (
        <div style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,0.96)", zIndex: 1000,
          display: "flex", flexDirection: "column",
        }}>
          <div style={{
            padding: "12px 18px", display: "flex", alignItems: "center", gap: "10px",
            borderBottom: "1px solid rgba(255,255,255,0.08)",
          }}>
            <button onClick={closePlayer} title="Close"
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", fontSize: "12px", cursor: "pointer" }}>
              <X size={13} /> Close
            </button>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", color: "#fff", fontSize: "14px", fontWeight: 600 }}>
              {player.item.title}
              {player.season != null && <span style={{ color: "rgba(255,255,255,0.5)", fontWeight: 400, fontSize: "12px" }}>S{player.season} · E{player.episode}</span>}
            </div>
            <div style={{ marginLeft: "auto", display: "flex", gap: "8px", alignItems: "center" }}>
              <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.5)" }}>Source:</span>
              <select
                value={player.providerIdx}
                onChange={e => setPlayer({ ...player, providerIdx: Number(e.target.value) })}
                style={{ padding: "6px 10px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.06)", color: "#fff", fontSize: "12px", cursor: "pointer", outline: "none" }}>
                {PROVIDERS.map((p, i) => <option key={p.name} value={i} style={{ background: "#1a1a1a" }}>{p.name}</option>)}
              </select>
              <button onClick={tryNextProvider} title="Try next source"
                style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", fontSize: "12px", cursor: "pointer" }}>
                <RefreshCw size={12} /> Next source
              </button>
              <DownloadBtn url={playerUrl} title={`${player.item.title}${player.season != null ? ` S${player.season}E${player.episode}` : ""}`} />
              <button onClick={() => window.open(playerUrl, "_blank", "noopener,noreferrer")} title="Open in new tab"
                style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", fontSize: "12px", cursor: "pointer" }}>
                <ExternalLink size={12} /> New tab
              </button>
            </div>
          </div>
          <div style={{ flex: 1, position: "relative", background: "#000" }}>
            <iframe
              key={`${player.item.id}-${player.season}-${player.episode}-${player.providerIdx}`}
              src={playerUrl}
              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: "none", background: "#000" }}
              allow="autoplay; fullscreen; picture-in-picture; encrypted-media; gyroscope; accelerometer"
              allowFullScreen
              referrerPolicy="strict-origin-when-cross-origin"
              title={player.item.title}
            />
          </div>
        </div>
      )}
    </div>
  );
}

function ContinueWatchingShelf({ items, accent, onPlay, onRemove }: {
  items: WatchEntry[];
  accent: string;
  onPlay: (e: WatchEntry) => void;
  onRemove: (e: WatchEntry) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => ref.current?.scrollBy({ left: dir * 600, behavior: "smooth" });
  return (
    <div style={{ marginBottom: "26px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
        <h3 style={{ fontSize: "14px", fontWeight: 600, color: "#fff", margin: 0 }}>Continue Watching</h3>
        <div style={{ display: "flex", gap: "4px" }}>
          <button onClick={() => scroll(-1)} style={navBtn}><ChevronLeft size={14} /></button>
          <button onClick={() => scroll(1)} style={navBtn}><ChevronRight size={14} /></button>
        </div>
      </div>
      <div ref={ref} style={{ display: "flex", gap: "10px", overflowX: "auto", scrollbarWidth: "none", paddingBottom: "4px" }}>
        {items.map(entry => (
          <div key={`${entry.type}-${entry.id}`} style={{ position: "relative", flexShrink: 0, width: "150px" }}>
            <button onClick={() => onPlay(entry)} title={entry.title}
              style={{
                position: "relative", width: "100%", aspectRatio: "2/3", borderRadius: "10px", overflow: "hidden",
                background: "#111", border: `1px solid ${accent}44`, cursor: "pointer", padding: 0,
                transition: "transform 0.15s, box-shadow 0.15s",
              }}
              onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px) scale(1.02)"; e.currentTarget.style.boxShadow = `0 10px 28px ${accent}44`; }}
              onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "none"; }}>
              {entry.poster && <img src={entry.poster} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />}
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.35)", opacity: 0, transition: "opacity 0.15s" }}
                onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
                onMouseLeave={e => (e.currentTarget.style.opacity = "0")}>
                <Play size={32} fill={accent} color={accent} />
              </div>
              <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "16px 8px 6px", background: "linear-gradient(to top, rgba(0,0,0,0.95), rgba(0,0,0,0))" }}>
                <div style={{ fontWeight: 600, fontSize: "11px", color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{entry.title}</div>
                <div style={{ fontSize: "10px", color: accent, marginTop: "2px", fontWeight: 600 }}>{formatProgress(entry)}</div>
              </div>
            </button>
            <button onClick={() => onRemove(entry)} title="Remove"
              style={{ position: "absolute", top: "5px", right: "5px", width: "20px", height: "20px", borderRadius: "50%", background: "rgba(0,0,0,0.7)", border: "1px solid rgba(255,255,255,0.2)", color: "rgba(255,255,255,0.7)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
              <X size={10} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function DownloadBtn({ url, title }: { url: string; title: string }) {
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const handle = () => {
    if (state === "loading") return;
    setState("loading");
    const apiUrl = `${API_BASE}/download?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`;
    // Navigate directly — server sends Content-Disposition: attachment so the
    // browser saves the file without leaving the page (desktop) or opens it
    // natively (mobile). Avoids the iOS share-sheet triggered by a.click().
    window.location.href = apiUrl;
    setTimeout(() => setState("idle"), 5000);
  };
  const label = state === "loading" ? "Fetching…" : state === "error" ? "Unavailable" : "Download";
  const bg = state === "loading" ? "rgba(0,150,255,0.15)" : state === "error" ? "rgba(255,60,60,0.15)" : "rgba(255,255,255,0.06)";
  const bc = state === "loading" ? "rgba(0,150,255,0.4)" : state === "error" ? "rgba(255,60,60,0.4)" : "rgba(255,255,255,0.1)";
  const color = state === "loading" ? "#0096ff" : state === "error" ? "#ff4444" : "#fff";
  return (
    <button onClick={handle} title="Download in best quality"
      style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: bg, border: `1px solid ${bc}`, color, fontSize: "12px", cursor: state === "loading" ? "default" : "pointer", transition: "all 0.2s" }}>
      <Download size={12} style={{ animation: state === "loading" ? "spin 1s linear infinite" : "none" }} />
      {label}
      <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>
    </button>
  );
}

function LoadingSkel() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: "12px" }}>
      {Array.from({ length: 18 }).map((_, i) => (
        <div key={i} style={{ aspectRatio: "2/3", borderRadius: "10px", background: "rgba(255,255,255,0.04)", animation: "pulse 1.4s ease-in-out infinite" }} />
      ))}
      <style>{`@keyframes pulse { 0%,100%{opacity:.4} 50%{opacity:.7} }`}</style>
    </div>
  );
}

function Hero({ item, accent, onPlay, onInfo }: { item: MediaItem; accent: string; onPlay: () => void; onInfo: () => void }) {
  return (
    <div style={{
      position: "relative", height: "320px", borderRadius: "14px", overflow: "hidden",
      marginBottom: "26px",
      background: item.backdrop ? `url(${item.backdrop}) center/cover` : "linear-gradient(135deg, #222, #111)",
    }}>
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(to right, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.6) 50%, rgba(0,0,0,0.3) 100%)",
      }} />
      <div style={{
        position: "absolute", inset: 0, padding: "30px 36px",
        display: "flex", flexDirection: "column", justifyContent: "flex-end", maxWidth: "640px",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
          <span style={{ fontSize: "11px", padding: "3px 8px", borderRadius: "6px", background: accent, color: "#fff", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>
            Featured
          </span>
          {item.year && <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.7)" }}>{item.year}</span>}
          {item.rating > 0 && (
            <span style={{ display: "inline-flex", alignItems: "center", gap: "3px", fontSize: "12px", color: "rgba(255,255,255,0.85)" }}>
              <Star size={12} fill="#f5c518" color="#f5c518" /> {item.rating.toFixed(1)}
            </span>
          )}
        </div>
        <h2 style={{ fontSize: "32px", fontWeight: 700, color: "#fff", margin: 0, marginBottom: "10px", lineHeight: 1.1 }}>{item.title}</h2>
        <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.75)", lineHeight: 1.55, margin: 0, marginBottom: "16px",
          display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
          {item.overview || "No description available."}
        </p>
        <div style={{ display: "flex", gap: "10px" }}>
          <button onClick={onPlay} style={{
            display: "flex", alignItems: "center", gap: "8px", padding: "10px 18px",
            borderRadius: "9px", background: "#fff", color: "#000", border: "none",
            fontSize: "13px", fontWeight: 600, cursor: "pointer",
          }}>
            <Play size={14} fill="#000" /> Play
          </button>
          <button onClick={onInfo} style={{
            display: "flex", alignItems: "center", gap: "8px", padding: "10px 18px",
            borderRadius: "9px", background: "rgba(255,255,255,0.15)", color: "#fff",
            border: "1px solid rgba(255,255,255,0.2)", fontSize: "13px", fontWeight: 600, cursor: "pointer",
            backdropFilter: "blur(10px)",
          }}>
            More Info
          </button>
        </div>
      </div>
    </div>
  );
}

function Shelf({ title, items, onPick, accent, watchlist, onToggleWatchlist }: { title: string; items: MediaItem[]; onPick: (i: MediaItem) => void; accent: string; watchlist?: WatchlistItem[]; onToggleWatchlist?: (item: MediaItem) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => { if (!ref.current) return; ref.current.scrollBy({ left: dir * 600, behavior: "smooth" }); };
  if (!items.length) return null;
  return (
    <div style={{ marginBottom: "26px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
        <h3 style={{ fontSize: "14px", fontWeight: 600, color: "#fff", margin: 0, letterSpacing: "0.3px" }}>{title}</h3>
        <div style={{ display: "flex", gap: "4px" }}>
          <button onClick={() => scroll(-1)} style={navBtn}><ChevronLeft size={14} /></button>
          <button onClick={() => scroll(1)} style={navBtn}><ChevronRight size={14} /></button>
        </div>
      </div>
      <div ref={ref} style={{ display: "flex", gap: "10px", overflowX: "auto", scrollbarWidth: "none", paddingBottom: "4px" }}>
        {items.map(it => <Poster key={`${it.kind}-${it.id}`} item={it} onPick={onPick} accent={accent} fixed
          isWatchlisted={watchlist ? watchlist.some(w => w.id === it.id && w.type === it.kind) : undefined}
          onToggleWatchlist={onToggleWatchlist ? () => onToggleWatchlist(it) : undefined}
        />)}
      </div>
    </div>
  );
}

const navBtn: React.CSSProperties = {
  display: "flex", alignItems: "center", justifyContent: "center",
  width: "26px", height: "26px", borderRadius: "6px",
  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
  color: "rgba(255,255,255,0.7)", cursor: "pointer",
};

function Poster({ item, onPick, accent, fixed, onToggleWatchlist, isWatchlisted }: { item: MediaItem; onPick: (i: MediaItem) => void; accent: string; fixed?: boolean; onToggleWatchlist?: () => void; isWatchlisted?: boolean }) {
  return (
    <div role="button" tabIndex={0} onClick={() => onPick(item)} onKeyDown={e => e.key === "Enter" && onPick(item)} title={item.title}
      style={{ position: "relative", flexShrink: 0, width: fixed ? "150px" : undefined, aspectRatio: "2/3", borderRadius: "10px", overflow: "hidden", background: "#111", border: "1px solid rgba(255,255,255,0.08)", cursor: "pointer", transition: "transform 0.15s, border-color 0.15s, box-shadow 0.15s" }}
      onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px) scale(1.02)"; e.currentTarget.style.borderColor = `${accent}88`; e.currentTarget.style.boxShadow = `0 10px 28px ${accent}44`; }}
      onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; e.currentTarget.style.boxShadow = "none"; }}
    >
      {item.poster
        ? <img src={item.poster} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        : <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "rgba(255,255,255,0.4)", fontSize: "12px", padding: "10px", textAlign: "center" }}>{item.title}</div>
      }
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "20px 8px 6px", background: "linear-gradient(to top, rgba(0,0,0,0.92), rgba(0,0,0,0))", color: "#fff", fontSize: "11px", textAlign: "left" }}>
        <div style={{ fontWeight: 600, textOverflow: "ellipsis", overflow: "hidden", whiteSpace: "nowrap" }}>{item.title}</div>
        <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "2px", color: "rgba(255,255,255,0.65)", fontSize: "10px" }}>
          {item.year && <span>{item.year}</span>}
          {item.rating > 0 && <span style={{ display: "inline-flex", alignItems: "center", gap: "2px" }}><Star size={9} fill="#f5c518" color="#f5c518" /> {item.rating.toFixed(1)}</span>}
        </div>
      </div>
      {onToggleWatchlist && (
        <button onClick={e => { e.stopPropagation(); onToggleWatchlist(); }} title={isWatchlisted ? "Remove from My List" : "Add to My List"}
          style={{ position: "absolute", top: "6px", right: "6px", width: "26px", height: "26px", borderRadius: "50%", background: "rgba(0,0,0,0.75)", border: `1px solid ${isWatchlisted ? accent : "rgba(255,255,255,0.25)"}`, color: isWatchlisted ? accent : "rgba(255,255,255,0.7)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", padding: 0, zIndex: 2, transition: "all 0.15s" }}>
          <Heart size={11} fill={isWatchlisted ? accent : "none"} />
        </button>
      )}
    </div>
  );
}

function SearchResults({ q, loading, results, onPick, accent }: { q: string; loading: boolean; results: MediaItem[]; onPick: (i: MediaItem) => void; accent: string }) {
  if (!q.trim()) return <div style={{ color: "rgba(255,255,255,0.4)", textAlign: "center", padding: "60px" }}>Type to search movies & TV…</div>;
  if (loading) return <LoadingSkel />;
  if (!results.length) return <div style={{ color: "rgba(255,255,255,0.4)", textAlign: "center", padding: "60px" }}>No results for "{q}".</div>;
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "12px" }}>
      {results.map(it => <Poster key={`${it.kind}-${it.id}`} item={it} onPick={onPick} accent={accent} />)}
    </div>
  );
}

function GenreView({ genreId, setGenreId, items, loading, page, totalPages, setPage, onPick, accent }: {
  genreId: number | null;
  setGenreId: (id: number) => void;
  items: MediaItem[];
  loading: boolean;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  onPick: (i: MediaItem) => void;
  accent: string;
}) {
  return (
    <div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "20px" }}>
        {MOVIE_GENRES.map(g => (
          <button key={g.id} onClick={() => { setGenreId(g.id); setPage(1); }}
            style={{
              padding: "6px 12px", borderRadius: "16px", border: "1px solid rgba(255,255,255,0.1)",
              background: genreId === g.id ? accent : "rgba(255,255,255,0.04)",
              color: genreId === g.id ? "#fff" : "rgba(255,255,255,0.7)",
              fontSize: "12px", cursor: "pointer",
            }}>{g.name}</button>
        ))}
      </div>
      {loading ? <LoadingSkel /> : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "12px" }}>
            {items.map(it => <Poster key={`${it.kind}-${it.id}`} item={it} onPick={onPick} accent={accent} />)}
          </div>
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "10px", marginTop: "24px" }}>
            <button disabled={page <= 1} onClick={() => setPage(page - 1)}
              style={{ ...navBtn, width: "auto", padding: "6px 12px", opacity: page <= 1 ? 0.4 : 1 }}>
              <ChevronLeft size={13} /> Prev
            </button>
            <span style={{ color: "rgba(255,255,255,0.6)", fontSize: "12px" }}>Page {page} of {Math.min(totalPages, 500)}</span>
            <button disabled={page >= totalPages} onClick={() => setPage(page + 1)}
              style={{ ...navBtn, width: "auto", padding: "6px 12px", opacity: page >= totalPages ? 0.4 : 1 }}>
              Next <ChevronRight size={13} />
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function DetailsModal({
  state, accent, season, setSeason, episodes, episodesLoading,
  onClose, onPlay, onPlayEpisode, onPickRec,
}: {
  state: { item: MediaItem; recs: MediaItem[]; seasons?: SeasonInfo[] };
  accent: string;
  season: number;
  setSeason: (s: number) => void;
  episodes: EpisodeInfo[];
  episodesLoading: boolean;
  onClose: () => void;
  onPlay: () => void;
  onPlayEpisode: (s: number, e: number) => void;
  onPickRec: (i: MediaItem) => void;
}) {
  const { item, recs, seasons } = state;
  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 900,
      display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "30px 20px", overflowY: "auto",
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: "100%", maxWidth: "880px", background: "#0e0e0e",
        borderRadius: "14px", overflow: "hidden", border: "1px solid rgba(255,255,255,0.08)",
        marginBottom: "30px",
      }}>
        <div style={{
          position: "relative", height: "260px",
          background: item.backdrop ? `url(${item.backdrop}) center/cover` : "#1a1a1a",
        }}>
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(0,0,0,0.3), #0e0e0e)" }} />
          <button onClick={onClose} title="Close"
            style={{ position: "absolute", top: "14px", right: "14px", width: "32px", height: "32px", borderRadius: "50%", background: "rgba(0,0,0,0.6)", border: "1px solid rgba(255,255,255,0.15)", color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <X size={16} />
          </button>
        </div>
        <div style={{ padding: "0 26px 26px", marginTop: "-60px", position: "relative" }}>
          <h2 style={{ fontSize: "24px", fontWeight: 700, color: "#fff", margin: 0, marginBottom: "8px" }}>{item.title}</h2>
          <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "14px", fontSize: "12px", color: "rgba(255,255,255,0.65)" }}>
            {item.year && <span>{item.year}</span>}
            {item.rating > 0 && <span style={{ display: "inline-flex", alignItems: "center", gap: "3px" }}><Star size={11} fill="#f5c518" color="#f5c518" /> {item.rating.toFixed(1)}</span>}
            <span style={{ padding: "2px 7px", borderRadius: "4px", background: "rgba(255,255,255,0.08)", textTransform: "uppercase", fontSize: "10px", letterSpacing: "0.5px", fontWeight: 600 }}>
              {item.kind === "movie" ? "Movie" : "TV Series"}
            </span>
          </div>

          {item.kind === "movie" && (
            <button onClick={onPlay} style={{
              display: "inline-flex", alignItems: "center", gap: "8px", padding: "10px 20px",
              borderRadius: "9px", background: accent, color: "#fff", border: "none",
              fontSize: "13px", fontWeight: 600, cursor: "pointer", marginBottom: "16px",
            }}>
              <Play size={14} fill="#fff" /> Play
            </button>
          )}

          <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.78)", lineHeight: 1.6, margin: 0 }}>
            {item.overview || "No description available."}
          </p>

          {item.kind === "tv" && seasons && seasons.length > 0 && (
            <div style={{ marginTop: "22px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
                <h3 style={{ fontSize: "14px", color: "#fff", margin: 0, fontWeight: 600 }}>Episodes</h3>
                <select value={season} onChange={e => setSeason(Number(e.target.value))}
                  style={{ marginLeft: "auto", padding: "6px 10px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.06)", color: "#fff", fontSize: "12px", cursor: "pointer", outline: "none" }}>
                  {seasons.map(s => <option key={s.season_number} value={s.season_number} style={{ background: "#1a1a1a" }}>{s.name} ({s.episode_count} ep)</option>)}
                </select>
              </div>
              {episodesLoading ? (
                <div style={{ color: "rgba(255,255,255,0.4)", fontSize: "12px", padding: "20px", textAlign: "center" }}>Loading episodes…</div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: "8px", maxHeight: "320px", overflowY: "auto" }}>
                  {episodes.map(ep => (
                    <button key={ep.episode_number} onClick={() => onPlayEpisode(season, ep.episode_number)}
                      style={{
                        display: "flex", gap: "12px", alignItems: "stretch",
                        padding: "10px", borderRadius: "9px", background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.06)", cursor: "pointer", textAlign: "left",
                        transition: "background 0.12s, border-color 0.12s",
                      }}
                      onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.06)"; e.currentTarget.style.borderColor = `${accent}66`; }}
                      onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.03)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.06)"; }}>
                      <div style={{ width: "120px", flexShrink: 0, aspectRatio: "16/9", borderRadius: "6px", overflow: "hidden", background: ep.still ? `url(${ep.still}) center/cover` : "#1a1a1a", position: "relative" }}>
                        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.35)", opacity: 0.6 }}>
                          <Play size={22} fill="#fff" color="#fff" />
                        </div>
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: "12px", fontWeight: 600, color: "#fff", marginBottom: "3px" }}>
                          {ep.episode_number}. {ep.name}
                        </div>
                        <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.55)", lineHeight: 1.45,
                          display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                          {ep.overview || "No description."}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {recs.length > 0 && (
            <div style={{ marginTop: "26px" }}>
              <h3 style={{ fontSize: "14px", color: "#fff", margin: 0, marginBottom: "12px", fontWeight: 600 }}>You may also like</h3>
              <div style={{ display: "flex", gap: "10px", overflowX: "auto", scrollbarWidth: "none" }}>
                {recs.slice(0, 12).map(r => <Poster key={`${r.kind}-${r.id}`} item={r} onPick={onPickRec} accent={accent} fixed />)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
