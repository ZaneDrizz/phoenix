import { useState, useRef, useEffect, useCallback } from "react";
import {
  Send, Square, Copy, Check, Sparkles, RotateCcw, Paperclip,
  X, FileText, Mic, MicOff, Plus, PenSquare, ChevronDown, Trash2
} from "lucide-react";

const API = `${import.meta.env.BASE_URL || "/"}api`.replace("//api", "/api");

/* ─── Types ─────────────────────────────────────────────── */
interface Attachment {
  id: string;
  name: string;
  kind: "image" | "text" | "pdf";
  dataUrl: string;
  content?: string;
}
interface Message {
  role: "user" | "assistant";
  content: string;
  id: string;
  attachments?: Attachment[];
}
interface Conversation {
  id: string;
  name: string;
  messages: Message[];
  updatedAt: number;
}

function uid() { return Math.random().toString(36).slice(2, 10); }
function saveConvos(convos: Conversation[]) {
  try { localStorage.setItem("phoenix.gpt.convos", JSON.stringify(convos)); } catch { /* noop */ }
}
function loadConvos(): Conversation[] {
  try { return JSON.parse(localStorage.getItem("phoenix.gpt.convos") ?? "[]"); } catch { return []; }
}
function nameFromMessages(msgs: Message[]): string {
  const first = msgs.find(m => m.role === "user");
  if (!first) return "New chat";
  return first.content.slice(0, 40) + (first.content.length > 40 ? "…" : "");
}

/* ─── Markdown rendering ─────────────────────────────────── */
function inlineFormat(text: string): React.ReactNode {
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**"))
      return <strong key={i}>{part.slice(2, -2)}</strong>;
    if (part.startsWith("*") && part.endsWith("*"))
      return <em key={i}>{part.slice(1, -1)}</em>;
    if (part.startsWith("`") && part.endsWith("`"))
      return <code key={i} style={{ background: "rgba(255,255,255,0.12)", padding: "1px 5px", borderRadius: "4px", fontFamily: "monospace", fontSize: "0.88em" }}>{part.slice(1, -1)}</code>;
    return part;
  });
}

function CodeBlock({ code, lang, accent }: { code: string; lang: string; accent: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  return (
    <div style={{ margin: "12px 0", borderRadius: "10px", overflow: "hidden", background: "rgba(0,0,0,0.4)", border: "1px solid rgba(255,255,255,0.1)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "7px 14px", borderBottom: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)" }}>
        <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)", fontFamily: "monospace" }}>{lang || "code"}</span>
        <button onClick={copy} style={{ background: "none", border: "none", color: copied ? accent : "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex", alignItems: "center", gap: "4px", fontSize: "11px", padding: "2px 6px" }}>
          {copied ? <Check size={12} /> : <Copy size={12} />} {copied ? "Copied!" : "Copy code"}
        </button>
      </div>
      <pre style={{ margin: 0, padding: "14px 16px", overflowX: "auto", fontSize: "13px", lineHeight: 1.65, color: "#e2e8f0", fontFamily: "'SF Mono','Fira Code',monospace" }}>{code}</pre>
    </div>
  );
}

function MarkdownText({ text, accent }: { text: string; accent: string }) {
  const lines = text.split("\n");
  const elements: React.ReactNode[] = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.startsWith("```")) {
      const lang = line.slice(3).trim();
      const codeLines: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith("```")) { codeLines.push(lines[i]); i++; }
      elements.push(<CodeBlock key={`cb-${i}`} code={codeLines.join("\n")} lang={lang} accent={accent} />);
    } else if (line.startsWith("### ")) {
      elements.push(<h3 key={i} style={{ margin: "14px 0 5px", fontSize: "15px", fontWeight: 700 }}>{inlineFormat(line.slice(4))}</h3>);
    } else if (line.startsWith("## ")) {
      elements.push(<h2 key={i} style={{ margin: "16px 0 6px", fontSize: "17px", fontWeight: 700 }}>{inlineFormat(line.slice(3))}</h2>);
    } else if (line.startsWith("# ")) {
      elements.push(<h1 key={i} style={{ margin: "18px 0 8px", fontSize: "19px", fontWeight: 700 }}>{inlineFormat(line.slice(2))}</h1>);
    } else if (line.startsWith("- ") || line.startsWith("* ")) {
      elements.push(
        <div key={i} style={{ display: "flex", gap: "10px", margin: "3px 0", paddingLeft: "4px" }}>
          <span style={{ color: "rgba(255,255,255,0.45)", flexShrink: 0 }}>•</span>
          <span>{inlineFormat(line.slice(2))}</span>
        </div>
      );
    } else if (/^\d+\. /.test(line)) {
      const num = line.match(/^(\d+)\. /)?.[1];
      elements.push(
        <div key={i} style={{ display: "flex", gap: "10px", margin: "3px 0", paddingLeft: "4px" }}>
          <span style={{ color: "rgba(255,255,255,0.45)", flexShrink: 0, minWidth: "18px" }}>{num}.</span>
          <span>{inlineFormat(line.replace(/^\d+\. /, ""))}</span>
        </div>
      );
    } else if (line.startsWith("---")) {
      elements.push(<hr key={i} style={{ border: "none", borderTop: "1px solid rgba(255,255,255,0.1)", margin: "12px 0" }} />);
    } else if (line.trim() === "") {
      elements.push(<div key={i} style={{ height: "5px" }} />);
    } else {
      elements.push(<p key={i} style={{ margin: "0 0 2px" }}>{inlineFormat(line)}</p>);
    }
    i++;
  }
  return <div style={{ fontSize: "15px", lineHeight: 1.72, color: "rgba(255,255,255,0.92)" }}>{elements}</div>;
}

function Cursor() {
  const [vis, setVis] = useState(true);
  useEffect(() => { const t = setInterval(() => setVis(v => !v), 530); return () => clearInterval(t); }, []);
  return <span style={{ opacity: vis ? 1 : 0, color: "rgba(255,255,255,0.7)" }}>▋</span>;
}

function ThinkingDots({ accent }: { accent: string }) {
  return (
    <div style={{ display: "flex", gap: "5px", alignItems: "center", padding: "2px 0" }}>
      {[0, 1, 2].map(i => (
        <div key={i} style={{
          width: "7px", height: "7px", borderRadius: "50%", background: accent, opacity: 0.55,
          animation: `gptBounce 1.2s ${i * 0.2}s infinite ease-in-out`,
        }} />
      ))}
    </div>
  );
}

/* ─── Suggestion cards (ChatGPT home grid) ───────────────── */
const SUGGESTIONS = [
  { icon: "✏️", text: "Write a professional email", sub: "for any situation" },
  { icon: "⚡", text: "Write a Python web scraper", sub: "with BeautifulSoup" },
  { icon: "🧮", text: "Explain a complex topic", sub: "step by step" },
  { icon: "🎨", text: "Give me UI design tips", sub: "for a modern dark app" },
  { icon: "🦾", text: "Debug my code", sub: "paste it and I'll fix it" },
  { icon: "📝", text: "Write a cover letter", sub: "for any job or role" },
  { icon: "🚀", text: "Name my startup", sub: "creative, catchy, unique" },
  { icon: "🌐", text: "Build a landing page", sub: "HTML, CSS, JS" },
  { icon: "💡", text: "Explain quantum computing", sub: "like I'm 10 years old" },
  { icon: "🎵", text: "Write song lyrics", sub: "any genre or mood" },
  { icon: "📊", text: "Create a business plan", sub: "outline for any idea" },
  { icon: "🔐", text: "Explain cybersecurity", sub: "attacks and defense" },
];

function shuffle<T>(a: T[]): T[] {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; }
  return r;
}

/* ─── Attachment chip ────────────────────────────────────── */
function AttachmentChip({ att, onRemove, accent }: { att: Attachment; onRemove?: () => void; accent: string }) {
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: "6px", padding: "4px 8px 4px 6px", borderRadius: "8px", background: `${accent}15`, border: `1px solid ${accent}30`, maxWidth: "180px", position: "relative", flexShrink: 0 }}>
      {att.kind === "image"
        ? <img src={att.dataUrl} alt={att.name} style={{ width: "26px", height: "26px", borderRadius: "4px", objectFit: "cover", flexShrink: 0 }} />
        : <div style={{ width: "26px", height: "26px", borderRadius: "4px", background: `${accent}20`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><FileText size={13} color={accent} /></div>
      }
      <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.7)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>{att.name}</span>
      {onRemove && (
        <button onClick={onRemove} style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.4)", display: "flex", padding: 0, flexShrink: 0 }}>
          <X size={12} />
        </button>
      )}
    </div>
  );
}

/* ─── Main component ─────────────────────────────────────── */
export default function PhoenixGPT({ accent, glow, onBack: _onBack }: { accent: string; glow: string; onBack: () => void; }) {
  const [convos, setConvos] = useState<Conversation[]>(() => loadConvos());
  const [activeId, setActiveId] = useState<string | null>(() => {
    const saved = loadConvos();
    return saved.length > 0 ? saved[0].id : null;
  });
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = loadConvos();
    return saved.length > 0 ? saved[0].messages : [];
  });
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [streamingId, setStreamingId] = useState<string | null>(null);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [focused, setFocused] = useState(false);
  const [atBottom, setAtBottom] = useState(true);
  const [listening, setListening] = useState(false);
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [suggestions] = useState(() => shuffle(SUGGESTIONS).slice(0, 4));
  const [modelOpen, setModelOpen] = useState(false);
  const [model] = useState("GPT-5");
  const [deleteHover, setDeleteHover] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<{
    start: () => void; stop: () => void;
    continuous: boolean; lang: string;
    onresult: ((ev: { results: { [k: number]: { [k: number]: { transcript: string } } } }) => void) | null;
    onerror: (() => void) | null; onend: (() => void) | null;
  } | null>(null);

  /* persist convos whenever they change */
  useEffect(() => { saveConvos(convos); }, [convos]);

  const scrollToBottom = useCallback(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);
  useEffect(() => { if (atBottom) scrollToBottom(); }, [messages, atBottom, scrollToBottom]);

  const onScroll = () => {
    const el = listRef.current;
    if (!el) return;
    setAtBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 80);
  };

  /* ── File handling ──────────────────────────────────────── */
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = ev => {
        const dataUrl = ev.target?.result as string;
        const isImage = file.type.startsWith("image/");
        const att: Attachment = { id: uid(), name: file.name, kind: isImage ? "image" : "text", dataUrl };
        if (!isImage) {
          const tr = new FileReader();
          tr.onload = te => { att.content = te.target?.result as string; setAttachments(prev => [...prev, att]); };
          tr.readAsText(file);
        } else {
          setAttachments(prev => [...prev, att]);
        }
      };
      reader.readAsDataURL(file);
    });
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeAttachment = (id: string) => setAttachments(prev => prev.filter(a => a.id !== id));

  /* ── Voice ──────────────────────────────────────────────── */
  const startVoice = () => {
    type SRC = new () => typeof recognitionRef.current & object;
    const w = window as unknown as Record<string, unknown>;
    const Ctor = (w["SpeechRecognition"] || w["webkitSpeechRecognition"]) as SRC | undefined;
    if (!Ctor) return;
    const rec = new Ctor();
    rec.continuous = false; rec.lang = "en-US";
    rec.onresult = (ev) => { setInput(prev => prev + ev.results[0][0].transcript); setListening(false); };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
    rec.start(); setListening(true);
  };
  const stopVoice = () => { recognitionRef.current?.stop(); setListening(false); };

  /* ── Build API message payload ──────────────────────────── */
  const buildApiMessages = (history: Message[], text: string, atts: Attachment[]) => {
    const apiMsgs = history.map(m => {
      if (m.attachments?.some(a => a.kind === "image")) {
        const content: Array<{ type: string; text?: string; image_url?: { url: string } }> = [];
        if (m.content) content.push({ type: "text", text: m.content });
        m.attachments.filter(a => a.kind === "image").forEach(a => content.push({ type: "image_url", image_url: { url: a.dataUrl } }));
        return { role: m.role, content };
      }
      return { role: m.role, content: m.content };
    });
    const textFiles = atts.filter(a => a.kind !== "image");
    let fullText = text;
    if (textFiles.length > 0) fullText += "\n\n" + textFiles.map(f => `**File: ${f.name}**\n\`\`\`\n${(f.content ?? "").slice(0, 8000)}\n\`\`\``).join("\n\n");
    if (atts.some(a => a.kind === "image")) {
      const content: Array<{ type: string; text?: string; image_url?: { url: string } }> = [];
      if (fullText) content.push({ type: "text", text: fullText });
      atts.filter(a => a.kind === "image").forEach(a => content.push({ type: "image_url", image_url: { url: a.dataUrl } }));
      apiMsgs.push({ role: "user", content });
    } else {
      apiMsgs.push({ role: "user", content: fullText });
    }
    return apiMsgs;
  };

  /* ── Send message ───────────────────────────────────────── */
  const send = useCallback(async (text?: string) => {
    const content = (text ?? input).trim();
    if ((!content && attachments.length === 0) || streaming) return;
    setInput(""); if (inputRef.current) inputRef.current.style.height = "auto";
    const sentAtts = [...attachments]; setAttachments([]);

    const userMsg: Message = { role: "user", content, id: uid(), attachments: sentAtts.length > 0 ? sentAtts : undefined };
    const asstId = uid();
    const asstMsg: Message = { role: "assistant", content: "", id: asstId };

    const nextMsgs = [...messages, userMsg, asstMsg];
    setMessages(nextMsgs);
    setStreaming(true); setStreamingId(asstId); setAtBottom(true);

    /* upsert conversation */
    const now = Date.now();
    let convoId = activeId;
    if (!convoId) {
      convoId = uid();
      const newConvo: Conversation = { id: convoId, name: nameFromMessages([userMsg]), messages: [], updatedAt: now };
      setConvos(prev => [newConvo, ...prev]);
      setActiveId(convoId);
    }

    const apiMessages = buildApiMessages([...messages, userMsg].slice(0, -1), content, sentAtts);
    const controller = new AbortController();
    abortRef.current = controller;

    let finalContent = "";
    try {
      const res = await fetch(`${API}/ai/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiMessages }),
        signal: controller.signal,
      });
      if (!res.ok || !res.body) throw new Error("AI unavailable");
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split("\n\n"); buf = parts.pop() ?? "";
        for (const part of parts) {
          if (!part.startsWith("data: ")) continue;
          try {
            const data = JSON.parse(part.slice(6)) as { content?: string; done?: boolean };
            if (data.content) {
              finalContent += data.content;
              setMessages(prev => prev.map(m => m.id === asstId ? { ...m, content: m.content + data.content! } : m));
            }
          } catch { /* skip bad json */ }
        }
      }
    } catch (err: unknown) {
      if (err instanceof Error && err.name !== "AbortError") {
        finalContent = "Sorry, something went wrong. Please try again.";
        setMessages(prev => prev.map(m => m.id === asstId ? { ...m, content: finalContent } : m));
      }
    } finally {
      setStreaming(false); setStreamingId(null); abortRef.current = null;
      setTimeout(() => inputRef.current?.focus(), 50);
      /* persist final state */
      const cId = convoId!;
      setMessages(prev => {
        const finalMsgs = prev;
        setConvos(pc => pc.map(c => c.id === cId
          ? { ...c, messages: finalMsgs, name: nameFromMessages(finalMsgs), updatedAt: Date.now() }
          : c
        ));
        return finalMsgs;
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [input, attachments, streaming, messages, activeId]);

  const stop = () => abortRef.current?.abort();

  const regenerate = async () => {
    if (streaming) return;
    const lastUserIdx = [...messages].reverse().findIndex(m => m.role === "user");
    if (lastUserIdx < 0) return;
    const lastUser = messages[messages.length - 1 - lastUserIdx];
    setMessages(messages.slice(0, messages.length - 1 - lastUserIdx));
    await send(lastUser.content);
  };

  /* ── Conversation management ────────────────────────────── */
  const newChat = () => {
    if (streaming) abortRef.current?.abort();
    setActiveId(null);
    setMessages([]);
    setAttachments([]);
    setStreaming(false);
    setStreamingId(null);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const switchConvo = (c: Conversation) => {
    if (streaming) abortRef.current?.abort();
    setActiveId(c.id);
    setMessages(c.messages);
    setStreaming(false);
    setStreamingId(null);
    setAttachments([]);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const deleteConvo = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const next = convos.filter(c => c.id !== id);
    setConvos(next);
    if (activeId === id) {
      if (next.length > 0) { setActiveId(next[0].id); setMessages(next[0].messages); }
      else { setActiveId(null); setMessages([]); }
    }
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send(); }
  };

  const isEmpty = messages.length === 0;

  /* ─── Sidebar ─────────────────────────────────────────────*/
  const Sidebar = () => (
    <div style={{
      width: sidebarVisible ? "260px" : "0px",
      minWidth: sidebarVisible ? "260px" : "0px",
      transition: "width 0.2s, min-width 0.2s",
      overflow: "hidden",
      background: "rgba(0,0,0,0.4)",
      borderRight: "1px solid rgba(255,255,255,0.06)",
      display: "flex", flexDirection: "column",
      flexShrink: 0,
    }}>
      <div style={{ padding: "14px 12px 10px", display: "flex", alignItems: "center", gap: "8px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px", flex: 1 }}>
          <div style={{ width: "28px", height: "28px", borderRadius: "8px", background: `${accent}22`, border: `1px solid ${accent}33`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Sparkles size={13} color={accent} />
          </div>
          <span style={{ fontWeight: 600, fontSize: "13px", color: "rgba(255,255,255,0.8)", whiteSpace: "nowrap" }}>PhoenixGPT</span>
        </div>
        <button onClick={newChat} title="New chat"
          style={{ width: "30px", height: "30px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all 0.15s" }}
          onMouseEnter={e => { e.currentTarget.style.background = `${accent}15`; e.currentTarget.style.color = accent; }}
          onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.04)"; e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}>
          <PenSquare size={14} />
        </button>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "4px 8px 12px" }}>
        {convos.length === 0 ? (
          <p style={{ color: "rgba(255,255,255,0.2)", fontSize: "12px", textAlign: "center", marginTop: "20px", padding: "0 12px" }}>No conversations yet</p>
        ) : (
          convos.map(c => {
            const isActive = c.id === activeId;
            const isHovered = deleteHover === c.id;
            return (
              <div key={c.id} onClick={() => switchConvo(c)}
                style={{ padding: "8px 10px", borderRadius: "8px", cursor: "pointer", marginBottom: "1px", background: isActive ? `${accent}18` : "transparent", border: isActive ? `1px solid ${accent}22` : "1px solid transparent", display: "flex", alignItems: "center", gap: "6px", transition: "all 0.1s" }}
                onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
                onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "transparent"; }}>
                <span style={{ flex: 1, fontSize: "12.5px", color: isActive ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.6)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", lineHeight: 1.4 }}>{c.name}</span>
                <button
                  onClick={e => deleteConvo(c.id, e)}
                  onMouseEnter={() => setDeleteHover(c.id)}
                  onMouseLeave={() => setDeleteHover(null)}
                  style={{ background: "none", border: "none", cursor: "pointer", color: isHovered ? "#ef4444" : "rgba(255,255,255,0.2)", display: "flex", padding: "2px", borderRadius: "4px", flexShrink: 0, opacity: isActive || isHovered ? 1 : 0, transition: "all 0.15s" }}>
                  <Trash2 size={12} />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );

  /* ─── Input bar ────────────────────────────────────────────*/
  const InputArea = () => (
    <div style={{ padding: "12px 16px 16px", flexShrink: 0, display: "flex", justifyContent: "center" }}>
      <div style={{ width: "100%", maxWidth: "760px" }}>
        <div style={{
          background: "rgba(255,255,255,0.07)",
          border: `1px solid ${focused ? accent + "55" : "rgba(255,255,255,0.11)"}`,
          borderRadius: "16px",
          transition: "border-color 0.15s",
          boxShadow: focused ? `0 0 0 3px ${accent}10` : "0 2px 12px rgba(0,0,0,0.25)",
        }}>
          {attachments.length > 0 && (
            <div style={{ display: "flex", gap: "8px", padding: "10px 14px 0", flexWrap: "wrap" }}>
              {attachments.map(att => <AttachmentChip key={att.id} att={att} accent={accent} onRemove={() => removeAttachment(att.id)} />)}
            </div>
          )}
          <div style={{ display: "flex", alignItems: "flex-end", padding: "12px 12px 10px 16px", gap: "8px" }}>
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={onKey}
              onFocus={() => setFocused(true)}
              onBlur={() => setFocused(false)}
              placeholder={attachments.length > 0 ? "Add a message (optional)…" : "Message PhoenixGPT…"}
              rows={1}
              style={{ flex: 1, background: "none", border: "none", color: "#fff", fontSize: "15px", resize: "none", outline: "none", fontFamily: "inherit", lineHeight: 1.55, maxHeight: "220px", overflowY: "auto", scrollbarWidth: "none", caretColor: accent }}
              onInput={e => { const el = e.currentTarget; el.style.height = "auto"; el.style.height = Math.min(el.scrollHeight, 220) + "px"; }}
            />
            <button onClick={streaming ? stop : () => void send()}
              disabled={!streaming && !input.trim() && attachments.length === 0}
              style={{
                width: "36px", height: "36px", borderRadius: "10px", border: "none", flexShrink: 0,
                background: streaming ? "rgba(239,68,68,0.85)" : ((input.trim() || attachments.length > 0) ? accent : "rgba(255,255,255,0.08)"),
                color: (input.trim() || attachments.length > 0 || streaming) ? "#fff" : "rgba(255,255,255,0.2)",
                cursor: (streaming || input.trim() || attachments.length > 0) ? "pointer" : "default",
                display: "flex", alignItems: "center", justifyContent: "center",
                boxShadow: (input.trim() || attachments.length > 0) && !streaming ? `0 0 16px ${glow}` : "none",
                transition: "all 0.15s",
              }}>
              {streaming ? <Square size={13} fill="currentColor" /> : <Send size={14} />}
            </button>
          </div>
          <div style={{ display: "flex", alignItems: "center", padding: "0 10px 10px", gap: "4px", flexWrap: "wrap" }}>
            <input ref={fileInputRef} type="file" multiple accept="image/*,.txt,.md,.json,.csv,.js,.ts,.py,.html,.css,.xml,.yaml,.yml" style={{ display: "none" }} onChange={handleFileSelect} />
            <button onClick={() => fileInputRef.current?.click()} title="Attach file or image"
              style={{ display: "flex", alignItems: "center", gap: "5px", padding: "4px 10px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.03)", color: "rgba(255,255,255,0.4)", cursor: "pointer", fontSize: "12px" }}
              onMouseEnter={e => { e.currentTarget.style.color = accent; e.currentTarget.style.borderColor = `${accent}40`; }}
              onMouseLeave={e => { e.currentTarget.style.color = "rgba(255,255,255,0.4)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; }}>
              <Paperclip size={12} /> Attach
            </button>
            <button onClick={() => fileInputRef.current?.click()} title="Upload image"
              style={{ display: "flex", alignItems: "center", gap: "5px", padding: "4px 10px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.03)", color: "rgba(255,255,255,0.4)", cursor: "pointer", fontSize: "12px" }}
              onMouseEnter={e => { e.currentTarget.style.color = accent; e.currentTarget.style.borderColor = `${accent}40`; }}
              onMouseLeave={e => { e.currentTarget.style.color = "rgba(255,255,255,0.4)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; }}>
              <Plus size={12} /> Image
            </button>
            <button onClick={listening ? stopVoice : startVoice} title={listening ? "Stop" : "Voice input"}
              style={{ display: "flex", alignItems: "center", gap: "5px", padding: "4px 10px", borderRadius: "8px", border: `1px solid ${listening ? accent + "55" : "rgba(255,255,255,0.08)"}`, background: listening ? `${accent}15` : "rgba(255,255,255,0.03)", color: listening ? accent : "rgba(255,255,255,0.4)", cursor: "pointer", fontSize: "12px" }}>
              {listening ? <MicOff size={12} /> : <Mic size={12} />}
              {listening ? "Listening…" : "Voice"}
            </button>
            <span style={{ marginLeft: "auto", fontSize: "11px", color: "rgba(255,255,255,0.15)" }}>
              {streaming ? "Generating…" : "↵ to send  ⇧↵ for newline"}
            </span>
          </div>
        </div>
        <p style={{ textAlign: "center", fontSize: "11px", color: "rgba(255,255,255,0.12)", marginTop: "8px" }}>
          PhoenixGPT can make mistakes. Consider checking important information.
        </p>
      </div>
    </div>
  );

  /* ─── Render ───────────────────────────────────────────────*/
  return (
    <div style={{ flex: 1, display: "flex", overflow: "hidden", position: "relative" }}>
      <style>{`
        @keyframes gptBounce { 0%,80%,100% { transform: translateY(0); } 40% { transform: translateY(-6px); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
        .gpt-msg { animation: fadeIn 0.18s ease; }
      `}</style>

      {/* ── Sidebar ───────────────────────── */}
      {Sidebar()}

      {/* ── Main area ─────────────────────── */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", padding: "10px 16px", borderBottom: "1px solid rgba(255,255,255,0.05)", flexShrink: 0, gap: "10px" }}>
          <button onClick={() => setSidebarVisible(v => !v)} title={sidebarVisible ? "Hide sidebar" : "Show sidebar"}
            style={{ width: "30px", height: "30px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <rect x="1" y="3" width="12" height="1.2" rx="0.6" fill="currentColor"/>
              <rect x="1" y="6.4" width="12" height="1.2" rx="0.6" fill="currentColor"/>
              <rect x="1" y="9.8" width="12" height="1.2" rx="0.6" fill="currentColor"/>
            </svg>
          </button>

          {/* Model selector */}
          <div style={{ position: "relative" }}>
            <button onClick={() => setModelOpen(o => !o)}
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "5px 10px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.75)", cursor: "pointer", fontSize: "13px", fontWeight: 600 }}>
              <Sparkles size={12} color={accent} />
              {model}
              <ChevronDown size={12} style={{ opacity: 0.5 }} />
            </button>
            {modelOpen && (
              <div style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, background: "#1a1a1a", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "10px", padding: "6px", zIndex: 50, minWidth: "180px", boxShadow: "0 8px 32px rgba(0,0,0,0.5)" }}
                onMouseLeave={() => setModelOpen(false)}>
                {["GPT-5", "GPT-4o", "GPT-4 Turbo", "GPT-3.5"].map(m => (
                  <button key={m} onClick={() => setModelOpen(false)}
                    style={{ display: "block", width: "100%", padding: "8px 12px", borderRadius: "7px", border: "none", background: m === model ? `${accent}18` : "transparent", color: m === model ? accent : "rgba(255,255,255,0.7)", cursor: "pointer", fontSize: "13px", textAlign: "left" }}>
                    {m} {m === model && "✓"}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div style={{ flex: 1 }} />
          {messages.length > 0 && (
            <button onClick={newChat} title="New chat"
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "5px 12px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.55)", cursor: "pointer", fontSize: "12px" }}
              onMouseEnter={e => { e.currentTarget.style.background = `${accent}15`; e.currentTarget.style.color = accent; }}
              onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.05)"; e.currentTarget.style.color = "rgba(255,255,255,0.55)"; }}>
              <Plus size={13} /> New chat
            </button>
          )}
        </div>

        {/* Messages / Empty state */}
        {isEmpty ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "40px 20px 0", overflowY: "auto" }}>
            <div style={{ width: "52px", height: "52px", borderRadius: "16px", background: `${accent}20`, border: `1px solid ${accent}33`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "18px" }}>
              <Sparkles size={22} color={accent} />
            </div>
            <h2 style={{ margin: "0 0 6px", fontSize: "22px", fontWeight: 700, color: "rgba(255,255,255,0.88)" }}>What can I help with?</h2>
            <p style={{ margin: "0 0 32px", fontSize: "14px", color: "rgba(255,255,255,0.35)" }}>Ask anything — I'm your AI assistant powered by PhoenixGPT.</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", maxWidth: "640px", width: "100%" }}>
              {suggestions.map((s, i) => (
                <button key={i} onClick={() => send(s.text)}
                  style={{ padding: "14px 16px", borderRadius: "12px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", cursor: "pointer", textAlign: "left", transition: "all 0.15s" }}
                  onMouseEnter={e => { e.currentTarget.style.background = `${accent}10`; e.currentTarget.style.borderColor = `${accent}30`; }}
                  onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.04)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; }}>
                  <div style={{ fontSize: "18px", marginBottom: "5px" }}>{s.icon}</div>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: "rgba(255,255,255,0.8)", marginBottom: "2px" }}>{s.text}</div>
                  <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.3)" }}>{s.sub}</div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div ref={listRef} onScroll={onScroll} style={{ flex: 1, overflowY: "auto", padding: "24px 16px 8px" }}>
            <div style={{ maxWidth: "760px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "24px" }}>
              {messages.map((msg, idx) => {
                const isUser = msg.role === "user";
                const isLast = idx === messages.length - 1;
                const isStreaming = streamingId === msg.id && streaming;
                return (
                  <div key={msg.id} className="gpt-msg">
                    {isUser ? (
                      /* User bubble */
                      <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px" }}>
                        <div style={{ maxWidth: "80%", display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "6px" }}>
                          {msg.attachments && msg.attachments.length > 0 && (
                            <div style={{ display: "flex", gap: "6px", flexWrap: "wrap", justifyContent: "flex-end" }}>
                              {msg.attachments.map(a => a.kind === "image"
                                ? <img key={a.id} src={a.dataUrl} alt={a.name} style={{ maxWidth: "220px", maxHeight: "180px", borderRadius: "10px", objectFit: "cover", border: "1px solid rgba(255,255,255,0.12)" }} />
                                : <AttachmentChip key={a.id} att={a} accent={accent} />
                              )}
                            </div>
                          )}
                          {msg.content && (
                            <div style={{ padding: "11px 16px", borderRadius: "18px 18px 4px 18px", background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.08)", fontSize: "15px", color: "rgba(255,255,255,0.9)", lineHeight: 1.6, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                              {msg.content}
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      /* Assistant message */
                      <div style={{ display: "flex", gap: "12px", alignItems: "flex-start" }}>
                        <div style={{ width: "30px", height: "30px", borderRadius: "50%", background: `linear-gradient(135deg, ${accent}80, ${accent}20)`, border: `1px solid ${accent}40`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                          <Sparkles size={13} color={accent} />
                        </div>
                        <div style={{ flex: 1, minWidth: 0, paddingTop: "2px" }}>
                          {!msg.content && isStreaming ? (
                            <ThinkingDots accent={accent} />
                          ) : (
                            <>
                              <MarkdownText text={msg.content} accent={accent} />
                              {isStreaming && <Cursor />}
                              {!isStreaming && msg.content && isLast && (
                                <MsgActions msg={msg} accent={accent} onRegenerate={idx === messages.length - 1 ? regenerate : undefined} />
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
              <div ref={bottomRef} />
            </div>
          </div>
        )}

        {/* Scroll to bottom FAB */}
        {!atBottom && !isEmpty && (
          <div style={{ position: "absolute", bottom: "120px", left: "50%", transform: "translateX(-50%)" }}>
            <button onClick={() => { setAtBottom(true); scrollToBottom(); }}
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 14px", borderRadius: "20px", border: "1px solid rgba(255,255,255,0.12)", background: "rgba(30,30,30,0.9)", color: "rgba(255,255,255,0.7)", cursor: "pointer", fontSize: "12px", boxShadow: "0 4px 20px rgba(0,0,0,0.4)", backdropFilter: "blur(10px)" }}>
              <ChevronDown size={13} /> Scroll to bottom
            </button>
          </div>
        )}

        {/* Input area */}
        {InputArea()}
      </div>
    </div>
  );
}

/* ─── Message action bar ────────────────────────────────── */
function MsgActions({ msg, accent, onRegenerate }: { msg: Message; accent: string; onRegenerate?: () => void }) {
  const [copied, setCopied] = useState(false);
  const [hov, setHov] = useState(false);
  const copy = () => { navigator.clipboard.writeText(msg.content); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: "flex", gap: "4px", marginTop: "10px", opacity: hov ? 1 : 0, transition: "opacity 0.15s" }}>
      <button onClick={copy} style={{ display: "flex", alignItems: "center", gap: "5px", padding: "4px 10px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: copied ? accent : "rgba(255,255,255,0.45)", cursor: "pointer", fontSize: "12px" }}>
        {copied ? <Check size={12} /> : <Copy size={12} />} {copied ? "Copied!" : "Copy"}
      </button>
      {onRegenerate && (
        <button onClick={onRegenerate} style={{ display: "flex", alignItems: "center", gap: "5px", padding: "4px 10px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.45)", cursor: "pointer", fontSize: "12px" }}>
          <RotateCcw size={12} /> Regenerate
        </button>
      )}
    </div>
  );
}
