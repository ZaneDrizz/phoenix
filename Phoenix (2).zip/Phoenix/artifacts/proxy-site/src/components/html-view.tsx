import { useState, useRef, useCallback, useEffect } from "react";
import { Code2, Upload, Play, Trash2, FileCode, X, RotateCcw, Columns, Square, Sun, Moon } from "lucide-react";

interface HtmlViewProps {
  accent: string;
  bg?: string;
}

type InputMode = "type" | "upload";

export default function HtmlView({ accent, bg = "transparent" }: HtmlViewProps) {
  const [mode, setMode] = useState<InputMode | null>(null);
  const [code, setCode] = useState("");
  const [rendered, setRendered] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [splitView, setSplitView] = useState(false);
  const [previewBg, setPreviewBg] = useState<"white" | "dark" | "transparent">("white");
  const [livePreview, setLivePreview] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleRun = useCallback(() => {
    if (!code.trim()) return;
    setRendered(code);
  }, [code]);

  const handleClear = () => {
    setCode("");
    setRendered(null);
    setFileName(null);
  };

  const handleBack = () => {
    setMode(null);
    setCode("");
    setRendered(null);
    setFileName(null);
  };

  const loadFile = (file: File) => {
    if (!file.name.endsWith(".html") && !file.name.endsWith(".htm") && file.type !== "text/html") {
      alert("Please upload an .html file.");
      return;
    }
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = e => {
      const text = e.target?.result as string;
      setCode(text);
      setRendered(text);
      setMode("upload");
    };
    reader.readAsText(file);
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) loadFile(file);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) loadFile(file);
    e.target.value = "";
  };

  // Auto-run on Ctrl/Cmd+Enter in textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); handleRun(); }
    };
    ta.addEventListener("keydown", handler);
    return () => ta.removeEventListener("keydown", handler);
  }, [handleRun]);

  /* ── Pick mode screen ──────────────────────────────────── */
  if (!mode) {
    return (
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: bg, padding: "40px 24px", gap: "32px" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: "36px", marginBottom: "8px" }}>{"</>"}</div>
          <h1 style={{ fontSize: "26px", fontWeight: 700, color: "#fff", margin: "0 0 6px" }}>HTML Viewer</h1>
          <p style={{ color: "rgba(255,255,255,0.45)", fontSize: "14px", margin: 0 }}>Type or paste HTML code, or upload an .html file</p>
        </div>

        <div style={{ display: "flex", gap: "18px", flexWrap: "wrap", justifyContent: "center" }}>
          {/* Type option */}
          <button
            onClick={() => setMode("type")}
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "14px", padding: "32px 40px", borderRadius: "16px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", cursor: "pointer", transition: "all 0.2s", minWidth: "180px" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.borderColor = accent; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.1)"; }}
          >
            <div style={{ width: "52px", height: "52px", borderRadius: "14px", background: `${accent}22`, border: `1px solid ${accent}44`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Code2 size={24} color={accent} />
            </div>
            <div>
              <div style={{ fontSize: "15px", fontWeight: 600, marginBottom: "4px" }}>Type / Paste</div>
              <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.45)" }}>Write HTML directly</div>
            </div>
          </button>

          {/* Upload option */}
          <button
            onClick={() => { fileRef.current?.click(); }}
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleFileDrop}
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "14px", padding: "32px 40px", borderRadius: "16px", background: dragOver ? `${accent}15` : "rgba(255,255,255,0.04)", border: `1px solid ${dragOver ? accent : "rgba(255,255,255,0.1)"}`, color: "#fff", cursor: "pointer", transition: "all 0.2s", minWidth: "180px" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.borderColor = accent; }}
            onMouseLeave={e => { if (!dragOver) { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.1)"; } }}
          >
            <div style={{ width: "52px", height: "52px", borderRadius: "14px", background: `${accent}22`, border: `1px solid ${accent}44`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Upload size={24} color={accent} />
            </div>
            <div>
              <div style={{ fontSize: "15px", fontWeight: 600, marginBottom: "4px" }}>Upload File</div>
              <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.45)" }}>Drop or browse .html</div>
            </div>
          </button>
        </div>

        <input ref={fileRef} type="file" accept=".html,.htm,text/html" style={{ display: "none" }} onChange={handleFileInput} />
      </div>
    );
  }

  /* ── Editor + Preview ─────────────────────────────────── */
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", background: bg, overflow: "hidden", minWidth: 0 }}>
      {/* Toolbar */}
      <div style={{ display: "flex", alignItems: "center", gap: "8px", padding: "10px 16px", borderBottom: "1px solid rgba(255,255,255,0.08)", flexShrink: 0 }}>
        <button onClick={handleBack} style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 11px", borderRadius: "7px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", fontSize: "12px", cursor: "pointer" }}>
          <X size={12} /> Close
        </button>

        {fileName && (
          <div style={{ display: "flex", alignItems: "center", gap: "6px", padding: "5px 10px", borderRadius: "7px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.6)", fontSize: "12px" }}>
            <FileCode size={12} /> {fileName}
          </div>
        )}

        <div style={{ marginLeft: "auto", display: "flex", gap: "8px" }}>
          {/* Upload another file */}
          <button onClick={() => fileRef.current?.click()} title="Upload a file"
            style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 11px", borderRadius: "7px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", fontSize: "12px", cursor: "pointer" }}>
            <Upload size={12} /> Upload
          </button>

          <button onClick={handleClear} title="Clear"
            style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 11px", borderRadius: "7px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", fontSize: "12px", cursor: "pointer" }}>
            <Trash2 size={12} /> Clear
          </button>

          {rendered && (
            <button onClick={() => setRendered(null)} title="Edit"
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 11px", borderRadius: "7px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", fontSize: "12px", cursor: "pointer" }}>
              <RotateCcw size={12} /> Edit
            </button>
          )}
          {rendered && code && (
            <button onClick={() => setSplitView(o => !o)} title={splitView ? "Single view" : "Side-by-side split"}
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 11px", borderRadius: "7px", background: splitView ? `${accent}20` : "rgba(255,255,255,0.06)", border: splitView ? `1px solid ${accent}44` : "1px solid rgba(255,255,255,0.1)", color: splitView ? accent : "rgba(255,255,255,0.7)", fontSize: "12px", cursor: "pointer" }}>
              <Columns size={12} /> {splitView ? "Single" : "Split"}
            </button>
          )}

          <button onClick={handleRun} title="Run HTML (Ctrl+Enter)"
            style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 14px", borderRadius: "7px", background: accent, border: "none", color: "#fff", fontSize: "12px", fontWeight: 600, cursor: "pointer" }}>
            <Play size={12} /> Run
          </button>
        </div>

        <input ref={fileRef} type="file" accept=".html,.htm,text/html" style={{ display: "none" }} onChange={handleFileInput} />
      </div>

      {/* Editor + Preview area */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        {/* Code editor */}
        {(splitView || !rendered) && (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", borderRight: splitView && rendered ? "1px solid rgba(255,255,255,0.08)" : "none" }}>
            <div style={{ padding: "8px 16px", background: "rgba(255,255,255,0.02)", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: "11px", color: "rgba(255,255,255,0.35)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span>HTML Editor</span>
              <span style={{ fontSize: "10px", color: "rgba(255,255,255,0.22)" }}>
                {code.split(/\s+/).filter(Boolean).length}w · {code.length}c · Ctrl+Enter to run
              </span>
            </div>
            <textarea
              ref={textareaRef} value={code} onChange={e => setCode(e.target.value)}
              placeholder={"<!DOCTYPE html>\n<html>\n  <head><title>My Page</title></head>\n  <body>\n    <h1>Hello, world!</h1>\n  </body>\n</html>"}
              spellCheck={false} autoComplete="off" autoCorrect="off"
              style={{ flex: 1, resize: "none", border: "none", outline: "none", background: "#0a0a0a", color: "#e0e0e0", fontFamily: "'Fira Code', 'Cascadia Code', 'Courier New', monospace", fontSize: "13px", lineHeight: "1.6", padding: "16px", tabSize: 2 }}
              onKeyDown={e => { if (e.key === "Tab") { e.preventDefault(); const s = e.currentTarget.selectionStart; const end = e.currentTarget.selectionEnd; setCode(c => c.substring(0, s) + "  " + c.substring(end)); setTimeout(() => { e.currentTarget.selectionStart = e.currentTarget.selectionEnd = s + 2; }, 0); } }}
            />
          </div>
        )}

        {/* Preview iframe */}
        {(splitView || rendered) && rendered && (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            <div style={{ padding: "6px 16px", background: "rgba(255,255,255,0.02)", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.35)" }}>Preview</span>
              <div style={{ display: "flex", gap: "4px" }}>
                {(["white", "dark"] as const).map(pbg => (
                  <button key={pbg} onClick={() => setPreviewBg(pbg)} style={{ padding: "2px 8px", borderRadius: "4px", border: previewBg === pbg ? `1px solid ${accent}44` : "1px solid rgba(255,255,255,0.08)", background: previewBg === pbg ? `${accent}18` : "none", color: previewBg === pbg ? accent : "rgba(255,255,255,0.3)", fontSize: "10px", cursor: "pointer" }}>
                    {pbg === "white" ? "☀️ Light" : "🌙 Dark"}
                  </button>
                ))}
              </div>
            </div>
            <iframe srcDoc={rendered} sandbox="allow-scripts allow-forms allow-same-origin allow-modals"
              style={{ flex: 1, border: "none", background: previewBg === "white" ? "#fff" : "#111" }} title="HTML Preview" />
          </div>
        )}
      </div>
    </div>
  );
}
