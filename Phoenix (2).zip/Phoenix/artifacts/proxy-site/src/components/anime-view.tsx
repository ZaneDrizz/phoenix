import { useState, useEffect, useCallback, useRef } from "react";
import { Search, X, Star, Play, ChevronLeft, ChevronRight, RefreshCw, ExternalLink, Tv2, Download, Heart } from "lucide-react";
import { saveToHistory, getWatchHistory, removeFromHistory, formatProgress, type WatchEntry } from "../lib/watch-history";
import { toggleAnimeWatchlist, isInAnimeWatchlist, getAnimeWatchlist, type WatchlistItem } from "../lib/watchlist";

const API_BASE = `${import.meta.env.BASE_URL || "/"}api`.replace("//api", "/api");

interface AnimeItem {
  mal_id: number;
  title: string;
  poster: string | null;
  backdrop: string | null;
  year: string;
  rating: number;
  overview: string;
  episodes: number | null;
  kind: "anime";
  status: string;
}

interface AnimeEpisode {
  number: number;
  title: string;
  aired: string | null;
}

interface AnimeDetails {
  item: AnimeItem;
  episodes: AnimeEpisode[];
}

interface PlayerState {
  item: AnimeItem;
  episode: number;
  audioTrack: "sub" | "dub";
  providerIdx: number;
}

const ANIME_CATEGORIES = [
  { id: "trending", label: "Trending Now", endpoint: "/anime/trending" },
  { id: "seasonal", label: "Airing This Season", endpoint: "/anime/seasonal" },
  { id: "popular", label: "All-Time Popular", endpoint: "/anime/popular" },
  { id: "top", label: "Top Rated", endpoint: "/anime/top" },
];

const PROVIDERS = [
  {
    name: "MegaPlay",
    build: (malId: number, ep: number, dub: boolean) =>
      `https://megaplay.buzz/stream/mal/${malId}/${ep}/${dub ? "dub" : "sub"}`,
  },
  {
    name: "Videasy",
    build: (malId: number, ep: number, _dub: boolean) =>
      `https://player.videasy.to/anime/${malId}/${ep}`,
  },
  {
    name: "VidSrc Mirror",
    build: (malId: number, ep: number, dub: boolean) =>
      `https://vidsrc.sh/embed/anime/${malId}/${ep}${dub ? "?dub=1" : ""}`,
  },
];

export default function AnimeView({ accent, bg }: { accent: string; bg: string }) {
  const [tab, setTab] = useState<"browse" | "search">("browse");
  const [rows, setRows] = useState<Record<string, AnimeItem[]>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQ, setSearchQ] = useState("");
  const [searchResults, setSearchResults] = useState<AnimeItem[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [details, setDetails] = useState<AnimeDetails | null>(null);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [player, setPlayer] = useState<PlayerState | null>(null);
  const [continueWatching, setContinueWatching] = useState<WatchEntry[]>([]);
  const searchAbort = useRef<AbortController | null>(null);

  // Load continue watching
  useEffect(() => {
    setContinueWatching(getWatchHistory().filter(e => e.type === "anime"));
  }, [player]);

  // Load shelves sequentially to respect Jikan rate limit
  useEffect(() => {
    setLoading(true);
    setError(null);
    let cancelled = false;
    const results: Record<string, AnimeItem[]> = {};

    (async () => {
      for (const cat of ANIME_CATEGORIES) {
        if (cancelled) break;
        try {
          const r = await fetch(`${API_BASE}${cat.endpoint}`);
          const j = await r.json() as { results?: AnimeItem[] };
          results[cat.id] = (j.results || []).filter(x => x.poster);
        } catch {
          results[cat.id] = [];
        }
        if (!cancelled) setRows({ ...results });
        // Small delay to stay within Jikan rate limit (3 req/s)
        await new Promise(res => setTimeout(res, 400));
      }
      if (!cancelled) setLoading(false);
    })();

    return () => { cancelled = true; };
  }, []);

  // Search debounce
  useEffect(() => {
    if (!searchQ.trim()) { setSearchResults([]); return; }
    setSearchLoading(true);
    if (searchAbort.current) searchAbort.current.abort();
    const ctrl = new AbortController();
    searchAbort.current = ctrl;
    const t = setTimeout(() => {
      fetch(`${API_BASE}/anime/search?q=${encodeURIComponent(searchQ.trim())}`, { signal: ctrl.signal })
        .then(r => r.json())
        .then(j => { setSearchResults((j as { results?: AnimeItem[] }).results || []); setSearchLoading(false); })
        .catch(() => { if (!ctrl.signal.aborted) setSearchLoading(false); });
    }, 500);
    return () => { clearTimeout(t); ctrl.abort(); };
  }, [searchQ]);

  const [animeWatchlist, setAnimeWatchlist] = useState<WatchlistItem[]>(() => getAnimeWatchlist());
  const toggleAnimeWl = useCallback((item: AnimeItem) => {
    toggleAnimeWatchlist({ id: item.mal_id, title: item.title, poster: item.poster || undefined, type: "anime" });
    setAnimeWatchlist(getAnimeWatchlist());
  }, []);

  const openDetails = useCallback(async (item: AnimeItem) => {
    setDetails({ item, episodes: [] });
    setDetailsLoading(true);
    try {
      const r = await fetch(`${API_BASE}/anime/details/${item.mal_id}`);
      const j = await r.json() as { item?: AnimeItem; episodes?: AnimeEpisode[] };
      setDetails({ item: j.item ?? item, episodes: j.episodes || [] });
    } catch {/* ignore */}
    setDetailsLoading(false);
  }, []);

  const play = (item: AnimeItem, episode: number, audioTrack: "sub" | "dub" = "sub") => {
    setPlayer({ item, episode, audioTrack, providerIdx: 0 });
    saveToHistory({ id: item.mal_id, type: "anime", title: item.title, poster: item.poster, episode, audioTrack });
  };

  const tryNext = () => {
    if (!player) return;
    setPlayer({ ...player, providerIdx: (player.providerIdx + 1) % PROVIDERS.length });
  };

  const playerUrl = player
    ? PROVIDERS[player.providerIdx].build(player.item.mal_id, player.episode, player.audioTrack === "dub")
    : "";

  return (
    <div style={{ flex: 1, position: "relative", display: "flex", flexDirection: "column", minWidth: 0, background: bg }}>
      {/* Header */}
      <div style={{
        padding: "16px 22px", borderBottom: "1px solid rgba(255,255,255,0.06)",
        display: "flex", alignItems: "center", gap: "12px",
        background: "rgba(0,0,0,0.4)", backdropFilter: "blur(10px)", zIndex: 5,
      }}>
        <Tv2 size={20} style={{ color: accent, filter: `drop-shadow(0 0 8px ${accent})` }} />
        <span style={{ fontSize: "16px", fontWeight: 600, letterSpacing: "0.3px", color: "#fff" }}>Anime</span>
        <div style={{ flex: 1, position: "relative", maxWidth: "360px", marginLeft: "auto" }}>
          <Search style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.3)", width: "14px", height: "14px", pointerEvents: "none" }} />
          <input
            value={searchQ}
            onChange={e => { setSearchQ(e.target.value); setTab(e.target.value.trim() ? "search" : "browse"); }}
            placeholder="Search anime..."
            autoComplete="off" spellCheck={false}
            style={{
              width: "100%", padding: "8px 12px 8px 34px",
              borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)",
              background: "rgba(255,255,255,0.04)", color: "#fff", outline: "none", fontSize: "12px",
            }}
            onFocus={e => (e.currentTarget.style.borderColor = `${accent}66`)}
            onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
          />
          {searchQ && (
            <button onClick={() => { setSearchQ(""); setTab("browse"); }} style={{ position: "absolute", right: "8px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex" }}>
              <X size={13} />
            </button>
          )}
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px 22px" }}>
        {tab === "search" ? (
          <SearchResults q={searchQ} loading={searchLoading} results={searchResults} onPick={openDetails} accent={accent} />
        ) : (
          <>
            {/* Continue Watching */}
            {continueWatching.length > 0 && (
              <ContinueWatchingShelf
                items={continueWatching}
                accent={accent}
                onPlay={e => {
                  const animeItem = Object.values(rows).flat().find(a => a.mal_id === Number(e.id));
                  if (animeItem) play(animeItem, e.episode ?? 1, e.audioTrack ?? "sub");
                }}
                onRemove={e => { removeFromHistory(e.id, "anime"); setContinueWatching(getWatchHistory().filter(h => h.type === "anime")); }}
              />
            )}

            {/* Hero */}
            {(() => {
              const hero = (rows[ANIME_CATEGORIES[0].id] || [])[0];
              if (!hero) return null;
              return <AnimeHero item={hero} accent={accent} onPlay={() => play(hero, 1, "sub")} onInfo={() => openDetails(hero)} />;
            })()}

            {loading && Object.keys(rows).length === 0 && <LoadingSkel />}

            {animeWatchlist.length > 0 && (
              <AnimeShelf title="❤️ My Anime List" items={animeWatchlist.map(w => ({ mal_id: Number(w.id), title: w.title, poster: w.poster || null, year: "", rating: 0, episodes: null, overview: "", backdrop: null, kind: "anime" as const, status: "" }))} onPick={openDetails} accent={accent} />
            )}
            {ANIME_CATEGORIES.map(cat => (
              <AnimeShelf key={cat.id} title={cat.label} items={rows[cat.id] || []} onPick={openDetails} accent={accent} watchlist={animeWatchlist} onToggleWatchlist={toggleAnimeWl} />
            ))}

            {error && <div style={{ color: "rgba(255,255,255,0.5)", padding: "40px", textAlign: "center" }}>{error}</div>}
          </>
        )}
      </div>

      {/* Details modal */}
      {details && (
        <AnimeDetailsModal
          details={details}
          loading={detailsLoading}
          accent={accent}
          onClose={() => setDetails(null)}
          onPlay={(ep, track) => play(details.item, ep, track)}
        />
      )}

      {/* Player */}
      {player && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.96)", zIndex: 1000, display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "12px 18px", display: "flex", alignItems: "center", gap: "10px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
            <button onClick={() => setPlayer(null)}
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", fontSize: "12px", cursor: "pointer" }}>
              <X size={13} /> Close
            </button>
            <div style={{ fontWeight: 600, fontSize: "14px", color: "#fff" }}>
              {player.item.title}
              <span style={{ color: "rgba(255,255,255,0.5)", fontWeight: 400, fontSize: "12px", marginLeft: "8px" }}>Ep {player.episode}</span>
            </div>

            {/* Sub/Dub toggle */}
            <div style={{ display: "flex", gap: "4px", marginLeft: "8px" }}>
              {(["sub", "dub"] as const).map(track => (
                <button key={track} onClick={() => { setPlayer({ ...player, audioTrack: track, providerIdx: 0 }); saveToHistory({ id: player.item.mal_id, type: "anime", title: player.item.title, poster: player.item.poster, episode: player.episode, audioTrack: track }); }}
                  style={{
                    padding: "5px 10px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.15)",
                    background: player.audioTrack === track ? accent : "rgba(255,255,255,0.06)",
                    color: "#fff", fontSize: "11px", fontWeight: 600, cursor: "pointer",
                    textTransform: "uppercase", letterSpacing: "0.5px",
                  }}>
                  {track}
                </button>
              ))}
            </div>

            <div style={{ marginLeft: "auto", display: "flex", gap: "8px", alignItems: "center" }}>
              <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.5)" }}>Source:</span>
              <select value={player.providerIdx} onChange={e => setPlayer({ ...player, providerIdx: Number(e.target.value) })}
                style={{ padding: "6px 10px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.06)", color: "#fff", fontSize: "12px", cursor: "pointer", outline: "none" }}>
                {PROVIDERS.map((p, i) => <option key={p.name} value={i} style={{ background: "#1a1a1a" }}>{p.name}</option>)}
              </select>
              <button onClick={tryNext} style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", fontSize: "12px", cursor: "pointer" }}>
                <RefreshCw size={12} /> Next source
              </button>
              <DownloadBtn url={playerUrl} title={`${player.item.title} Ep${player.episode}`} />
              <button onClick={() => window.open(playerUrl, "_blank", "noopener,noreferrer")}
                style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", fontSize: "12px", cursor: "pointer" }}>
                <ExternalLink size={12} /> New tab
              </button>
            </div>
          </div>
          <div style={{ flex: 1, position: "relative", background: "#000" }}>
            <iframe
              key={`${player.item.mal_id}-${player.episode}-${player.audioTrack}-${player.providerIdx}`}
              src={playerUrl}
              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: "none", background: "#000" }}
              allow="autoplay; fullscreen; picture-in-picture; encrypted-media; gyroscope; accelerometer"
              allowFullScreen
               referrerPolicy="strict-origin-when-cross-origin"
              title={player.item.title}
            />
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Sub-components ─────────────────────────────────────── */

function DownloadBtn({ url, title }: { url: string; title: string }) {
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const handle = () => {
    if (state === "loading") return;
    setState("loading");
    const apiUrl = `${API_BASE}/download?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`;
    window.location.href = apiUrl;
    setTimeout(() => setState("idle"), 5000);
  };
  const label = state === "loading" ? "Fetching…" : state === "error" ? "Unavailable" : "Download";
  const bg = state === "loading" ? "rgba(0,150,255,0.15)" : state === "error" ? "rgba(255,60,60,0.15)" : "rgba(255,255,255,0.06)";
  const bc = state === "loading" ? "rgba(0,150,255,0.4)" : state === "error" ? "rgba(255,60,60,0.4)" : "rgba(255,255,255,0.1)";
  const color = state === "loading" ? "#0096ff" : state === "error" ? "#ff4444" : "#fff";
  return (
    <button onClick={handle} title="Download in best quality"
      style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 12px", borderRadius: "8px", background: bg, border: `1px solid ${bc}`, color, fontSize: "12px", cursor: state === "loading" ? "default" : "pointer", transition: "all 0.2s" }}>
      <Download size={12} style={{ animation: state === "loading" ? "spin 1s linear infinite" : "none" }} />
      {label}
      <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>
    </button>
  );
}

function LoadingSkel() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "12px" }}>
      {Array.from({ length: 18 }).map((_, i) => (
        <div key={i} style={{ aspectRatio: "2/3", borderRadius: "10px", background: "rgba(255,255,255,0.04)", animation: "pulse 1.4s ease-in-out infinite" }} />
      ))}
      <style>{`@keyframes pulse { 0%,100%{opacity:.4} 50%{opacity:.7} }`}</style>
    </div>
  );
}

function AnimeHero({ item, accent, onPlay, onInfo }: { item: AnimeItem; accent: string; onPlay: () => void; onInfo: () => void }) {
  return (
    <div style={{
      position: "relative", height: "300px", borderRadius: "14px", overflow: "hidden", marginBottom: "26px",
      background: item.backdrop ? `url(${item.backdrop}) center/cover` : item.poster ? `url(${item.poster}) center/cover` : "#1a1a1a",
    }}>
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to right, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.55) 60%, rgba(0,0,0,0.2) 100%)" }} />
      <div style={{ position: "absolute", inset: 0, padding: "30px 36px", display: "flex", flexDirection: "column", justifyContent: "flex-end", maxWidth: "600px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
          <span style={{ fontSize: "11px", padding: "3px 8px", borderRadius: "6px", background: accent, color: "#fff", fontWeight: 600, letterSpacing: "0.5px" }}>ANIME</span>
          {item.year && <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.7)" }}>{item.year}</span>}
          {item.rating > 0 && <span style={{ display: "inline-flex", alignItems: "center", gap: "3px", fontSize: "12px", color: "rgba(255,255,255,0.85)" }}><Star size={12} fill="#f5c518" color="#f5c518" /> {item.rating.toFixed(1)}</span>}
          {item.episodes && <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.6)" }}>{item.episodes} ep</span>}
        </div>
        <h2 style={{ fontSize: "28px", fontWeight: 700, color: "#fff", margin: "0 0 10px", lineHeight: 1.1 }}>{item.title}</h2>
        <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.75)", lineHeight: 1.55, margin: "0 0 16px", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
          {item.overview || ""}
        </p>
        <div style={{ display: "flex", gap: "8px" }}>
          <button onClick={onPlay} style={{ display: "flex", alignItems: "center", gap: "8px", padding: "9px 16px", borderRadius: "9px", background: "#fff", color: "#000", border: "none", fontSize: "13px", fontWeight: 600, cursor: "pointer" }}>
            <Play size={14} fill="#000" /> Play (Sub)
          </button>
          <button onClick={onInfo} style={{ display: "flex", alignItems: "center", gap: "8px", padding: "9px 16px", borderRadius: "9px", background: "rgba(255,255,255,0.15)", color: "#fff", border: "1px solid rgba(255,255,255,0.2)", fontSize: "13px", fontWeight: 600, cursor: "pointer", backdropFilter: "blur(10px)" }}>
            More Info
          </button>
        </div>
      </div>
    </div>
  );
}

const navBtn: React.CSSProperties = {
  display: "flex", alignItems: "center", justifyContent: "center",
  width: "26px", height: "26px", borderRadius: "6px",
  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
  color: "rgba(255,255,255,0.7)", cursor: "pointer",
};

function AnimePoster({ item, onPick, accent, fixed, onToggleWatchlist, isWatchlisted }: { item: AnimeItem; onPick: (i: AnimeItem) => void; accent: string; fixed?: boolean; onToggleWatchlist?: () => void; isWatchlisted?: boolean }) {
  return (
    <div role="button" tabIndex={0} onClick={() => onPick(item)} onKeyDown={e => e.key === "Enter" && onPick(item)} title={item.title}
      style={{ position: "relative", flexShrink: 0, width: fixed ? "150px" : undefined, aspectRatio: "2/3", borderRadius: "10px", overflow: "hidden", background: "#111", border: "1px solid rgba(255,255,255,0.08)", cursor: "pointer", transition: "transform 0.15s, border-color 0.15s, box-shadow 0.15s" }}
      onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px) scale(1.02)"; e.currentTarget.style.borderColor = `${accent}88`; e.currentTarget.style.boxShadow = `0 10px 28px ${accent}44`; }}
      onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; e.currentTarget.style.boxShadow = "none"; }}
    >
      {item.poster
        ? <img src={item.poster} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        : <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "rgba(255,255,255,0.4)", fontSize: "12px", padding: "10px", textAlign: "center" }}>{item.title}</div>
      }
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "20px 8px 6px", background: "linear-gradient(to top, rgba(0,0,0,0.92), rgba(0,0,0,0))", color: "#fff", fontSize: "11px" }}>
        <div style={{ fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.title}</div>
        <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "2px", color: "rgba(255,255,255,0.6)", fontSize: "10px" }}>
          {item.year && <span>{item.year}</span>}
          {item.rating > 0 && <span style={{ display: "inline-flex", alignItems: "center", gap: "2px" }}><Star size={9} fill="#f5c518" color="#f5c518" /> {item.rating.toFixed(1)}</span>}
        </div>
      </div>
      {onToggleWatchlist && (
        <button onClick={e => { e.stopPropagation(); onToggleWatchlist(); }} title={isWatchlisted ? "Remove from My List" : "Add to My List"}
          style={{ position: "absolute", top: "6px", right: "6px", width: "26px", height: "26px", borderRadius: "50%", background: "rgba(0,0,0,0.75)", border: `1px solid ${isWatchlisted ? accent : "rgba(255,255,255,0.25)"}`, color: isWatchlisted ? accent : "rgba(255,255,255,0.7)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", padding: 0, zIndex: 2, transition: "all 0.15s" }}>
          <Heart size={11} fill={isWatchlisted ? accent : "none"} />
        </button>
      )}
    </div>
  );
}

function AnimeShelf({ title, items, onPick, accent, watchlist, onToggleWatchlist }: { title: string; items: AnimeItem[]; onPick: (i: AnimeItem) => void; accent: string; watchlist?: WatchlistItem[]; onToggleWatchlist?: (item: AnimeItem) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => ref.current?.scrollBy({ left: dir * 600, behavior: "smooth" });
  if (!items.length) return null;
  return (
    <div style={{ marginBottom: "26px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
        <h3 style={{ fontSize: "14px", fontWeight: 600, color: "#fff", margin: 0 }}>{title}</h3>
        <div style={{ display: "flex", gap: "4px" }}>
          <button onClick={() => scroll(-1)} style={navBtn}><ChevronLeft size={14} /></button>
          <button onClick={() => scroll(1)} style={navBtn}><ChevronRight size={14} /></button>
        </div>
      </div>
      <div ref={ref} style={{ display: "flex", gap: "10px", overflowX: "auto", scrollbarWidth: "none", paddingBottom: "4px" }}>
        {items.map(it => <AnimePoster key={it.mal_id} item={it} onPick={onPick} accent={accent} fixed
          isWatchlisted={watchlist ? watchlist.some(w => w.id === it.mal_id) : undefined}
          onToggleWatchlist={onToggleWatchlist ? () => onToggleWatchlist(it) : undefined}
        />)}
      </div>
    </div>
  );
}

function SearchResults({ q, loading, results, onPick, accent }: { q: string; loading: boolean; results: AnimeItem[]; onPick: (i: AnimeItem) => void; accent: string }) {
  if (!q.trim()) return <div style={{ color: "rgba(255,255,255,0.4)", textAlign: "center", padding: "60px" }}>Type to search anime…</div>;
  if (loading) return <LoadingSkel />;
  if (!results.length) return <div style={{ color: "rgba(255,255,255,0.4)", textAlign: "center", padding: "60px" }}>No results for "{q}".</div>;
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "12px" }}>
      {results.map(it => <AnimePoster key={it.mal_id} item={it} onPick={onPick} accent={accent} />)}
    </div>
  );
}

function ContinueWatchingShelf({ items, accent, onPlay, onRemove }: { items: WatchEntry[]; accent: string; onPlay: (e: WatchEntry) => void; onRemove: (e: WatchEntry) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => ref.current?.scrollBy({ left: dir * 600, behavior: "smooth" });
  return (
    <div style={{ marginBottom: "26px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
        <h3 style={{ fontSize: "14px", fontWeight: 600, color: "#fff", margin: 0 }}>Continue Watching</h3>
        <div style={{ display: "flex", gap: "4px" }}>
          <button onClick={() => scroll(-1)} style={navBtn}><ChevronLeft size={14} /></button>
          <button onClick={() => scroll(1)} style={navBtn}><ChevronRight size={14} /></button>
        </div>
      </div>
      <div ref={ref} style={{ display: "flex", gap: "10px", overflowX: "auto", scrollbarWidth: "none", paddingBottom: "4px" }}>
        {items.map(entry => (
          <div key={`${entry.type}-${entry.id}`} style={{ position: "relative", flexShrink: 0, width: "150px" }}>
            <button onClick={() => onPlay(entry)} title={entry.title}
              style={{
                position: "relative", width: "100%", aspectRatio: "2/3", borderRadius: "10px", overflow: "hidden",
                background: "#111", border: `1px solid ${accent}44`, cursor: "pointer", padding: 0,
                transition: "transform 0.15s, box-shadow 0.15s",
              }}
              onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px) scale(1.02)"; e.currentTarget.style.boxShadow = `0 10px 28px ${accent}44`; }}
              onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "none"; }}>
              {entry.poster && <img src={entry.poster} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />}
              <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.4)", display: "flex", alignItems: "center", justifyContent: "center", opacity: 0, transition: "opacity 0.15s" }}
                onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
                onMouseLeave={e => (e.currentTarget.style.opacity = "0")}>
                <Play size={32} fill={accent} color={accent} />
              </div>
              <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "16px 8px 6px", background: "linear-gradient(to top, rgba(0,0,0,0.95), rgba(0,0,0,0))" }}>
                <div style={{ fontWeight: 600, fontSize: "11px", color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{entry.title}</div>
                <div style={{ fontSize: "10px", color: accent, marginTop: "2px", fontWeight: 600 }}>
                  {formatProgress(entry)}{entry.audioTrack && ` · ${entry.audioTrack.toUpperCase()}`}
                </div>
              </div>
            </button>
            <button onClick={() => onRemove(entry)} title="Remove"
              style={{ position: "absolute", top: "5px", right: "5px", width: "20px", height: "20px", borderRadius: "50%", background: "rgba(0,0,0,0.7)", border: "1px solid rgba(255,255,255,0.2)", color: "rgba(255,255,255,0.7)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
              <X size={10} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function AnimeDetailsModal({ details, loading, accent, onClose, onPlay }: {
  details: AnimeDetails;
  loading: boolean;
  accent: string;
  onClose: () => void;
  onPlay: (ep: number, track: "sub" | "dub") => void;
}) {
  const { item, episodes } = details;
  const [audioTrack, setAudioTrack] = useState<"sub" | "dub">("sub");
  if (!item) return null;
  const totalEps = item.episodes || episodes.length || 1;
  const epList = episodes.length > 0
    ? episodes
    : Array.from({ length: Math.min(totalEps, 100) }, (_, i) => ({ number: i + 1, title: `Episode ${i + 1}`, aired: null }));

  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 900, display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "30px 20px", overflowY: "auto" }}>
      <div onClick={e => e.stopPropagation()} style={{ width: "100%", maxWidth: "880px", background: "#0e0e0e", borderRadius: "14px", overflow: "hidden", border: "1px solid rgba(255,255,255,0.08)", marginBottom: "30px" }}>
        <div style={{ position: "relative", height: "240px", background: item.backdrop ? `url(${item.backdrop}) center/cover` : item.poster ? `url(${item.poster}) center top/cover` : "#1a1a1a" }}>
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(0,0,0,0.3), #0e0e0e)" }} />
          <button onClick={onClose} style={{ position: "absolute", top: "14px", right: "14px", width: "32px", height: "32px", borderRadius: "50%", background: "rgba(0,0,0,0.6)", border: "1px solid rgba(255,255,255,0.15)", color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <X size={16} />
          </button>
        </div>
        <div style={{ padding: "0 26px 26px", marginTop: "-50px", position: "relative" }}>
          <h2 style={{ fontSize: "22px", fontWeight: 700, color: "#fff", margin: "0 0 8px" }}>{item.title}</h2>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "14px", fontSize: "12px", color: "rgba(255,255,255,0.65)" }}>
            {item.year && <span>{item.year}</span>}
            {item.rating > 0 && <span style={{ display: "inline-flex", alignItems: "center", gap: "3px" }}><Star size={11} fill="#f5c518" color="#f5c518" /> {item.rating.toFixed(1)}</span>}
            {item.episodes && <span>{item.episodes} episodes</span>}
            <span style={{ padding: "2px 7px", borderRadius: "4px", background: "rgba(255,255,255,0.08)", textTransform: "uppercase", fontSize: "10px", fontWeight: 600 }}>Anime</span>
          </div>

          {/* Sub/Dub + Play */}
          <div style={{ display: "flex", gap: "8px", marginBottom: "16px", alignItems: "center" }}>
            {(["sub", "dub"] as const).map(track => (
              <button key={track} onClick={() => setAudioTrack(track)}
                style={{ padding: "7px 14px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.15)", background: audioTrack === track ? accent : "rgba(255,255,255,0.06)", color: "#fff", fontSize: "12px", fontWeight: 600, cursor: "pointer", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                {track}
              </button>
            ))}
            <button onClick={() => onPlay(1, audioTrack)}
              style={{ display: "inline-flex", alignItems: "center", gap: "8px", padding: "7px 16px", borderRadius: "8px", background: "#fff", color: "#000", border: "none", fontSize: "13px", fontWeight: 600, cursor: "pointer" }}>
              <Play size={14} fill="#000" /> Play Ep 1
            </button>
          </div>

          <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.78)", lineHeight: 1.6, margin: "0 0 22px" }}>{item.overview || "No description available."}</p>

          {/* Episode list */}
          <h3 style={{ fontSize: "14px", color: "#fff", margin: "0 0 12px", fontWeight: 600 }}>
            Episodes {loading && <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)", fontWeight: 400 }}>Loading…</span>}
          </h3>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px", maxHeight: "340px", overflowY: "auto" }}>
            {epList.map(ep => (
              <button key={ep.number} onClick={() => onPlay(ep.number, audioTrack)}
                style={{
                  display: "flex", alignItems: "center", gap: "12px", padding: "10px 12px",
                  borderRadius: "8px", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)",
                  cursor: "pointer", textAlign: "left", transition: "background 0.12s, border-color 0.12s",
                }}
                onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.07)"; e.currentTarget.style.borderColor = `${accent}66`; }}
                onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.03)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.06)"; }}>
                <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: `${accent}18`, border: `1px solid ${accent}33`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <Play size={12} fill={accent} color={accent} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: "12px", fontWeight: 600, color: "#fff" }}>Episode {ep.number}{ep.title !== `Episode ${ep.number}` ? ` — ${ep.title}` : ""}</div>
                  {ep.aired && <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", marginTop: "2px" }}>{ep.aired}</div>}
                </div>
                <div style={{ fontSize: "11px", color: accent, fontWeight: 600, textTransform: "uppercase", flexShrink: 0 }}>{audioTrack}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
