/* Custom SVG logos for all Phoenix app sections */

interface IconProps { size?: number; color?: string; accent?: string; }

export function HomeIcon2({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9.5z" />
      <path d="M9 21V12h6v9" />
    </svg>
  );
}

export function GamesIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="7" width="20" height="12" rx="4" />
      <path d="M12 2v3M8 2v2M16 2v2" strokeWidth="1.5" />
      <line x1="8" y1="13" x2="8" y2="17" />
      <line x1="6" y1="15" x2="10" y2="15" />
      <circle cx="16" cy="14" r="1" fill={color} stroke="none" />
      <circle cx="18" cy="16" r="1" fill={color} stroke="none" />
    </svg>
  );
}

export function MoviesIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <path d="M7 4v16M17 4v16M2 8h5M17 8h5M2 12h20M2 16h5M17 16h5" strokeWidth="1.4" />
    </svg>
  );
}

export function TVIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="5" width="20" height="14" rx="2" />
      <path d="M8 21h8M12 19v2" />
      <path d="M8 5l4-3 4 3" strokeWidth="1.4" />
      <path d="M7 12l4-2v4l-4-2z" fill={color} stroke="none" />
    </svg>
  );
}

export function AnimeIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6L12 2z" />
    </svg>
  );
}

export function MusicIcon2({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="8" cy="18" r="3" />
      <circle cx="18" cy="16" r="3" />
      <path d="M11 18V7l10-2v11" strokeWidth="1.6" />
      <path d="M11 11l10-2" strokeWidth="1.4" />
    </svg>
  );
}

export function AIIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2a4 4 0 0 1 4 4v1h1a3 3 0 0 1 3 3v2a3 3 0 0 1-3 3h-1v1a4 4 0 0 1-8 0v-1H7a3 3 0 0 1-3-3V10a3 3 0 0 1 3-3h1V6a4 4 0 0 1 4-4z" />
      <circle cx="9.5" cy="10.5" r="1" fill={color} stroke="none" />
      <circle cx="14.5" cy="10.5" r="1" fill={color} stroke="none" />
      <path d="M9 14s1 1.5 3 1.5 3-1.5 3-1.5" strokeWidth="1.5" />
      <path d="M12 2v-1M19.07 4.93l.71-.71M22 12h1M19.07 19.07l.71.71M12 22v1M4.93 19.07l-.71.71M2 12H1M4.93 4.93l-.71-.71" strokeWidth="1.3" />
    </svg>
  );
}

export function AppsIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </svg>
  );
}

export function HTMLIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 4l1.5 16L12 22l6.5-2L20 4H4z" />
      <path d="M8 8h8l-.5 5.5L12 15l-3.5-1.5L8.25 11H16" strokeWidth="1.5" />
    </svg>
  );
}

export function ChatIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
      <line x1="8" y1="10" x2="16" y2="10" strokeWidth="1.5" />
      <line x1="8" y1="14" x2="13" y2="14" strokeWidth="1.5" />
    </svg>
  );
}

export function SettingsIcon2({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

export function IncognitoIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 5C7 5 2.73 8.11 1 12.5 2.73 16.89 7 20 12 20s9.27-3.11 11-7.5C21.27 8.11 17 5 12 5z" />
      <circle cx="12" cy="12" r="3" />
      <line x1="2" y1="2" x2="22" y2="22" strokeWidth="2" />
    </svg>
  );
}

export function BrowserIcon({ size = 20, color = "#fff" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="2" y1="12" x2="22" y2="12" />
      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
    </svg>
  );
}

export function PhoenixLogoFull({ width = 160, accent = "#f97316" }: { width?: number; accent?: string }) {
  return (
    <svg width={width} height={width * 0.4} viewBox="0 0 400 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Phoenix pixel bird */}
      <g transform="scale(3.5) translate(0, 2)">
        <rect x="7" y="14" width="2" height="1" fill={accent} />
        <rect x="6" y="13" width="4" height="1" fill={accent} opacity="0.9" />
        <rect x="5" y="13" width="1" height="2" fill={accent} />
        <rect x="10" y="13" width="1" height="2" fill={accent} />
        <rect x="5" y="8" width="6" height="5" fill={accent} opacity="0.9" />
        <rect x="4" y="9" width="1" height="3" fill={accent} opacity="0.8" />
        <rect x="11" y="9" width="1" height="3" fill={accent} opacity="0.8" />
        <rect x="1" y="7" width="4" height="3" fill={accent} />
        <rect x="11" y="7" width="4" height="3" fill={accent} />
        <rect x="6" y="4" width="4" height="4" fill={accent} />
        <rect x="5" y="5" width="1" height="2" fill={accent} />
        <rect x="10" y="5" width="1" height="2" fill={accent} />
        <rect x="6" y="3" width="1" height="2" fill="#fbbf24" />
        <rect x="8" y="1" width="1" height="3" fill="#f59e0b" />
        <rect x="10" y="2" width="1" height="2" fill="#fbbf24" />
        <rect x="7" y="2" width="2" height="1" fill="#fde68a" />
        <rect x="6" y="5" width="1" height="1" fill="#111" />
        <rect x="9" y="5" width="1" height="1" fill="#111" />
      </g>
      {/* PHOENIX text */}
      <text x="62" y="66" fontFamily="system-ui, -apple-system, sans-serif" fontWeight="800" fontSize="42" fill="white" letterSpacing="-1">PHOENIX</text>
      <text x="63" y="86" fontFamily="system-ui, -apple-system, sans-serif" fontWeight="400" fontSize="13" fill="rgba(255,255,255,0.35)" letterSpacing="4">OPEN WEB PORTAL</text>
    </svg>
  );
}

export function PhoenixWordmark({ accent = "#f97316" }: { accent?: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
      <svg width="28" height="28" viewBox="0 0 16 16" style={{ imageRendering: "pixelated" }} xmlns="http://www.w3.org/2000/svg">
        <rect x="7" y="14" width="2" height="1" fill={accent} />
        <rect x="6" y="13" width="4" height="1" fill={accent} />
        <rect x="5" y="13" width="1" height="2" fill={accent} />
        <rect x="10" y="13" width="1" height="2" fill={accent} />
        <rect x="4" y="14" width="1" height="1" fill={accent} />
        <rect x="11" y="14" width="1" height="1" fill={accent} />
        <rect x="5" y="8" width="6" height="5" fill={accent} />
        <rect x="4" y="9" width="1" height="3" fill={accent} />
        <rect x="11" y="9" width="1" height="3" fill={accent} />
        <rect x="6" y="8" width="4" height="1" fill="#fed7aa" />
        <rect x="1" y="7" width="4" height="3" fill={accent} />
        <rect x="11" y="7" width="4" height="3" fill={accent} />
        <rect x="6" y="9" width="4" height="2" fill="#fed7aa" />
        <rect x="7" y="11" width="2" height="1" fill="#fed7aa" />
        <rect x="6" y="4" width="4" height="4" fill={accent} />
        <rect x="5" y="5" width="1" height="2" fill={accent} />
        <rect x="10" y="5" width="1" height="2" fill={accent} />
        <rect x="6" y="3" width="1" height="2" fill="#fbbf24" />
        <rect x="8" y="1" width="1" height="3" fill="#f59e0b" />
        <rect x="10" y="2" width="1" height="2" fill="#fbbf24" />
        <rect x="7" y="2" width="2" height="1" fill="#fde68a" />
        <rect x="6" y="5" width="1" height="1" fill="#1c1c1c" />
        <rect x="9" y="5" width="1" height="1" fill="#1c1c1c" />
      </svg>
      <span style={{ fontWeight: 700, fontSize: "16px", color: "#fff", letterSpacing: "-0.02em" }}>Phoenix</span>
    </div>
  );
}
