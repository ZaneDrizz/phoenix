import { useState, useRef } from "react";
import { Music, Search, X, Play, ExternalLink, ChevronLeft, ChevronRight } from "lucide-react";

interface Playlist {
  id: string;
  name: string;
  description: string;
  gradient: string;
  emoji: string;
  genre: string;
}

const GENRES = [
  "Featured", "Pop", "Hip-Hop", "Rock", "Electronic", "R&B", "Latin",
  "Country", "Classical", "Jazz", "Chill", "Gaming", "Workout",
];

const PLAYLISTS: Playlist[] = [
  // Featured
  { id: "37i9dQZF1DXcBWIGoYBM5M", name: "Today's Top Hits",      description: "The biggest songs right now",           genre: "Featured",    emoji: "🔥", gradient: "linear-gradient(135deg,#e80074,#9b00e8)" },
  { id: "37i9dQZF1DX0XUsuxWHRQd", name: "Hot Hits USA",           description: "What's hot across the country",        genre: "Featured",    emoji: "🇺🇸", gradient: "linear-gradient(135deg,#1a8cff,#c80058)" },
  { id: "37i9dQZF1DXaXB8fQg7xif", name: "Dance Party",            description: "Get the party started",                genre: "Featured",    emoji: "🎉", gradient: "linear-gradient(135deg,#ff6b00,#e80074)" },
  { id: "37i9dQZF1DX4WYpdgoIcn6", name: "Chill Hits",             description: "Kick back and relax",                  genre: "Featured",    emoji: "😌", gradient: "linear-gradient(135deg,#0078ff,#00c9a7)" },
  { id: "37i9dQZF1DX76Wlfdnj7AP", name: "Beast Mode",             description: "Get in the zone",                      genre: "Featured",    emoji: "💪", gradient: "linear-gradient(135deg,#ff4e00,#ec9f05)" },
  // Pop
  { id: "37i9dQZF1DXcBWIGoYBM5M", name: "Today's Top Hits",      description: "The biggest songs right now",           genre: "Pop",         emoji: "⭐", gradient: "linear-gradient(135deg,#e80074,#9b00e8)" },
  { id: "37i9dQZF1DX4WYpdgoIcn6", name: "Pop Rising",             description: "Tomorrow's hits, today",               genre: "Pop",         emoji: "🌟", gradient: "linear-gradient(135deg,#ff80ab,#ea00d9)" },
  { id: "37i9dQZF1DXb7kCgr26Acy", name: "Pop All Day",            description: "Non-stop pop bangers",                 genre: "Pop",         emoji: "🎵", gradient: "linear-gradient(135deg,#ff6ec7,#ff5bae)" },
  { id: "37i9dQZF1DWUa8ZRTfalHk", name: "Pop Punk's Not Dead",    description: "Energy and attitude",                  genre: "Pop",         emoji: "🎸", gradient: "linear-gradient(135deg,#1f1f1f,#e91e63)" },
  // Hip-Hop
  { id: "37i9dQZF1DX0XUsuxWHRQd", name: "Rap Caviar",             description: "Hip hop central",                      genre: "Hip-Hop",     emoji: "🎤", gradient: "linear-gradient(135deg,#000,#ffd700)" },
  { id: "37i9dQZF1DXdEKclS5LJKM", name: "Most Necessary",         description: "Today's hottest hip hop",              genre: "Hip-Hop",     emoji: "🔊", gradient: "linear-gradient(135deg,#1a1a1a,#e33d00)" },
  { id: "37i9dQZF1DX2RxBh64BHjQ", name: "Hood Classics",          description: "Certified hood classics",              genre: "Hip-Hop",     emoji: "🏆", gradient: "linear-gradient(135deg,#111,#ffa500)" },
  { id: "37i9dQZF1DX48TBNLNW4FW", name: "Trap Nation",            description: "Heavy trap beats",                     genre: "Hip-Hop",     emoji: "💿", gradient: "linear-gradient(135deg,#0a0a0a,#6200ea)" },
  // Rock
  { id: "37i9dQZF1DWXRqgorJj26U", name: "Rock Classics",          description: "Rock legends & anthems",               genre: "Rock",        emoji: "🤘", gradient: "linear-gradient(135deg,#1a0000,#cc0000)" },
  { id: "37i9dQZF1DXdLtD0qszB98", name: "Rock This",              description: "Today's rock hits",                    genre: "Rock",        emoji: "🎸", gradient: "linear-gradient(135deg,#222,#cc4400)" },
  { id: "37i9dQZF1DX9qNs32fujYe", name: "All New Rock",           description: "Fresh rock tracks",                    genre: "Rock",        emoji: "🔥", gradient: "linear-gradient(135deg,#1c1c1c,#880000)" },
  { id: "37i9dQZF1DWWzBc2b1oVPZ", name: "Hard Rock",              description: "Loud & proud",                         genre: "Rock",        emoji: "💀", gradient: "linear-gradient(135deg,#0a0a0a,#555)" },
  // Electronic
  { id: "37i9dQZF1DX4dyzvuaRJ0n", name: "mint",                   description: "The best new electronic music",        genre: "Electronic",  emoji: "🟢", gradient: "linear-gradient(135deg,#00b09b,#96c93d)" },
  { id: "37i9dQZF1DX6J5NfMjj9YS", name: "Electronic Rising",      description: "The next wave of electronic",          genre: "Electronic",  emoji: "⚡", gradient: "linear-gradient(135deg,#0575e6,#021b79)" },
  { id: "37i9dQZF1DX2A29LI7xHn1", name: "Rave",                   description: "Hard-hitting rave anthems",            genre: "Electronic",  emoji: "🌀", gradient: "linear-gradient(135deg,#12c2e9,#f64f59)" },
  { id: "37i9dQZF1DXa2PmaDOJegR", name: "Techno Bunker",          description: "Pure techno, unfiltered",              genre: "Electronic",  emoji: "🏭", gradient: "linear-gradient(135deg,#000,#333)" },
  // R&B
  { id: "37i9dQZF1DX4SBhb3fqCJd", name: "R&B Hits",               description: "The best new R&B",                     genre: "R&B",         emoji: "🎙️", gradient: "linear-gradient(135deg,#8e0e00,#1f1c18)" },
  { id: "37i9dQZF1DX2UgsUIg75Vg", name: "Soul Coffee",            description: "Rich soulful music",                   genre: "R&B",         emoji: "☕", gradient: "linear-gradient(135deg,#2c3e50,#bdc3c7)" },
  { id: "37i9dQZF1DXbYM3nMM0oPk", name: "Night Rider",            description: "Late night R&B vibes",                 genre: "R&B",         emoji: "🌙", gradient: "linear-gradient(135deg,#1a1a2e,#e94560)" },
  // Latin
  { id: "37i9dQZF1DX10zKzsJ2jva", name: "Latin Hot 100",          description: "La música más popular",                genre: "Latin",       emoji: "🔥", gradient: "linear-gradient(135deg,#e44d26,#f7a61c)" },
  { id: "37i9dQZF1DX5gQonLbZD9s", name: "Baila Reggaeton",        description: "El mejor reggaeton",                   genre: "Latin",       emoji: "🕺", gradient: "linear-gradient(135deg,#ee0979,#ff6a00)" },
  { id: "37i9dQZF1DX1KSsuBdIFJf", name: "Viva Latino",            description: "Latin heat all day",                  genre: "Latin",       emoji: "💃", gradient: "linear-gradient(135deg,#c90032,#ff7c00)" },
  // Country
  { id: "37i9dQZF1DX1lVhptIYRda", name: "Hot Country",            description: "Country's biggest hits",               genre: "Country",     emoji: "🤠", gradient: "linear-gradient(135deg,#b45309,#78350f)" },
  { id: "37i9dQZF1DX1H7L54ZfhOt", name: "Country Roads",          description: "Classic country feels",                genre: "Country",     emoji: "🌾", gradient: "linear-gradient(135deg,#5d4037,#bcaaa4)" },
  { id: "37i9dQZF1DX7v9oPDt1SuK", name: "New Boots",              description: "Brand new country",                    genre: "Country",     emoji: "👢", gradient: "linear-gradient(135deg,#4e342e,#d7ccc8)" },
  // Classical
  { id: "37i9dQZF1DWWEJlAGA9gs0", name: "Classical Essentials",   description: "The greatest classical works",         genre: "Classical",   emoji: "🎻", gradient: "linear-gradient(135deg,#2c2c54,#aaa6c3)" },
  { id: "37i9dQZF1DX4sWSpwq3LiO", name: "Classical Focus",        description: "Music to help you concentrate",        genre: "Classical",   emoji: "📚", gradient: "linear-gradient(135deg,#141414,#4a4a8a)" },
  { id: "37i9dQZF1DWVFeEut75IAL", name: "Classical Piano",        description: "Piano masterpieces",                   genre: "Classical",   emoji: "🎹", gradient: "linear-gradient(135deg,#1a1a1a,#8a8a9a)" },
  // Jazz
  { id: "37i9dQZF1DXbITWG1ZJKYt", name: "Jazz Classics",          description: "The essential jazz collection",         genre: "Jazz",        emoji: "🎷", gradient: "linear-gradient(135deg,#1a0533,#e9b44c)" },
  { id: "37i9dQZF1DX5NPOcIqBMEB", name: "Jazz Vibes",             description: "Smooth jazz all day",                  genre: "Jazz",        emoji: "🌆", gradient: "linear-gradient(135deg,#2d1b00,#c9a96e)" },
  { id: "37i9dQZF1DX4wta20PHzhA", name: "Jazz Piano",             description: "Piano-forward jazz",                   genre: "Jazz",        emoji: "🎵", gradient: "linear-gradient(135deg,#0d0221,#a8835e)" },
  // Chill
  { id: "37i9dQZF1DX8NTLI2TtZa6", name: "Lo-fi Beats",            description: "Chill beats to relax/study to",        genre: "Chill",       emoji: "☁️", gradient: "linear-gradient(135deg,#2d3561,#c05c7e)" },
  { id: "37i9dQZF1DX4WYpdgoIcn6", name: "Chill Hits",             description: "The best chill tracks",                genre: "Chill",       emoji: "😌", gradient: "linear-gradient(135deg,#0078ff,#00c9a7)" },
  { id: "37i9dQZF1DX889U0CL85jj", name: "Coffee Table Jazz",      description: "Perfect background music",             genre: "Chill",       emoji: "☕", gradient: "linear-gradient(135deg,#4b3832,#c9b29c)" },
  { id: "37i9dQZF1DX9itPmrBEMsN", name: "Peaceful Piano",         description: "Relax and indulge with piano",         genre: "Chill",       emoji: "🕊️", gradient: "linear-gradient(135deg,#1a1a2e,#9ba4b4)" },
  // Gaming
  { id: "37i9dQZF1DWTl4y3vgJOXW", name: "Gaming Music",           description: "The best video game soundtracks",      genre: "Gaming",      emoji: "🎮", gradient: "linear-gradient(135deg,#0f0c29,#302b63)" },
  { id: "37i9dQZF1DX7Ku6cgKRu4R", name: "Legendary Gaming",       description: "Epic gaming soundscapes",              genre: "Gaming",      emoji: "🏆", gradient: "linear-gradient(135deg,#141e30,#243b55)" },
  { id: "37i9dQZF1DX3USyB4y6jfz", name: "Lo-Fi Gaming",           description: "Chill beats for gaming",               genre: "Gaming",      emoji: "🕹️", gradient: "linear-gradient(135deg,#1a1a2e,#16213e)" },
  // Workout
  { id: "37i9dQZF1DX76Wlfdnj7AP", name: "Beast Mode",             description: "Maximum training intensity",           genre: "Workout",     emoji: "💪", gradient: "linear-gradient(135deg,#ff4e00,#ec9f05)" },
  { id: "37i9dQZF1DX7EKSfMivtSA", name: "Power Workout",          description: "Get your pump on",                     genre: "Workout",     emoji: "🏋️", gradient: "linear-gradient(135deg,#e52d27,#b31217)" },
  { id: "37i9dQZF1DX5uQYtP6lkwK", name: "Running",                description: "Keep your pace up",                   genre: "Workout",     emoji: "🏃", gradient: "linear-gradient(135deg,#f7971e,#ffd200)" },
];

function PlaylistCard({ pl, accent, onPlay }: { pl: Playlist; accent: string; onPlay: (pl: Playlist) => void }) {
  const [hov, setHov] = useState(false);
  return (
    <button
      onClick={() => onPlay(pl)}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        position: "relative", display: "flex", flexDirection: "column",
        borderRadius: "12px", overflow: "hidden", border: "none", padding: 0, cursor: "pointer",
        transform: hov ? "translateY(-3px) scale(1.02)" : "none",
        boxShadow: hov ? `0 16px 40px rgba(0,0,0,0.5), 0 0 0 1px ${accent}55` : "0 4px 16px rgba(0,0,0,0.3)",
        transition: "transform 0.18s, box-shadow 0.18s",
        background: "#111",
      }}>
      {/* Artwork */}
      <div style={{ width: "100%", aspectRatio: "1", background: pl.gradient, display: "flex", alignItems: "center", justifyContent: "center", position: "relative", fontSize: "44px" }}>
        {pl.emoji}
        {hov && (
          <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ width: "44px", height: "44px", borderRadius: "50%", background: accent, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 4px 20px ${accent}88` }}>
              <Play size={18} fill="#fff" color="#fff" style={{ marginLeft: "2px" }} />
            </div>
          </div>
        )}
      </div>
      {/* Info */}
      <div style={{ padding: "10px 12px 12px", background: "rgba(255,255,255,0.03)", textAlign: "left" }}>
        <div style={{ fontSize: "12px", fontWeight: 700, color: "#fff", marginBottom: "3px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{pl.name}</div>
        <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.5)", lineHeight: 1.4, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{pl.description}</div>
      </div>
    </button>
  );
}

function GenreShelf({ genre, playlists, accent, onPlay }: { genre: string; playlists: Playlist[]; accent: string; onPlay: (pl: Playlist) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => ref.current?.scrollBy({ left: dir * 700, behavior: "smooth" });
  if (!playlists.length) return null;
  return (
    <div style={{ marginBottom: "32px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}>
        <h3 style={{ fontSize: "15px", fontWeight: 700, color: "#fff", margin: 0, letterSpacing: "0.2px" }}>{genre}</h3>
        <div style={{ display: "flex", gap: "4px" }}>
          <button onClick={() => scroll(-1)} style={navBtn}><ChevronLeft size={14} /></button>
          <button onClick={() => scroll(1)} style={navBtn}><ChevronRight size={14} /></button>
        </div>
      </div>
      <div ref={ref} style={{ display: "flex", gap: "12px", overflowX: "auto", scrollbarWidth: "none", paddingBottom: "4px" }}>
        {playlists.map(pl => (
          <div key={pl.id + pl.name} style={{ flexShrink: 0, width: "160px" }}>
            <PlaylistCard pl={pl} accent={accent} onPlay={onPlay} />
          </div>
        ))}
      </div>
    </div>
  );
}

const navBtn: React.CSSProperties = {
  display: "flex", alignItems: "center", justifyContent: "center",
  width: "26px", height: "26px", borderRadius: "6px",
  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
  color: "rgba(255,255,255,0.7)", cursor: "pointer",
};

export default function MusicView({ accent, bg }: { accent: string; bg: string }) {
  const [activeGenre, setActiveGenre] = useState("Featured");
  const [searchQ, setSearchQ] = useState("");
  const [nowPlaying, setNowPlaying] = useState<Playlist | null>(null);

  const filtered = PLAYLISTS.filter(pl => {
    if (searchQ.trim()) {
      const q = searchQ.toLowerCase();
      return pl.name.toLowerCase().includes(q) || pl.description.toLowerCase().includes(q) || pl.genre.toLowerCase().includes(q);
    }
    return pl.genre === activeGenre;
  });

  const handlePlay = (pl: Playlist) => setNowPlaying(pl);

  return (
    <div style={{ flex: 1, position: "relative", display: "flex", flexDirection: "column", minWidth: 0, background: bg, height: "100%" }}>
      {/* Header */}
      <div style={{
        padding: "16px 22px", borderBottom: "1px solid rgba(255,255,255,0.06)",
        display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap",
        background: "rgba(0,0,0,0.4)", backdropFilter: "blur(10px)", zIndex: 5, flexShrink: 0,
      }}>
        <Music size={20} style={{ color: accent, filter: `drop-shadow(0 0 8px ${accent})` }} />
        <span style={{ fontSize: "16px", fontWeight: 600, letterSpacing: "0.3px", color: "#fff" }}>Music</span>
        <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.35)", marginLeft: "2px" }}>powered by Spotify</span>

        {/* Genre tabs */}
        <div style={{ display: "flex", gap: "4px", flexWrap: "wrap", marginLeft: "8px" }}>
          {GENRES.map(g => (
            <button key={g} onClick={() => { setActiveGenre(g); setSearchQ(""); }}
              style={{
                padding: "5px 11px", borderRadius: "16px", border: "1px solid rgba(255,255,255,0.1)",
                background: activeGenre === g && !searchQ ? accent : "rgba(255,255,255,0.04)",
                color: activeGenre === g && !searchQ ? "#fff" : "rgba(255,255,255,0.65)",
                fontSize: "11px", cursor: "pointer", fontWeight: 500, transition: "background 0.15s",
              }}>{g}</button>
          ))}
        </div>

        {/* Search */}
        <div style={{ position: "relative", maxWidth: "280px", marginLeft: "auto" }}>
          <Search style={{ position: "absolute", left: "10px", top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.3)", width: "13px", height: "13px", pointerEvents: "none" }} />
          <input value={searchQ} onChange={e => setSearchQ(e.target.value)} placeholder="Search playlists..."
            autoComplete="off" spellCheck={false}
            style={{ width: "100%", padding: "7px 30px 7px 30px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.04)", color: "#fff", outline: "none", fontSize: "12px" }}
            onFocus={e => (e.currentTarget.style.borderColor = `${accent}66`)}
            onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
          />
          {searchQ && (
            <button onClick={() => setSearchQ("")} style={{ position: "absolute", right: "8px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex" }}>
              <X size={12} />
            </button>
          )}
        </div>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
        {/* Playlist browser */}
        <div style={{ flex: 1, overflowY: "auto", padding: "22px 22px 22px", minWidth: 0 }}>
          {searchQ.trim() ? (
            <>
              <p style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)", marginBottom: "16px", marginTop: 0 }}>
                {filtered.length} result{filtered.length !== 1 ? "s" : ""} for "{searchQ}"
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "12px" }}>
                {filtered.map(pl => (
                  <PlaylistCard key={pl.id + pl.name} pl={pl} accent={accent} onPlay={handlePlay} />
                ))}
              </div>
              {filtered.length === 0 && (
                <div style={{ color: "rgba(255,255,255,0.4)", textAlign: "center", padding: "60px" }}>No playlists found for "{searchQ}".</div>
              )}
            </>
          ) : (
            <GenreShelf genre={activeGenre} playlists={filtered} accent={accent} onPlay={handlePlay} />
          )}

          {/* All genres overview when on Featured with no search */}
          {activeGenre === "Featured" && !searchQ && (
            <>
              {GENRES.filter(g => g !== "Featured").map(genre => {
                const items = PLAYLISTS.filter(p => p.genre === genre);
                return <GenreShelf key={genre} genre={genre} playlists={items} accent={accent} onPlay={handlePlay} />;
              })}
            </>
          )}
        </div>

        {/* Now playing - Spotify embed */}
        {nowPlaying && (
          <div style={{
            width: "340px", flexShrink: 0, borderLeft: "1px solid rgba(255,255,255,0.07)",
            display: "flex", flexDirection: "column", background: "rgba(0,0,0,0.4)", backdropFilter: "blur(12px)",
          }}>
            <div style={{ padding: "14px 16px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={{ fontSize: "20px" }}>{nowPlaying.emoji}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: "12px", fontWeight: 700, color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{nowPlaying.name}</div>
                <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", marginTop: "2px" }}>{nowPlaying.genre}</div>
              </div>
              <button
                onClick={() => window.open(`https://open.spotify.com/playlist/${nowPlaying.id}`, "_blank", "noopener,noreferrer")}
                title="Open in Spotify" style={{ padding: "5px", borderRadius: "6px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex" }}>
                <ExternalLink size={13} />
              </button>
              <button onClick={() => setNowPlaying(null)} title="Close"
                style={{ padding: "5px", borderRadius: "6px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex" }}>
                <X size={13} />
              </button>
            </div>
            <div style={{ flex: 1, position: "relative", minHeight: 0 }}>
              <iframe
                key={nowPlaying.id}
                src={`https://open.spotify.com/embed/playlist/${nowPlaying.id}?utm_source=generator&theme=0`}
                style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: "none" }}
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                loading="lazy"
                title={nowPlaying.name}
              />
            </div>
          </div>
        )}
      </div>

      {/* Hint when nothing playing */}
      {!nowPlaying && (
        <div style={{
          position: "absolute", bottom: "24px", left: "50%", transform: "translateX(-50%)",
          background: "rgba(0,0,0,0.75)", backdropFilter: "blur(10px)",
          border: "1px solid rgba(255,255,255,0.1)", borderRadius: "10px",
          padding: "10px 18px", display: "flex", alignItems: "center", gap: "8px",
          pointerEvents: "none",
        }}>
          <Music size={13} style={{ color: accent }} />
          <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.6)" }}>Click any playlist to start playing</span>
        </div>
      )}
    </div>
  );
}
