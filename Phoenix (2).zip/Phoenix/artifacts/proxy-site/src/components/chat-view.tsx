import { useState, useEffect, useRef, useCallback } from "react";
import { Send, X, Users, Smile, Search, Copy, Check, Image, Heart, ThumbsUp, Laugh, Flame, Star, Reply, Pin, Hash, Phone, Video, AtSign, Bell, Plus, Paperclip } from "lucide-react";

const EMOJIS = [
  "😀","😂","🥲","😍","🤔","😎","🥳","😴","😡","🥺",
  "👍","👎","❤️","🔥","✅","❌","⭐","🎉","👀","💯",
  "🙏","👏","🤝","💪","🫡","🤣","😭","😏","🤨","😒",
  "😊","😇","🤗","😌","😋","😛","😜","🤪","😝","🤑",
  "💀","👻","🎃","🤡","💩","👽","🤖","👾","🎮","🎯",
  "🌟","💫","✨","🌈","🌊","🔮","💎","🍕","🍔","🍦",
  "🐶","🐱","🦊","🐸","🦁","🐙","🦋","🌸","🌹","🍀",
  "🚀","💥","⚡","🌙","☀️","🏆","💡","🎵","🎨","🔑",
];

const REACTION_EMOJIS = ["❤️","😂","😮","😢","😡","👍","🔥","🎉","💯","👀"];

const GIF_COLLECTION = [
  { id: "1", url: "https://media.tenor.com/NjLsHAa1HOEAAAAC/hello-wave.gif", name: "Hello Wave" },
  { id: "2", url: "https://media.tenor.com/5Rc7BTXF8kIAAAAC/fire-flame.gif", name: "Fire" },
  { id: "3", url: "https://media.tenor.com/RlQCLg_Y0oMAAAAC/wow-amazing.gif", name: "Wow" },
  { id: "4", url: "https://media.tenor.com/kjfMCz3PBgMAAAAC/ok-okay.gif", name: "OK" },
  { id: "5", url: "https://media.tenor.com/GkAeGQEhbFsAAAAC/let-go-lets-go.gif", name: "Let's Go" },
  { id: "6", url: "https://media.tenor.com/Sq5fBa8O4tsAAAAC/panda-bear.gif", name: "Panda" },
  { id: "7", url: "https://media.tenor.com/Rv_JHlK_4egAAAAC/cat-cute.gif", name: "Cat" },
  { id: "8", url: "https://media.tenor.com/6jKK0T1L-DMAAAAC/thumbs-up.gif", name: "Thumbs Up" },
  { id: "9", url: "https://media.tenor.com/p1KiTiWWTR8AAAAC/clapping-clap.gif", name: "Clap" },
  { id: "10", url: "https://media.tenor.com/OIj-RKi4JlkAAAAC/facepalm.gif", name: "Facepalm" },
  { id: "11", url: "https://media.tenor.com/FUvxA0Y7WLIAAAAC/laugh.gif", name: "Laugh" },
  { id: "12", url: "https://media.tenor.com/I4VNjFKxGywAAAAC/mindblown.gif", name: "Mind Blown" },
  { id: "13", url: "https://media.tenor.com/t4sQ-RzjUFEAAAAC/party.gif", name: "Party" },
  { id: "14", url: "https://media.tenor.com/5yS-A1v4e_MAAAAC/dancing.gif", name: "Dance" },
  { id: "15", url: "https://media.tenor.com/7MhIKLRjf6IAAAAC/sunglasses.gif", name: "Cool" },
  { id: "16", url: "https://media.tenor.com/rYXdYFmjRdQAAAAC/keyboard.gif", name: "Typing" },
  { id: "17", url: "https://media.tenor.com/NjIc07gcRTMAAAAC/yes.gif", name: "Yes!" },
  { id: "18", url: "https://media.tenor.com/OqNNqT6-u1kAAAAC/no-no-way.gif", name: "No Way" },
  { id: "19", url: "https://media.tenor.com/p5KAXQ10wosAAAAC/love-heart.gif", name: "Love" },
  { id: "20", url: "https://media.tenor.com/qcNK6sTbhMQAAAAC/rocket-launch.gif", name: "Rocket" },
];

const API = `${import.meta.env.BASE_URL || "/"}api`.replace("//api", "/api");
function getToken() { return localStorage.getItem("phoenix.token") || ""; }
function getUsername() { return localStorage.getItem("phoenix.username") || ""; }

interface ChatMsg { id: number; username: string; displayName?: string | null; content: string; createdAt: string; avatarUrl?: string | null; avatarDecoration?: string | null; }
const MAX_FILE_BYTES = 6 * 1024 * 1024;
interface Reaction { emoji: string; count: number; users: string[] }
const CHAT_DECORATIONS: Record<string, { emoji: string; color: string }> = {
  sparkles: { emoji: "✦", color: "#f9a8d4" },
  crown: { emoji: "♛", color: "#facc15" },
  flame: { emoji: "🔥", color: "#fb923c" },
  hearts: { emoji: "♥", color: "#fb7185" },
  halo: { emoji: "◌", color: "#fde68a" },
  diamond: { emoji: "◆", color: "#67e8f9" },
};

function ChatAvatar({ msg, accent }: { msg: ChatMsg; accent: string }) {
  const decor = msg.avatarDecoration ? CHAT_DECORATIONS[msg.avatarDecoration] : undefined;
  return (
    <div style={{ position: "relative", width: "22px", height: "22px", flexShrink: 0 }}>
      <div style={{ width: "100%", height: "100%", borderRadius: "6px", background: `${accent}30`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "10px", fontWeight: 700, color: accent, overflow: "hidden" }}>
        {msg.avatarUrl ? <img src={msg.avatarUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : msg.username[0]?.toUpperCase()}
      </div>
      {decor && <><div style={{ position: "absolute", inset: -2, borderRadius: "8px", border: `1px solid ${decor.color}`, boxShadow: `0 0 6px ${decor.color}99`, pointerEvents: "none" }} /><span style={{ position: "absolute", top: -7, right: -5, color: decor.color, fontSize: "9px", lineHeight: 1, textShadow: `0 0 5px ${decor.color}` }}>{decor.emoji}</span></>}
    </div>
  );
}

function CopyBtn({ text, accent }: { text: string; accent: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
      title="Copy" style={{ background: "none", border: "none", color: copied ? accent : "rgba(255,255,255,0.2)", cursor: "pointer", padding: "2px 4px", display: "flex", alignItems: "center", transition: "color 0.15s", flexShrink: 0 }}
      onMouseEnter={e => { if (!copied) e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}
      onMouseLeave={e => { if (!copied) e.currentTarget.style.color = "rgba(255,255,255,0.2)"; }}>
      {copied ? <Check size={11} /> : <Copy size={11} />}
    </button>
  );
}

function ReactionPicker({ onReact, accent }: { onReact: (emoji: string) => void; accent: string }) {
  return (
    <div style={{ display: "flex", gap: "3px", padding: "6px 8px", borderRadius: "12px", background: "rgba(20,20,20,0.98)", border: "1px solid rgba(255,255,255,0.12)", boxShadow: "0 4px 24px rgba(0,0,0,0.8)", position: "absolute", zIndex: 50, bottom: "calc(100% + 8px)", left: "0", whiteSpace: "nowrap" }}>
      {REACTION_EMOJIS.map(em => (
        <button key={em} onClick={() => onReact(em)}
          style={{ fontSize: "18px", padding: "4px 5px", borderRadius: "6px", border: "none", background: "none", cursor: "pointer", transition: "transform 0.1s" }}
          onMouseEnter={e => { e.currentTarget.style.transform = "scale(1.25)"; e.currentTarget.style.background = `${accent}20`; }}
          onMouseLeave={e => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.background = "none"; }}>
          {em}
        </button>
      ))}
    </div>
  );
}

export default function ChatView({ accent, glow, onBack, onSignIn }: {
  accent: string; glow: string; onBack: () => void; onSignIn: () => void;
}) {
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [online, setOnline] = useState<number | null>(null);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [gifOpen, setGifOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [reactions, setReactions] = useState<Record<number, Reaction[]>>({});
  const [reactionPickerFor, setReactionPickerFor] = useState<number | null>(null);
  const [replyTo, setReplyTo] = useState<ChatMsg | null>(null);
  const [hoveredMsg, setHoveredMsg] = useState<number | null>(null);
  const [pinnedMsgId, setPinnedMsgId] = useState<number | null>(null);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<"global" | "mentions">("global");
  const [modGiveOpen, setModGiveOpen] = useState(false);
  const [modGiveUsers, setModGiveUsers] = useState<Array<{ id: number; accountId: string; username: string; displayName: string }>>([]);
  const [modGiveSelected, setModGiveSelected] = useState<number[]>([]);
  const [modGiveAmount, setModGiveAmount] = useState("100");
  const [modGiveLoading, setModGiveLoading] = useState(false);

  const bottomRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const emojiRef = useRef<HTMLDivElement>(null);
  const gifRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const me = getUsername();
  const isGuest = !getToken();

  const fetchMessages = useCallback(async () => {
    try {
      const res = await fetch(`${API}/chat/messages`, { headers: { Authorization: `Bearer ${getToken()}` } });
      if (res.ok) {
        const data = (await res.json()) as { messages: ChatMsg[] };
        setMessages(prev => JSON.stringify(prev) === JSON.stringify(data.messages) ? prev : data.messages);
        setOnline(Math.floor(Math.random() * 18) + 5);
      }
    } catch {}
  }, []);

  useEffect(() => { fetchMessages(); const id = setInterval(fetchMessages, 3000); return () => clearInterval(id); }, [fetchMessages]);

  useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    if (el.scrollHeight - el.scrollTop - el.clientHeight < 80) bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (emojiRef.current && !emojiRef.current.contains(e.target as Node)) setEmojiOpen(false);
      if (gifRef.current && !gifRef.current.contains(e.target as Node)) setGifOpen(false);
      if (reactionPickerFor !== null) setReactionPickerFor(null);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [reactionPickerFor]);

  const simulateTyping = () => {
    const names = ["Alex", "Sam", "Jordan", "Casey"];
    const rnd = names[Math.floor(Math.random() * names.length)];
    if (input.length > 0 && input.length % 3 === 0) {
      setTypingUsers([rnd]);
      setTimeout(() => setTypingUsers([]), 2000);
    }
  };

  const send = async (text?: string) => {
    const msg = (text ?? input).trim();
    if (!msg || sending) return;
    if (msg.toLowerCase() === "/modgive") {
      setError(null);
      setModGiveOpen(true);
      setModGiveSelected([]);
      setModGiveLoading(true);
      try {
        const res = await fetch(`${API}/currency/admin/users`, { headers: { Authorization: `Bearer ${getToken()}` } });
        const data = await res.json() as { users?: Array<{ id: number; accountId: string; username: string; displayName: string }>; error?: string };
        if (!res.ok) {
          setModGiveOpen(false);
          setError(data.error || "Owner tools are unavailable for this account.");
        } else {
          setModGiveUsers(data.users || []);
          setInput("");
        }
      } catch {
        setModGiveOpen(false);
        setError("Could not load users for /modgive.");
      } finally {
        setModGiveLoading(false);
      }
      return;
    }
    setSending(true); setError(null);
    const fullMsg = replyTo ? `> @${replyTo.username}: ${replyTo.content.slice(0, 60)}${replyTo.content.length > 60 ? "…" : ""}\n${msg}` : msg;
    setReplyTo(null);
    try {
      const res = await fetch(`${API}/chat/message`, {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ content: fullMsg }),
      });
      if (res.ok) { setInput(""); await fetchMessages(); setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 100); }
      else { const d = (await res.json()) as { error?: string }; setError(d.error || "Failed to send"); }
    } catch { setError("Network error — try again"); }
    setSending(false); inputRef.current?.focus();
  };

  const sendGif = async (gifUrl: string) => {
    setGifOpen(false);
    await send(`[GIF]${gifUrl}[/GIF]`);
  };

  const sendFile = (file: File) => {
    if (file.size > MAX_FILE_BYTES) {
      setError("Files must be 6 MB or smaller.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result ?? "");
      if (!dataUrl) { setError("That file could not be read."); return; }
      void send(`[FILE name="${file.name.replace(/["\\]/g, "")}" type="${file.type || "application/octet-stream"}"]${dataUrl}[/FILE]`);
    };
    reader.onerror = () => setError("That file could not be read.");
    reader.readAsDataURL(file);
  };

  const handleReaction = (msgId: number, emoji: string) => {
    setReactions(prev => {
      const msgReactions = [...(prev[msgId] ?? [])];
      const existing = msgReactions.find(r => r.emoji === emoji);
      if (existing) {
        if (existing.users.includes(me)) {
          existing.users = existing.users.filter(u => u !== me);
          existing.count--;
          if (existing.count === 0) return { ...prev, [msgId]: msgReactions.filter(r => r.emoji !== emoji) };
        } else {
          existing.users.push(me);
          existing.count++;
        }
        return { ...prev, [msgId]: msgReactions };
      } else {
        return { ...prev, [msgId]: [...msgReactions, { emoji, count: 1, users: [me] }] };
      }
    });
    setReactionPickerFor(null);
  };

  const fmt = (iso: string) => {
    const d = new Date(iso), now = new Date(), diff = now.getTime() - d.getTime();
    if (diff < 60000) return "just now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    return d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const filtered = search.trim()
    ? messages.filter(m => m.content.toLowerCase().includes(search.toLowerCase()) || m.username.toLowerCase().includes(search.toLowerCase()) || (m.displayName || "").toLowerCase().includes(search.toLowerCase()))
    : messages;

  const grouped = filtered.reduce<Array<{ username: string; displayName: string; msgs: ChatMsg[]; isMe: boolean }>>((acc, msg) => {
    const last = acc[acc.length - 1];
    if (last && last.username === msg.username && !search.trim()) { last.msgs.push(msg); }
    else { acc.push({ username: msg.username, displayName: msg.displayName || msg.username, msgs: [msg], isMe: msg.username === me }); }
    return acc;
  }, []);

  const pinnedMsg = pinnedMsgId !== null ? messages.find(m => m.id === pinnedMsgId) : null;

  const renderContent = (content: string) => {
    const fileMatch = content.match(/^\[FILE name="([^"]*)" type="([^"]*)"\](data:[\s\S]+)\[\/FILE\]$/);
    if (fileMatch) {
      const [, name, type, dataUrl] = fileMatch;
      if (type.startsWith("image/")) {
        return <div><img src={dataUrl} alt={name} style={{ maxWidth: "260px", maxHeight: "220px", borderRadius: "8px", objectFit: "contain", display: "block" }} /><span style={{ display: "block", marginTop: "5px", fontSize: "11px", color: "rgba(255,255,255,0.45)" }}>{name}</span></div>;
      }
      return <a href={dataUrl} download={name} style={{ display: "inline-flex", alignItems: "center", gap: "7px", color: accent, textDecoration: "none", fontSize: "12px", padding: "8px 10px", borderRadius: "8px", background: `${accent}14`, border: `1px solid ${accent}33` }}><Paperclip size={13} /> {name}</a>;
    }
    const gifMatch = content.match(/\[GIF\](.*?)\[\/GIF\]/);
    if (gifMatch) {
      return <img src={gifMatch[1]} alt="GIF" style={{ maxWidth: "200px", maxHeight: "160px", borderRadius: "8px", objectFit: "cover", display: "block" }} onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />;
    }
    const lines = content.split("\n");
    return lines.map((line, i) => {
      if (line.startsWith("> ")) {
        return <div key={i} style={{ borderLeft: `3px solid ${accent}88`, paddingLeft: "8px", color: "rgba(255,255,255,0.4)", fontSize: "11px", marginBottom: "4px", borderRadius: "2px", fontStyle: "italic" }}>{line.slice(2)}</div>;
      }
      return <span key={i}>{line}{i < lines.length - 1 ? <br /> : null}</span>;
    });
  };

  const submitModGive = async () => {
    const amount = Number(modGiveAmount);
    if (!modGiveSelected.length || !Number.isInteger(amount) || amount < 1) {
      setError("Pick one or more users and enter a whole AtBucks amount.");
      return;
    }
    setModGiveLoading(true);
    setError(null);
    try {
      const res = await fetch(`${API}/currency/admin/modgive`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ userIds: modGiveSelected, amount }),
      });
      const data = await res.json() as { users?: Array<{ username: string }>; error?: string };
      if (!res.ok) {
        setError(data.error || "The AtBucks grant failed.");
        return;
      }
      setModGiveOpen(false);
      setModGiveSelected([]);
      setError(`Granted ${amount.toLocaleString()} AtBucks to ${(data.users || []).length} user${(data.users || []).length === 1 ? "" : "s"}.`);
    } catch {
      setError("Network error while granting AtBucks.");
    } finally {
      setModGiveLoading(false);
    }
  };

  if (isGuest) return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "16px", padding: "40px" }}>
      <div style={{ width: "56px", height: "56px", borderRadius: "16px", background: `${accent}20`, border: `1px solid ${accent}33`, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Users size={26} color={accent} />
      </div>
      <div style={{ textAlign: "center" }}>
        <h3 style={{ margin: "0 0 8px", fontSize: "18px", fontWeight: 700, color: "#fff" }}>Global Chat</h3>
        <p style={{ margin: 0, fontSize: "13px", color: "rgba(255,255,255,0.4)", lineHeight: 1.6, maxWidth: "280px" }}>
          Create a free account to join the 24/7 global chat and talk with other users.
        </p>
      </div>
      <button onClick={onSignIn} style={{ marginTop: "4px", padding: "10px 28px", borderRadius: "10px", border: "none", background: accent, color: "#fff", fontSize: "14px", fontWeight: 600, cursor: "pointer", boxShadow: `0 0 20px ${glow}` }}>
        Sign In / Create Account
      </button>
      <button onClick={onBack} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", fontSize: "12px", cursor: "pointer" }}>Back to Home</button>
    </div>
  );

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", position: "relative" }}>
      {modGiveOpen && (
        <div onClick={() => !modGiveLoading && setModGiveOpen(false)} style={{ position: "fixed", inset: 0, zIndex: 1200, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px", background: "rgba(0,0,0,0.76)", backdropFilter: "blur(6px)" }}>
          <div onClick={e => e.stopPropagation()} style={{ width: "min(520px, 100%)", maxHeight: "min(680px, 90vh)", overflow: "auto", padding: "22px", borderRadius: "16px", border: `1px solid ${accent}44`, background: "rgba(18,18,18,0.98)", boxShadow: `0 20px 80px ${glow}` }}>
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "16px", marginBottom: "18px" }}>
              <div>
                <div style={{ color: accent, fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase" }}>Owner command</div>
                <h2 style={{ margin: "5px 0 4px", color: "#fff", fontSize: "20px" }}>Modgive</h2>
                <p style={{ margin: 0, color: "rgba(255,255,255,0.42)", fontSize: "12px" }}>Choose multiple accounts to receive AtBucks.</p>
              </div>
              <button onClick={() => setModGiveOpen(false)} disabled={modGiveLoading} style={{ border: "none", background: "none", color: "rgba(255,255,255,0.45)", cursor: "pointer", display: "flex" }}><X size={18} /></button>
            </div>
            <label style={{ display: "block", marginBottom: "7px", color: "rgba(255,255,255,0.45)", fontSize: "10px", textTransform: "uppercase", letterSpacing: "0.1em" }}>Amount per user</label>
            <input value={modGiveAmount} onChange={e => setModGiveAmount(e.target.value.replace(/\D/g, "").slice(0, 6))} inputMode="numeric" style={{ width: "100%", boxSizing: "border-box", padding: "10px 11px", marginBottom: "16px", borderRadius: "9px", border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.05)", color: "#fff", outline: "none", fontSize: "13px" }} />
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
              <span style={{ color: "rgba(255,255,255,0.45)", fontSize: "10px", textTransform: "uppercase", letterSpacing: "0.1em" }}>Recipients</span>
              <span style={{ color: accent, fontSize: "11px", fontWeight: 650 }}>{modGiveSelected.length} selected</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "6px", marginBottom: "18px" }}>
              {modGiveUsers.map(user => {
                const selected = modGiveSelected.includes(user.id);
                return <button key={user.id} onClick={() => setModGiveSelected(current => selected ? current.filter(id => id !== user.id) : [...current, user.id])} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px 11px", textAlign: "left", borderRadius: "9px", border: `1px solid ${selected ? `${accent}66` : "rgba(255,255,255,0.08)"}`, background: selected ? `${accent}16` : "rgba(255,255,255,0.035)", color: "#fff", cursor: "pointer" }}>
                  <span style={{ width: "18px", height: "18px", borderRadius: "5px", display: "inline-flex", alignItems: "center", justifyContent: "center", border: `1px solid ${selected ? accent : "rgba(255,255,255,0.25)"}`, background: selected ? accent : "transparent", color: "#111", fontSize: "12px", fontWeight: 800 }}>{selected ? "✓" : ""}</span>
                  <span style={{ minWidth: 0, flex: 1 }}><strong style={{ display: "block", fontSize: "12px", fontWeight: 650 }}>{user.displayName || user.username}</strong><span style={{ display: "block", marginTop: "2px", color: "rgba(255,255,255,0.36)", fontSize: "10px" }}>@{user.username} · {user.accountId}</span></span>
                </button>;
              })}
              {!modGiveLoading && modGiveUsers.length === 0 && <div style={{ padding: "20px", textAlign: "center", color: "rgba(255,255,255,0.4)", fontSize: "12px" }}>No users available.</div>}
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: "8px" }}>
              <button onClick={() => setModGiveOpen(false)} disabled={modGiveLoading} style={{ padding: "9px 13px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.62)", cursor: "pointer", fontSize: "11px" }}>Cancel</button>
              <button onClick={() => void submitModGive()} disabled={modGiveLoading || !modGiveSelected.length} style={{ padding: "9px 14px", borderRadius: "8px", border: "none", background: modGiveSelected.length ? accent : "rgba(255,255,255,0.1)", color: modGiveSelected.length ? "#fff" : "rgba(255,255,255,0.35)", cursor: modGiveSelected.length ? "pointer" : "default", fontSize: "11px", fontWeight: 700 }}>{modGiveLoading ? "Working…" : "Grant AtBucks"}</button>
            </div>
          </div>
        </div>
      )}
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", borderBottom: "1px solid rgba(255,255,255,0.07)", flexShrink: 0, background: "rgba(12,12,12,0.6)", backdropFilter: "blur(12px)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <div style={{ width: "34px", height: "34px", borderRadius: "10px", background: `${accent}22`, border: `1px solid ${accent}44`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Hash size={16} color={accent} />
          </div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <h2 style={{ margin: 0, fontSize: "14px", fontWeight: 700, color: "#fff" }}>global</h2>
              {pinnedMsg && <span style={{ fontSize: "10px", padding: "1px 6px", borderRadius: "10px", background: `${accent}20`, color: accent, border: `1px solid ${accent}30` }}>📌 pinned</span>}
            </div>
            <p style={{ margin: "1px 0 0", fontSize: "11px", color: "rgba(255,255,255,0.3)" }}>
              {online !== null
                ? <><span style={{ display: "inline-block", width: "6px", height: "6px", borderRadius: "50%", background: "#22c55e", marginRight: "5px", verticalAlign: "middle" }} />{online} online · {messages.length} messages</>
                : "connecting..."}
            </p>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
          <span style={{ fontSize: "11px", color: accent, fontWeight: 600, padding: "3px 8px", borderRadius: "8px", background: `${accent}10`, border: `1px solid ${accent}25` }}>@{me}</span>
          <button title="Voice call (coming soon)"
            style={{ padding: "6px 7px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.35)", cursor: "pointer", display: "flex" }}>
            <Phone size={13} />
          </button>
          <button title="Video call (coming soon)"
            style={{ padding: "6px 7px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.35)", cursor: "pointer", display: "flex" }}>
            <Video size={13} />
          </button>
          <button onClick={() => { setSearchOpen(o => !o); if (searchOpen) setSearch(""); }} title="Search messages"
            style={{ padding: "6px 7px", borderRadius: "8px", border: searchOpen ? `1px solid ${accent}44` : "1px solid rgba(255,255,255,0.08)", background: searchOpen ? `${accent}20` : "rgba(255,255,255,0.04)", color: searchOpen ? accent : "rgba(255,255,255,0.4)", cursor: "pointer", display: "flex" }}>
            <Search size={13} />
          </button>
          <button onClick={() => { setSearchOpen(o => !o); if (searchOpen) setSearch(""); }} title="Mentions"
            style={{ padding: "6px 7px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.35)", cursor: "pointer", display: "flex" }}>
            <AtSign size={13} />
          </button>
          <button onClick={onBack} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex", padding: "4px" }}
            onMouseEnter={e => (e.currentTarget.style.color = "rgba(255,255,255,0.8)")}
            onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.3)")}
          ><X size={16} /></button>
        </div>
      </div>

      {/* Pinned message banner */}
      {pinnedMsg && (
        <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "7px 16px", background: `${accent}10`, borderBottom: `1px solid ${accent}25`, flexShrink: 0 }}>
          <Pin size={12} color={accent} />
          <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.5)" }}>Pinned: </span>
          <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.7)", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {pinnedMsg.content.slice(0, 80)}
          </span>
          <button onClick={() => setPinnedMsgId(null)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex" }}><X size={11} /></button>
        </div>
      )}

      {/* Tab bar */}
      <div style={{ display: "flex", gap: "0", borderBottom: "1px solid rgba(255,255,255,0.06)", flexShrink: 0 }}>
        {(["global", "mentions"] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            style={{ padding: "8px 16px", border: "none", background: "none", fontSize: "12px", fontWeight: 500, cursor: "pointer", borderBottom: activeTab === tab ? `2px solid ${accent}` : "2px solid transparent", color: activeTab === tab ? accent : "rgba(255,255,255,0.35)", transition: "all 0.15s" }}>
            {tab === "global" ? "💬 Global" : "🔔 Mentions"}
          </button>
        ))}
      </div>

      {/* Search bar */}
      {searchOpen && (
        <div style={{ padding: "8px 16px 6px", borderBottom: "1px solid rgba(255,255,255,0.06)", background: "rgba(0,0,0,0.25)", flexShrink: 0 }}>
          <input autoFocus value={search} onChange={e => setSearch(e.target.value)} placeholder="Search messages or usernames..."
            style={{ width: "100%", padding: "8px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", fontSize: "12.5px", outline: "none", fontFamily: "inherit", boxSizing: "border-box" }}
            onFocus={e => (e.currentTarget.style.borderColor = `${accent}66`)}
            onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
          />
          {search && <p style={{ margin: "4px 2px 0", fontSize: "10.5px", color: "rgba(255,255,255,0.3)" }}>{filtered.length} result{filtered.length !== 1 ? "s" : ""}</p>}
        </div>
      )}

      {/* Messages */}
      <div ref={listRef} style={{ flex: 1, overflowY: "auto", padding: "16px 16px 8px", display: "flex", flexDirection: "column", gap: "12px" }}>
        {messages.length === 0 && (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "10px", opacity: 0.4, paddingTop: "40px" }}>
            <Users size={32} color={accent} />
            <p style={{ margin: 0, fontSize: "13px", color: "#fff" }}>No messages yet</p>
            <p style={{ margin: 0, fontSize: "11px", color: "rgba(255,255,255,0.5)" }}>Be the first to say something!</p>
          </div>
        )}
        {activeTab === "mentions" && (
          <div style={{ textAlign: "center", padding: "40px 20px" }}>
            <AtSign size={32} color={accent} style={{ margin: "0 auto", display: "block" }} />
            <p style={{ marginTop: "12px", fontSize: "13px", color: "rgba(255,255,255,0.4)" }}>Mentions will appear here</p>
          </div>
        )}
        {activeTab === "global" && grouped.map((group, gi) => (
          <div key={gi} style={{ display: "flex", flexDirection: "column", alignItems: group.isMe ? "flex-end" : "flex-start", gap: "3px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "2px" }}>
              {!group.isMe && (
                <ChatAvatar msg={group.msgs[group.msgs.length - 1]} accent={accent} />
              )}
              <span style={{ fontSize: "11px", fontWeight: 600, color: group.isMe ? accent : "rgba(255,255,255,0.55)" }}>
                 {group.isMe ? "You" : group.displayName}
              </span>
               {!group.isMe && <span style={{ fontSize: "10px", color: "rgba(255,255,255,0.2)" }}>@{group.username}</span>}
              <span style={{ fontSize: "10px", color: "rgba(255,255,255,0.2)" }}>
                {fmt(group.msgs[group.msgs.length - 1].createdAt)}
              </span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "3px", alignItems: group.isMe ? "flex-end" : "flex-start", maxWidth: "75%" }}>
              {group.msgs.map(msg => (
                <div key={msg.id}
                  onMouseEnter={() => setHoveredMsg(msg.id)}
                  onMouseLeave={() => setHoveredMsg(null)}
                  style={{ position: "relative" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px", flexDirection: group.isMe ? "row-reverse" : "row" }}>
                    <div style={{
                      padding: "8px 12px", borderRadius: "12px",
                      borderBottomRightRadius: group.isMe ? "3px" : "12px",
                      borderBottomLeftRadius: group.isMe ? "12px" : "3px",
                      background: group.isMe ? accent : "rgba(255,255,255,0.08)",
                      color: group.isMe ? "#fff" : "rgba(255,255,255,0.88)",
                      fontSize: "13px", lineHeight: 1.5, wordBreak: "break-word",
                      boxShadow: group.isMe ? `0 2px 12px ${glow}` : "none",
                      maxWidth: "100%",
                    }}>
                      {renderContent(msg.content)}
                    </div>
                    {/* Hover action bar */}
                    <div style={{ display: "flex", gap: "2px", opacity: hoveredMsg === msg.id ? 1 : 0, transition: "opacity 0.15s", flexShrink: 0, flexDirection: group.isMe ? "row-reverse" : "row" }}>
                      <div style={{ position: "relative" }}>
                        <button onClick={() => setReactionPickerFor(reactionPickerFor === msg.id ? null : msg.id)}
                          title="React"
                          style={{ padding: "3px 5px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(20,20,20,0.9)", color: "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex", fontSize: "12px" }}>
                          <Smile size={12} />
                        </button>
                        {reactionPickerFor === msg.id && <ReactionPicker onReact={em => handleReaction(msg.id, em)} accent={accent} />}
                      </div>
                      <button onClick={() => setReplyTo(msg)} title="Reply"
                        style={{ padding: "3px 5px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(20,20,20,0.9)", color: "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex" }}>
                        <Reply size={12} />
                      </button>
                      <button onClick={() => setPinnedMsgId(pinnedMsgId === msg.id ? null : msg.id)} title="Pin"
                        style={{ padding: "3px 5px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(20,20,20,0.9)", color: pinnedMsgId === msg.id ? accent : "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex" }}>
                        <Pin size={12} />
                      </button>
                      <CopyBtn text={msg.content} accent={accent} />
                    </div>
                  </div>
                  {/* Reactions display */}
                  {reactions[msg.id]?.length > 0 && (
                    <div style={{ display: "flex", gap: "4px", marginTop: "3px", flexWrap: "wrap", justifyContent: group.isMe ? "flex-end" : "flex-start" }}>
                      {reactions[msg.id].map(r => (
                        <button key={r.emoji} onClick={() => handleReaction(msg.id, r.emoji)}
                          title={r.users.join(", ")}
                          style={{ display: "flex", alignItems: "center", gap: "3px", padding: "2px 7px", borderRadius: "20px", border: `1px solid ${r.users.includes(me) ? accent + "60" : "rgba(255,255,255,0.12)"}`, background: r.users.includes(me) ? `${accent}15` : "rgba(255,255,255,0.05)", cursor: "pointer", fontSize: "12px" }}>
                          <span>{r.emoji}</span>
                          <span style={{ fontSize: "10px", color: "rgba(255,255,255,0.5)" }}>{r.count}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
        {/* Typing indicator */}
        {typingUsers.length > 0 && (
          <div style={{ display: "flex", alignItems: "center", gap: "8px", padding: "4px 0", opacity: 0.6 }}>
            <div style={{ display: "flex", gap: "3px" }}>
              {[0,1,2].map(i => <div key={i} style={{ width: "6px", height: "6px", borderRadius: "50%", background: "rgba(255,255,255,0.5)", animation: `chatBounce 1s ${i * 0.15}s infinite` }} />)}
            </div>
            <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)" }}>{typingUsers[0]} is typing…</span>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {error && <div style={{ padding: "0 16px 6px", fontSize: "11px", color: "#ef4444", flexShrink: 0 }}>{error}</div>}

      {/* Reply preview */}
      {replyTo && (
        <div style={{ display: "flex", alignItems: "center", gap: "8px", padding: "8px 16px", borderTop: "1px solid rgba(255,255,255,0.06)", background: "rgba(0,0,0,0.3)", flexShrink: 0 }}>
          <Reply size={12} color={accent} />
          <div style={{ flex: 1, borderLeft: `3px solid ${accent}80`, paddingLeft: "8px" }}>
            <span style={{ fontSize: "10px", color: accent, fontWeight: 600 }}>@{replyTo.username}</span>
            <p style={{ margin: 0, fontSize: "11px", color: "rgba(255,255,255,0.4)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{replyTo.content.slice(0, 80)}</p>
          </div>
          <button onClick={() => setReplyTo(null)} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", display: "flex" }}><X size={13} /></button>
        </div>
      )}

      {/* GIF picker */}
      {gifOpen && (
        <div ref={gifRef} style={{ position: "absolute", bottom: "80px", left: "16px", zIndex: 60, background: "rgba(16,16,16,0.98)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "14px", padding: "12px", width: "300px", maxHeight: "280px", overflowY: "auto", boxShadow: "0 8px 40px rgba(0,0,0,0.9)" }}>
          <p style={{ margin: "0 0 8px", fontSize: "11px", fontWeight: 600, color: "rgba(255,255,255,0.4)" }}>GIFs</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px" }}>
            {GIF_COLLECTION.map(g => (
              <button key={g.id} onClick={() => void sendGif(g.url)}
                style={{ padding: 0, border: "1px solid rgba(255,255,255,0.08)", borderRadius: "8px", overflow: "hidden", cursor: "pointer", background: "#111", aspectRatio: "16/9" }}>
                <img src={g.url} alt={g.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} loading="lazy"
                  onError={e => { (e.currentTarget as HTMLImageElement).src = ""; (e.currentTarget.parentElement as HTMLElement).textContent = g.name; }} />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input area */}
      <div style={{ display: "flex", gap: "6px", padding: "10px 12px 12px", borderTop: "1px solid rgba(255,255,255,0.07)", flexShrink: 0, background: "rgba(12,12,12,0.6)", backdropFilter: "blur(12px)", alignItems: "center", position: "relative" }}>
        <input ref={fileInputRef} type="file" accept="*/*" style={{ display: "none" }}
          onChange={e => { const file = e.target.files?.[0]; if (file) sendFile(file); e.currentTarget.value = ""; }} />

        <div style={{ position: "relative", flexShrink: 0 }} ref={emojiRef}>
          <button onClick={() => { setEmojiOpen(o => !o); setGifOpen(false); }} title="Emoji"
            style={{ padding: "8px", borderRadius: "10px", border: "none", background: emojiOpen ? `${accent}20` : "rgba(255,255,255,0.07)", color: emojiOpen ? accent : "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex", transition: "all 0.15s" }}>
            <Smile size={16} />
          </button>
          {emojiOpen && (
            <div style={{ position: "absolute", bottom: "50px", left: 0, zIndex: 50, background: "rgba(18,18,18,0.98)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "12px", padding: "10px", display: "grid", gridTemplateColumns: "repeat(10, 1fr)", gap: "2px", width: "280px", boxShadow: "0 8px 40px rgba(0,0,0,0.8)", maxHeight: "200px", overflowY: "auto" }}>
              {EMOJIS.map(em => (
                <button key={em} onClick={() => { setInput(p => p + em); setEmojiOpen(false); inputRef.current?.focus(); }}
                  style={{ fontSize: "18px", padding: "4px 2px", borderRadius: "6px", border: "none", background: "none", cursor: "pointer", lineHeight: 1 }}
                  onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.1)")}
                  onMouseLeave={e => (e.currentTarget.style.background = "none")}
                >{em}</button>
              ))}
            </div>
          )}
        </div>

        <button onClick={() => { setGifOpen(o => !o); setEmojiOpen(false); }} title="Send GIF"
          style={{ padding: "7px 9px", borderRadius: "10px", border: gifOpen ? `1px solid ${accent}44` : "1px solid rgba(255,255,255,0.1)", background: gifOpen ? `${accent}20` : "rgba(255,255,255,0.07)", color: gifOpen ? accent : "rgba(255,255,255,0.5)", cursor: "pointer", fontSize: "10px", fontWeight: 700, flexShrink: 0, letterSpacing: "0.5px" }}>
          GIF
        </button>

        <button onClick={() => fileInputRef.current?.click()} title="Send file"
          style={{ padding: "8px", borderRadius: "10px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.07)", color: "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex", flexShrink: 0 }}>
          <Paperclip size={14} />
        </button>

        <div style={{ flex: 1, position: "relative" }}>
          <input ref={inputRef} value={input} onChange={e => { setInput(e.target.value); simulateTyping(); }}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send(); } }}
            placeholder={replyTo ? `Replying to @${replyTo.username}…` : "Message #global…"} maxLength={500}
            style={{ width: "100%", padding: "10px 14px", borderRadius: "10px", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", fontSize: "13px", outline: "none", fontFamily: "inherit", boxSizing: "border-box" }}
            onFocus={e => (e.currentTarget.style.borderColor = `${accent}66`)}
            onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
          />
          {input.length > 400 && (
            <span style={{ position: "absolute", right: "10px", bottom: "-17px", fontSize: "10px", color: input.length >= 490 ? "#ef4444" : "rgba(255,255,255,0.3)" }}>
              {500 - input.length} left
            </span>
          )}
        </div>

        <button onClick={() => void send()} disabled={!input.trim() || sending}
          style={{ padding: "10px 14px", borderRadius: "10px", border: "none", background: input.trim() && !sending ? accent : "rgba(255,255,255,0.07)", color: "#fff", cursor: input.trim() && !sending ? "pointer" : "default", display: "flex", alignItems: "center", fontSize: "13px", transition: "background 0.15s", flexShrink: 0, boxShadow: input.trim() ? `0 0 12px ${glow}` : "none" }}>
          <Send size={14} />
        </button>
      </div>

      <style>{`
        @keyframes chatBounce { 0%, 60%, 100% { transform: translateY(0); } 30% { transform: translateY(-4px); } }
      `}</style>
    </div>
  );
}
