import { useEffect, useState } from "react";
import { ArrowLeft, Check, Coins, Crown, Gift, Heart, LockKeyhole, MessageCircle, Palette, Plus, Sparkles, UserRound, WandSparkles } from "lucide-react";

const API = `${import.meta.env.BASE_URL || "/"}api`.replace("//api", "/api");

interface ShopItem {
  id: string;
  type: string;
  value: string;
  name: string;
  description: string;
  price: number;
  emoji: string;
  color: string;
}
interface Quest {
  id: string;
  title: string;
  description: string;
  reward: number;
  target: number;
  progress: number;
  completed: boolean;
}
interface CurrencyState {
  accountId: string;
  username: string;
  displayName: string;
  balance: number;
  equippedDecoration: string;
  daily: { reward: number; claimed: boolean };
  inventory: string[];
  shop: ShopItem[];
  quests: Quest[];
  isAdmin: boolean;
}

function formatAtBucks(value: number) {
  return new Intl.NumberFormat("en-US").format(value);
}

function DecorationPreview({ item, size = 48, equipped = false }: { item: Pick<ShopItem, "emoji" | "color">; size?: number; equipped?: boolean }) {
  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <div style={{ width: "100%", height: "100%", borderRadius: "50%", background: `${item.color}1f`, border: `2px solid ${item.color}`, display: "flex", alignItems: "center", justifyContent: "center", color: item.color, fontSize: Math.max(16, size * 0.42), boxShadow: `0 0 18px ${item.color}55` }}>✦</div>
      <span style={{ position: "absolute", top: -Math.max(8, size * 0.16), right: -Math.max(5, size * 0.1), color: item.color, fontSize: Math.max(12, size * 0.3), lineHeight: 1, textShadow: `0 0 8px ${item.color}` }}>{item.emoji}</span>
      {equipped && <span style={{ position: "absolute", right: -4, bottom: -4, width: 16, height: 16, borderRadius: "50%", background: "#22c55e", color: "#041108", display: "flex", alignItems: "center", justifyContent: "center", border: "2px solid #121212" }}><Check size={10} strokeWidth={3} /></span>}
    </div>
  );
}

export default function CurrencyView({ accent, glow, onBack, onSignIn, onOpenChat, onOpenProfile }: { accent: string; glow: string; onBack: () => void; onSignIn: () => void; onOpenChat: () => void; onOpenProfile: () => void }) {
  const [state, setState] = useState<CurrencyState | null>(null);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState<string | null>(null);
  const [message, setMessage] = useState<{ text: string; ok: boolean } | null>(null);
  const [grantAmount, setGrantAmount] = useState("1000");
  const token = localStorage.getItem("phoenix.token");

  const refresh = async () => {
    if (!token) { setLoading(false); return; }
    try {
      const res = await fetch(`${API}/currency`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json() as CurrencyState & { error?: string };
      if (!res.ok) { setMessage({ text: data.error || "Could not load AtBucks.", ok: false }); return; }
      setState(data);
    } catch { setMessage({ text: "Network error while loading AtBucks.", ok: false }); }
    finally { setLoading(false); }
  };

  useEffect(() => { void refresh(); }, []);

  const request = async (key: string, path: string, body?: Record<string, unknown>) => {
    if (!token) { onSignIn(); return; }
    setWorking(key);
    setMessage(null);
    try {
      const res = await fetch(`${API}${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        ...(body ? { body: JSON.stringify(body) } : {}),
      });
      const data = await res.json() as { balance?: number; reward?: number; error?: string; equippedDecoration?: string };
      if (!res.ok) { setMessage({ text: data.error || "That action could not be completed.", ok: false }); return; }
      if (data.equippedDecoration) {
        localStorage.setItem("phoenix.avatarDecoration", data.equippedDecoration);
        window.dispatchEvent(new Event("phoenix-profile-changed"));
      }
      setMessage({ text: data.reward ? `+${formatAtBucks(data.reward)} AtBucks added.` : "Done.", ok: true });
      await refresh();
    } catch { setMessage({ text: "Network error. Try again.", ok: false }); }
    finally { setWorking(null); }
  };

  const questIcon = (id: string) => id === "say-hello" ? <MessageCircle size={16} /> : <Palette size={16} />;

  return (
    <main style={{ position: "relative", zIndex: 1, flex: 1, minWidth: 0, overflowY: "auto", padding: "clamp(24px, 5vw, 64px) clamp(18px, 5vw, 72px)" }}>
      <div style={{ maxWidth: "980px", margin: "0 auto" }}>
        <button onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: "7px", marginBottom: "22px", padding: "8px 12px", borderRadius: "9px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.58)", cursor: "pointer", fontSize: "12px" }}>
          <ArrowLeft size={14} /> Back to Phoenix
        </button>

        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "flex-end", justifyContent: "space-between", gap: "18px", marginBottom: "26px" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "9px", color: accent, fontSize: "11px", fontWeight: 700, letterSpacing: "0.16em", textTransform: "uppercase" }}><Coins size={15} /> Phoenix economy</div>
            <h1 style={{ margin: "9px 0 7px", fontSize: "clamp(30px, 5vw, 46px)", lineHeight: 1, letterSpacing: "-0.04em" }}>AtBucks</h1>
            <p style={{ margin: 0, color: "rgba(255,255,255,0.4)", fontSize: "13px" }}>Earn your way to profile upgrades.</p>
          </div>
          <div style={{ minWidth: "170px", padding: "14px 17px", borderRadius: "15px", background: `linear-gradient(135deg, ${accent}24, rgba(255,255,255,0.05))`, border: `1px solid ${accent}42`, boxShadow: `0 10px 36px ${glow}` }}>
            <div style={{ color: "rgba(255,255,255,0.42)", fontSize: "10px", textTransform: "uppercase", letterSpacing: "0.12em" }}>Your balance</div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "3px", color: "#fff", fontSize: "27px", fontWeight: 750 }}><Coins size={22} color={accent} />{loading ? "…" : formatAtBucks(state?.balance ?? 0)}</div>
          </div>
        </div>

        {!token ? (
          <section style={{ padding: "28px", borderRadius: "16px", border: "1px solid rgba(255,255,255,0.09)", background: "rgba(20,20,20,0.8)", textAlign: "center" }}>
            <LockKeyhole size={28} color={accent} style={{ marginBottom: "10px" }} />
            <h2 style={{ margin: "0 0 7px", fontSize: "18px" }}>Sign in to use AtBucks</h2>
            <p style={{ margin: "0 auto 18px", maxWidth: "380px", color: "rgba(255,255,255,0.4)", fontSize: "12px", lineHeight: 1.6 }}>Your balance and purchases are tied to your Phoenix account.</p>
            <button onClick={onSignIn} style={{ padding: "10px 16px", border: "none", borderRadius: "9px", background: accent, color: "#fff", cursor: "pointer", fontWeight: 650 }}>Sign in</button>
          </section>
        ) : (
          <>
            {message && <div style={{ marginBottom: "15px", padding: "10px 13px", borderRadius: "10px", color: message.ok ? "#86efac" : "#fca5a5", background: message.ok ? "rgba(34,197,94,0.1)" : "rgba(239,68,68,0.1)", border: `1px solid ${message.ok ? "rgba(34,197,94,0.25)" : "rgba(239,68,68,0.25)"}`, fontSize: "12px" }}>{message.text}</div>}

            <section style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.3fr) minmax(260px, 0.7fr)", gap: "14px", marginBottom: "28px" }}>
              <div style={{ padding: "20px", borderRadius: "16px", border: `1px solid ${state?.daily.claimed ? "rgba(255,255,255,0.08)" : `${accent}42`}`, background: state?.daily.claimed ? "rgba(255,255,255,0.035)" : `linear-gradient(135deg, ${accent}15, rgba(255,255,255,0.035))` }}>
                <div style={{ display: "flex", alignItems: "center", gap: "11px" }}>
                  <div style={{ width: "42px", height: "42px", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "center", background: state?.daily.claimed ? "rgba(255,255,255,0.07)" : `${accent}24`, color: state?.daily.claimed ? "rgba(255,255,255,0.4)" : accent }}><Gift size={20} /></div>
                  <div style={{ flex: 1 }}><h2 style={{ margin: 0, fontSize: "15px" }}>Daily drop</h2><p style={{ margin: "4px 0 0", color: "rgba(255,255,255,0.4)", fontSize: "11px" }}>{state?.daily.claimed ? "You have collected today’s reward." : `Collect ${state?.daily.reward ?? 100} AtBucks today.`}</p></div>
                  <button disabled={state?.daily.claimed || working === "daily"} onClick={() => void request("daily", "/currency/daily")} style={{ padding: "9px 12px", borderRadius: "9px", border: "none", background: state?.daily.claimed ? "rgba(255,255,255,0.08)" : accent, color: state?.daily.claimed ? "rgba(255,255,255,0.35)" : "#fff", cursor: state?.daily.claimed ? "default" : "pointer", fontSize: "11px", fontWeight: 650 }}>{working === "daily" ? "Claiming…" : state?.daily.claimed ? "Claimed" : "Claim 100"}</button>
                </div>
              </div>
              {state?.isAdmin && (
                <div style={{ padding: "20px", borderRadius: "16px", border: "1px solid rgba(250,204,21,0.25)", background: "rgba(250,204,21,0.06)" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", color: "#facc15", fontSize: "11px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em" }}><Crown size={14} /> Creator tools</div>
                   <p style={{ margin: "8px 0 12px", color: "rgba(255,255,255,0.48)", fontSize: "11px" }}>Owner tools for Phoenix and PhoenixDrizz. Use <strong style={{ color: "#facc15" }}>/modgive</strong> in Global Chat to pick multiple recipients.</p>
                  <div style={{ display: "flex", gap: "7px" }}><input value={grantAmount} onChange={e => setGrantAmount(e.target.value.replace(/\D/g, "").slice(0, 6))} inputMode="numeric" style={{ minWidth: 0, flex: 1, padding: "8px 9px", borderRadius: "8px", border: "1px solid rgba(250,204,21,0.25)", background: "rgba(0,0,0,0.2)", color: "#fff", outline: "none", fontSize: "12px" }} /><button disabled={working === "grant"} onClick={() => void request("grant", "/currency/admin/grant", { amount: Number(grantAmount) })} style={{ padding: "8px 10px", borderRadius: "8px", border: "none", background: "#facc15", color: "#211a00", cursor: "pointer", fontSize: "11px", fontWeight: 700 }}>{working === "grant" ? "…" : "Grant"}</button></div>
                </div>
              )}
            </section>

            <section style={{ marginBottom: "30px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}><div><h2 style={{ margin: 0, fontSize: "18px" }}>Daily quests</h2><p style={{ margin: "4px 0 0", color: "rgba(255,255,255,0.32)", fontSize: "11px" }}>Complete real actions in Phoenix to earn more.</p></div><WandSparkles size={20} color={accent} /></div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "10px" }}>
                {(state?.quests ?? []).map(quest => {
                  const ready = quest.progress >= quest.target && !quest.completed;
                  return <div key={quest.id} style={{ padding: "15px", borderRadius: "13px", border: ready ? `1px solid ${accent}55` : "1px solid rgba(255,255,255,0.08)", background: ready ? `${accent}0d` : "rgba(255,255,255,0.035)" }}>
                    <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}><div style={{ width: "30px", height: "30px", borderRadius: "9px", display: "flex", alignItems: "center", justifyContent: "center", background: `${accent}18`, color: accent }}>{questIcon(quest.id)}</div><div style={{ minWidth: 0, flex: 1 }}><div style={{ display: "flex", justifyContent: "space-between", gap: "8px" }}><h3 style={{ margin: 0, fontSize: "13px" }}>{quest.title}</h3><span style={{ color: "#facc15", fontSize: "10px", fontWeight: 700, whiteSpace: "nowrap" }}>+{quest.reward} <Coins size={10} style={{ verticalAlign: "-1px" }} /></span></div><p style={{ margin: "5px 0 0", color: "rgba(255,255,255,0.38)", fontSize: "11px", lineHeight: 1.45 }}>{quest.description}</p></div></div>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "14px" }}><div style={{ flex: 1, height: "5px", borderRadius: "999px", background: "rgba(255,255,255,0.08)", overflow: "hidden" }}><div style={{ width: `${Math.min(100, quest.progress / quest.target * 100)}%`, height: "100%", borderRadius: "inherit", background: quest.completed ? "#4ade80" : accent }} /></div><span style={{ color: "rgba(255,255,255,0.35)", fontSize: "10px" }}>{quest.completed ? "Done" : `${quest.progress}/${quest.target}`}</span></div>
                    <div style={{ display: "flex", justifyContent: "flex-end", marginTop: "12px" }}>{quest.id === "say-hello" && !quest.completed && !ready ? <button onClick={onOpenChat} style={{ display: "inline-flex", alignItems: "center", gap: "5px", padding: "7px 9px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.62)", cursor: "pointer", fontSize: "10px" }}><MessageCircle size={12} /> Open chat</button> : quest.id === "make-it-yours" && !quest.completed && !ready ? <button onClick={onOpenProfile} style={{ display: "inline-flex", alignItems: "center", gap: "5px", padding: "7px 9px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.62)", cursor: "pointer", fontSize: "10px" }}><UserRound size={12} /> Open profile</button> : <button disabled={quest.completed || working === quest.id} onClick={() => void request(quest.id, "/currency/quests/claim", { questId: quest.id })} style={{ display: "inline-flex", alignItems: "center", gap: "5px", padding: "7px 10px", borderRadius: "8px", border: "none", background: quest.completed ? "rgba(255,255,255,0.08)" : accent, color: quest.completed ? "rgba(255,255,255,0.35)" : "#fff", cursor: quest.completed ? "default" : "pointer", fontSize: "10px", fontWeight: 650 }}>{quest.completed ? <Check size={12} /> : <Plus size={12} />}{quest.completed ? "Claimed" : working === quest.id ? "Claiming…" : "Claim reward"}</button>}</div>
                  </div>;
                })}
              </div>
            </section>

            <section>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}><div><h2 style={{ margin: 0, fontSize: "18px" }}>Decoration shop</h2><p style={{ margin: "4px 0 0", color: "rgba(255,255,255,0.32)", fontSize: "11px" }}>Buy cosmetics, then equip them on your avatar.</p></div><Sparkles size={20} color={accent} /></div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: "10px" }}>
                {(state?.shop ?? []).map(item => {
                  const owned = state?.inventory.includes(item.id) ?? false;
                  const equipped = state?.equippedDecoration === item.value;
                  return <div key={item.id} style={{ padding: "15px", borderRadius: "13px", border: equipped ? `1px solid ${item.color}88` : "1px solid rgba(255,255,255,0.08)", background: equipped ? `${item.color}0d` : "rgba(255,255,255,0.035)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "11px" }}><DecorationPreview item={item} equipped={equipped} /><div style={{ minWidth: 0 }}><h3 style={{ margin: 0, fontSize: "13px" }}>{item.name}</h3><p style={{ margin: "4px 0 0", color: "rgba(255,255,255,0.38)", fontSize: "10px" }}>{item.description}</p></div></div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px", marginTop: "15px" }}>{owned ? <span style={{ color: "#86efac", fontSize: "10px", fontWeight: 650 }}>Owned</span> : <span style={{ display: "inline-flex", alignItems: "center", gap: "4px", color: "#facc15", fontSize: "11px", fontWeight: 700 }}><Coins size={12} />{formatAtBucks(item.price)}</span>}{owned ? <button disabled={equipped || working === `equip:${item.id}`} onClick={() => void request(`equip:${item.id}`, "/currency/shop/equip", { itemId: item.id })} style={{ padding: "7px 10px", borderRadius: "8px", border: equipped ? "1px solid rgba(74,222,128,0.25)" : `1px solid ${item.color}55`, background: equipped ? "rgba(74,222,128,0.1)" : `${item.color}18`, color: equipped ? "#86efac" : item.color, cursor: equipped ? "default" : "pointer", fontSize: "10px", fontWeight: 650 }}>{equipped ? "Equipped" : "Equip"}</button> : <button disabled={working === `buy:${item.id}`} onClick={() => void request(`buy:${item.id}`, "/currency/shop/purchase", { itemId: item.id })} style={{ padding: "7px 10px", borderRadius: "8px", border: "none", background: accent, color: "#fff", cursor: "pointer", fontSize: "10px", fontWeight: 650 }}>{working === `buy:${item.id}` ? "Buying…" : "Buy"}</button>}</div>
                  </div>;
                })}
              </div>
            </section>
          </>
        )}
      </div>
    </main>
  );
}