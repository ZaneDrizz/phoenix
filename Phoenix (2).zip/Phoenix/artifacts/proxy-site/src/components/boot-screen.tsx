import { useEffect, useRef, useState, useMemo } from "react";

const MESSAGES = [
  "Initializing Phoenix OS...",
  "Loading secure modules...",
  "Connecting proxy layer...",
  "Starting media services...",
  "Mounting game library...",
  "Loading AI assistant...",
  "Configuring user environment...",
  "Starting chat services...",
  "System ready.",
];

function PhoenixBootIcon() {
  return (
    <svg width="64" height="64" viewBox="0 0 16 16" style={{ imageRendering: "pixelated" }} xmlns="http://www.w3.org/2000/svg">
      <rect x="7" y="14" width="2" height="1" fill="#f97316" />
      <rect x="6" y="13" width="4" height="1" fill="#fb923c" />
      <rect x="5" y="13" width="1" height="2" fill="#f97316" />
      <rect x="10" y="13" width="1" height="2" fill="#f97316" />
      <rect x="4" y="14" width="1" height="1" fill="#ea580c" />
      <rect x="11" y="14" width="1" height="1" fill="#ea580c" />
      <rect x="5" y="8" width="6" height="5" fill="#fb923c" />
      <rect x="4" y="9" width="1" height="3" fill="#fb923c" />
      <rect x="11" y="9" width="1" height="3" fill="#fb923c" />
      <rect x="6" y="8" width="4" height="1" fill="#fed7aa" />
      <rect x="1" y="7" width="4" height="3" fill="#f97316" />
      <rect x="11" y="7" width="4" height="3" fill="#f97316" />
      <rect x="1" y="10" width="3" height="1" fill="#ea580c" />
      <rect x="12" y="10" width="3" height="1" fill="#ea580c" />
      <rect x="2" y="6" width="3" height="1" fill="#fb923c" />
      <rect x="11" y="6" width="3" height="1" fill="#fb923c" />
      <rect x="6" y="9" width="4" height="2" fill="#fed7aa" />
      <rect x="7" y="11" width="2" height="1" fill="#fed7aa" />
      <rect x="6" y="4" width="4" height="4" fill="#fb923c" />
      <rect x="5" y="5" width="1" height="2" fill="#fb923c" />
      <rect x="10" y="5" width="1" height="2" fill="#fb923c" />
      <rect x="8" y="7" width="2" height="1" fill="#fde68a" />
      <rect x="6" y="3" width="1" height="2" fill="#fbbf24" />
      <rect x="8" y="1" width="1" height="3" fill="#f59e0b" />
      <rect x="10" y="2" width="1" height="2" fill="#fbbf24" />
      <rect x="7" y="2" width="2" height="1" fill="#fde68a" />
      <rect x="6" y="5" width="1" height="1" fill="#1c1c1c" />
      <rect x="9" y="5" width="1" height="1" fill="#1c1c1c" />
    </svg>
  );
}

export default function BootScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [msgIdx, setMsgIdx] = useState(0);
  const [fading, setFading] = useState(false);
  const doneRef = useRef(false);

  const stars = useMemo(() =>
    Array.from({ length: 100 }, (_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      size: Math.random() < 0.7 ? 1 : 2,
      opacity: +(Math.random() * 0.4 + 0.1).toFixed(2),
    })),
  []);

  useEffect(() => {
    let prog = 0;
    const tick = () => {
      prog += Math.random() * 10 + 5;
      if (prog >= 100) {
        prog = 100;
        setProgress(100);
        setMsgIdx(MESSAGES.length - 1);
        if (!doneRef.current) {
          doneRef.current = true;
          setTimeout(() => {
            setFading(true);
            setTimeout(onDone, 500);
          }, 350);
        }
        return;
      }
      setProgress(prog);
      setMsgIdx(Math.min(Math.floor((prog / 100) * (MESSAGES.length - 1)), MESSAGES.length - 2));
      setTimeout(tick, 110 + Math.random() * 80);
    };
    const t = setTimeout(tick, 200);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9999,
      background: "#05050f",
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      opacity: fading ? 0 : 1, transition: "opacity 0.5s ease",
    }}>
      {/* Stars */}
      <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }}>
        {stars.map(s => (
          <div key={s.id} style={{
            position: "absolute", left: s.left, top: s.top,
            width: s.size, height: s.size,
            borderRadius: "50%", background: `rgba(255,255,255,${s.opacity})`,
          }} />
        ))}
      </div>

      {/* Scanlines overlay */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.06) 2px, rgba(0,0,0,0.06) 4px)",
        zIndex: 1,
      }} />

      <div style={{ position: "relative", zIndex: 2, display: "flex", flexDirection: "column", alignItems: "center", gap: "28px" }}>
        {/* Logo */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "14px" }}>
          <div style={{ filter: "drop-shadow(0 0 18px rgba(249,115,22,0.7))" }}>
            <PhoenixBootIcon />
          </div>
          <div style={{
            color: "#fff", fontSize: "20px", fontWeight: 700,
            letterSpacing: "0.25em", textTransform: "uppercase",
            textShadow: "0 0 20px rgba(249,115,22,0.5)",
          }}>
            PHOENIX OS
          </div>
          <div style={{ color: "rgba(255,255,255,0.25)", fontSize: "10px", letterSpacing: "0.15em" }}>
            YOUR PORTAL TO THE OPEN WEB
          </div>
        </div>

        {/* Progress */}
        <div style={{ width: "260px", display: "flex", flexDirection: "column", gap: "10px" }}>
          <div style={{ width: "100%", height: "3px", background: "rgba(255,255,255,0.08)", borderRadius: "2px", overflow: "hidden" }}>
            <div style={{
              height: "100%", width: `${progress}%`,
              background: "linear-gradient(90deg, #ea580c, #f97316, #fb923c)",
              borderRadius: "2px",
              transition: "width 0.12s ease",
              boxShadow: "0 0 10px rgba(249,115,22,0.8)",
            }} />
          </div>
          <div style={{
            fontSize: "10.5px", color: "rgba(255,255,255,0.35)",
            letterSpacing: "0.04em", minHeight: "14px",
            fontFamily: "'Courier New', monospace",
          }}>
            {MESSAGES[msgIdx]}
          </div>
        </div>
      </div>

      {/* Version */}
      <div style={{
        position: "absolute", bottom: "20px",
        fontSize: "9px", color: "rgba(255,255,255,0.12)",
        letterSpacing: "0.12em", fontFamily: "'Courier New', monospace",
      }}>
        PHOENIX v2.0 • {new Date().getFullYear()}
      </div>
    </div>
  );
}
