import { useState, useEffect, useRef } from "react";

/* ── Typewriter hook ─────────────────────────────────────── */
function useTypewriter(text: string, speed = 38, startDelay = 0) {
  const [displayed, setDisplayed] = useState("");
  const [done, setDone] = useState(false);
  useEffect(() => {
    setDisplayed("");
    setDone(false);
    let i = 0;
    const delay = setTimeout(() => {
      const id = setInterval(() => {
        i++;
        setDisplayed(text.slice(0, i));
        if (i >= text.length) { clearInterval(id); setDone(true); }
      }, speed);
      return () => clearInterval(id);
    }, startDelay);
    return () => clearTimeout(delay);
  }, [text, speed, startDelay]);
  return { displayed, done };
}

/* ── Props ───────────────────────────────────────────────── */
export interface WizardTheme {
  key: string;
  name: string;
  accent: string;
  bg: string;
  particle: string;
}
export interface WizardCloak {
  id: string;
  name: string;
  favicon: string | null;
}
interface Props {
  themes: WizardTheme[];
  cloaks: WizardCloak[];
  username: string;
  initialTheme: string;
  initialCloak: string;
  onComplete: (s: { theme: string; cloak: string; autoCloak: boolean; panicKey: string }) => void;
  onSkip: () => void;
}

const TOTAL = 8;

/* ── Starfield (same as boot) ────────────────────────────── */
function Stars() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    let w = cv.width = window.innerWidth;
    let h = cv.height = window.innerHeight;
    const stars = Array.from({ length: 140 }, () => ({
      x: Math.random() * w, y: Math.random() * h,
      r: Math.random() * 1.2 + 0.2,
      o: Math.random() * 0.6 + 0.2,
      s: Math.random() * 0.3 + 0.05,
    }));
    let frame = 0;
    let raf: number;
    function draw() {
      ctx.clearRect(0, 0, w, h);
      stars.forEach(s => {
        const pulse = s.o + Math.sin(frame * s.s) * 0.15;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,255,255,${Math.max(0, Math.min(1, pulse))})`;
        ctx.fill();
      });
      frame++;
      raf = requestAnimationFrame(draw);
    }
    draw();
    const resize = () => {
      w = cv.width = window.innerWidth;
      h = cv.height = window.innerHeight;
    };
    window.addEventListener("resize", resize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);
  return <canvas ref={ref} style={{ position: "absolute", inset: 0, pointerEvents: "none" }} />;
}

/* ── Dot step indicator ──────────────────────────────────── */
function StepDots({ current, total, accent }: { current: number; total: number; accent: string }) {
  return (
    <div style={{ display: "flex", gap: "8px", alignItems: "center", justifyContent: "center" }}>
      {Array.from({ length: total }, (_, i) => (
        <div key={i} style={{
          width: i === current ? "22px" : "7px",
          height: "7px",
          borderRadius: "4px",
          background: i === current ? accent : i < current ? `${accent}66` : "rgba(255,255,255,0.15)",
          transition: "all 0.3s cubic-bezier(.4,0,.2,1)",
        }} />
      ))}
    </div>
  );
}

/* ── Feature card ────────────────────────────────────────── */
function FeatureCard({ icon, title, desc, accent }: { icon: string; title: string; desc: string; accent: string }) {
  return (
    <div style={{
      background: "rgba(255,255,255,0.04)",
      border: "1px solid rgba(255,255,255,0.08)",
      borderRadius: "14px",
      padding: "16px 14px",
      display: "flex", flexDirection: "column", gap: "6px",
      transition: "border-color 0.2s",
    }}
      onMouseEnter={e => (e.currentTarget.style.borderColor = `${accent}44`)}
      onMouseLeave={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)")}
    >
      <div style={{ fontSize: "22px" }}>{icon}</div>
      <div style={{ fontSize: "13px", fontWeight: 600, color: "#fff" }}>{title}</div>
      <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)", lineHeight: 1.5 }}>{desc}</div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   MAIN WIZARD COMPONENT
═══════════════════════════════════════════════════════════ */
export default function WelcomeWizard({ themes, cloaks, username, initialTheme, initialCloak, onComplete, onSkip }: Props) {
  const [page, setPage] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const [entering, setEntering] = useState(false);
  const [dir, setDir] = useState<1 | -1>(1);

  /* wizard state */
  const [selTheme, setSelTheme] = useState(initialTheme);
  const [selCloak, setSelCloak] = useState(initialCloak);
  const [autoCloak, setAutoCloak] = useState(false);
  const [panicKey, setPanicKey] = useState("Escape");
  const [panicKeyInput, setPanicKeyInput] = useState(false);

  const curTheme = themes.find(t => t.key === selTheme) ?? themes[0];
  const accent = curTheme.accent;

  /* ── navigation ── */
  function goTo(next: number, direction: 1 | -1 = 1) {
    if (leaving) return;
    setDir(direction);
    setLeaving(true);
    setTimeout(() => {
      setPage(next);
      setLeaving(false);
      setEntering(true);
      setTimeout(() => setEntering(false), 280);
    }, 220);
  }
  const next = () => page < TOTAL - 1 ? goTo(page + 1, 1) : finish();
  const prev = () => page > 0 && goTo(page - 1, -1);
  const finish = () => onComplete({ theme: selTheme, cloak: selCloak, autoCloak, panicKey });

  /* ── shared panel style ── */
  const panel: React.CSSProperties = {
    position: "relative", zIndex: 2,
    width: "min(640px, 94vw)",
    background: "rgba(14,14,18,0.88)",
    backdropFilter: "blur(24px)",
    WebkitBackdropFilter: "blur(24px)",
    border: "1px solid rgba(255,255,255,0.09)",
    borderRadius: "20px",
    padding: "40px 44px 32px",
    boxShadow: `0 0 80px ${accent}18, 0 24px 80px rgba(0,0,0,0.8)`,
    transition: "box-shadow 0.4s",
    transform: leaving
      ? `translateX(${dir * -60}px)`
      : entering
        ? `translateX(${dir * 60}px)`
        : "translateX(0)",
    opacity: leaving || entering ? 0 : 1,
    transition2: "transform 0.22s cubic-bezier(.4,0,.2,1), opacity 0.22s",
  } as React.CSSProperties;
  (panel as Record<string, string>).transition = "transform 0.22s cubic-bezier(.4,0,.2,1), opacity 0.22s";

  /* ── scan line overlay ── */
  const scanlines: React.CSSProperties = {
    position: "absolute", inset: 0, pointerEvents: "none",
    background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.04) 2px, rgba(0,0,0,0.04) 4px)",
    zIndex: 1,
  };

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9000,
      background: "radial-gradient(ellipse 90% 70% at 50% 20%, #1a0a28 0%, #0e0810 35%, #06040c 65%, #020108 100%)",
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      fontFamily: "'Share Tech Mono', 'Courier New', monospace",
      overflow: "hidden",
    }}>
      <Stars />
      <div style={scanlines} />

      {/* Top-right skip */}
      <button onClick={onSkip} style={{
        position: "absolute", top: "20px", right: "24px", zIndex: 10,
        background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
        borderRadius: "8px", padding: "6px 14px", color: "rgba(255,255,255,0.4)",
        fontSize: "11px", cursor: "pointer", fontFamily: "inherit", letterSpacing: "0.06em",
        transition: "all 0.15s",
      }}
        onMouseEnter={e => { e.currentTarget.style.color = "rgba(255,255,255,0.75)"; e.currentTarget.style.background = "rgba(255,255,255,0.1)"; }}
        onMouseLeave={e => { e.currentTarget.style.color = "rgba(255,255,255,0.4)"; e.currentTarget.style.background = "rgba(255,255,255,0.06)"; }}
      >
        SKIP SETUP
      </button>

      {/* Main panel */}
      <div style={panel}>
        {/* Top accent bar */}
        <div style={{
          position: "absolute", top: 0, left: "10%", right: "10%", height: "1px",
          background: `linear-gradient(90deg, transparent, ${accent}88, transparent)`,
          boxShadow: `0 0 12px ${accent}55`,
        }} />

        {/* Page content */}
        <PageContent
          page={page}
          accent={accent}
          themes={themes}
          cloaks={cloaks}
          username={username}
          selTheme={selTheme}
          setSelTheme={setSelTheme}
          selCloak={selCloak}
          setSelCloak={setSelCloak}
          autoCloak={autoCloak}
          setAutoCloak={setAutoCloak}
          panicKey={panicKey}
          setPanicKey={setPanicKey}
          panicKeyInput={panicKeyInput}
          setPanicKeyInput={setPanicKeyInput}
          onFinish={finish}
        />

        {/* Bottom nav */}
        <div style={{ marginTop: "28px", display: "flex", flexDirection: "column", gap: "16px", alignItems: "center" }}>
          <StepDots current={page} total={TOTAL} accent={accent} />
          <div style={{ display: "flex", gap: "10px", width: "100%", justifyContent: "space-between" }}>
            <button onClick={prev} disabled={page === 0}
              style={{
                padding: "10px 20px", borderRadius: "10px", border: "1px solid rgba(255,255,255,0.1)",
                background: "rgba(255,255,255,0.04)", color: page === 0 ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.55)",
                fontSize: "12px", cursor: page === 0 ? "default" : "pointer", fontFamily: "inherit",
                letterSpacing: "0.06em", transition: "all 0.15s",
              }}
              onMouseEnter={e => { if (page > 0) e.currentTarget.style.background = "rgba(255,255,255,0.08)"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
            >
              ← BACK
            </button>
            <button onClick={next}
              style={{
                padding: "10px 28px", borderRadius: "10px", border: "none",
                background: page === TOTAL - 1
                  ? `linear-gradient(135deg, ${accent}, ${accent}bb)`
                  : `linear-gradient(135deg, ${accent}cc, ${accent}88)`,
                color: "#fff", fontSize: "12px", cursor: "pointer", fontFamily: "inherit",
                fontWeight: 700, letterSpacing: "0.08em",
                boxShadow: `0 0 20px ${accent}44`,
                transition: "all 0.15s",
              }}
              onMouseEnter={e => { e.currentTarget.style.boxShadow = `0 0 28px ${accent}66`; e.currentTarget.style.transform = "scale(1.02)"; }}
              onMouseLeave={e => { e.currentTarget.style.boxShadow = `0 0 20px ${accent}44`; e.currentTarget.style.transform = "scale(1)"; }}
            >
              {page === TOTAL - 1 ? "LAUNCH PHOENIX →" : "CONTINUE →"}
            </button>
          </div>
        </div>
      </div>

      {/* Page counter */}
      <div style={{ position: "relative", zIndex: 2, marginTop: "16px", fontSize: "10px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.1em" }}>
        {String(page + 1).padStart(2, "0")} / {String(TOTAL).padStart(2, "0")}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Barlow:wght@300;400;500;600&display=swap');
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 4px; }
      `}</style>
    </div>
  );
}

/* ─── Individual pages ────────────────────────────────────── */
interface PageProps {
  page: number;
  accent: string;
  themes: WizardTheme[];
  cloaks: WizardCloak[];
  username: string;
  selTheme: string;
  setSelTheme: (v: string) => void;
  selCloak: string;
  setSelCloak: (v: string) => void;
  autoCloak: boolean;
  setAutoCloak: (v: boolean) => void;
  panicKey: string;
  setPanicKey: (v: string) => void;
  panicKeyInput: boolean;
  setPanicKeyInput: (v: boolean) => void;
  onFinish: () => void;
}

function PageContent(props: PageProps) {
  switch (props.page) {
    case 0: return <PageWelcome {...props} />;
    case 1: return <PageAccount {...props} />;
    case 2: return <PageTheme {...props} />;
    case 3: return <PageCloak {...props} />;
    case 4: return <PageAutoCloak {...props} />;
    case 5: return <PageFeatures {...props} />;
    case 6: return <PageTools {...props} />;
    case 7: return <PageReady {...props} />;
    default: return null;
  }
}

/* ── PAGE 1: Welcome ─────────────────────────────────────── */
function PageWelcome({ accent }: PageProps) {
  const { displayed } = useTypewriter("Welcome to Phoenix.", 45, 200);
  const { displayed: sub } = useTypewriter("Your portal to the open web.", 32, 1400);

  return (
    <div style={{ textAlign: "center" }}>
      {/* Phoenix pixel logo */}
      <div style={{ display: "flex", justifyContent: "center", marginBottom: "24px" }}>
        <svg width="72" height="72" viewBox="0 0 16 16" style={{ imageRendering: "pixelated", filter: `drop-shadow(0 0 16px ${accent}99)` }}>
          <rect x="7" y="14" width="2" height="1" fill="#f97316" />
          <rect x="6" y="13" width="4" height="1" fill="#fb923c" />
          <rect x="5" y="13" width="1" height="2" fill="#f97316" />
          <rect x="10" y="13" width="1" height="2" fill="#f97316" />
          <rect x="4" y="14" width="1" height="1" fill="#ea580c" />
          <rect x="11" y="14" width="1" height="1" fill="#ea580c" />
          <rect x="5" y="8" width="6" height="5" fill="#fb923c" />
          <rect x="4" y="9" width="1" height="3" fill="#fb923c" />
          <rect x="11" y="9" width="1" height="3" fill="#fb923c" />
          <rect x="6" y="8" width="4" height="1" fill="#fed7aa" />
          <rect x="1" y="7" width="4" height="3" fill="#f97316" />
          <rect x="11" y="7" width="4" height="3" fill="#f97316" />
          <rect x="1" y="10" width="3" height="1" fill="#ea580c" />
          <rect x="12" y="10" width="3" height="1" fill="#ea580c" />
          <rect x="3" y="6" width="2" height="1" fill="#f97316" />
          <rect x="11" y="6" width="2" height="1" fill="#f97316" />
          <rect x="4" y="5" width="8" height="3" fill="#fbbf24" />
          <rect x="5" y="4" width="6" height="1" fill="#fef3c7" />
          <rect x="6" y="3" width="4" height="1" fill="#fff" />
          <rect x="7" y="2" width="2" height="1" fill="#fff" />
          <rect x="6" y="7" width="1" height="2" fill="#fff" />
          <rect x="9" y="7" width="1" height="2" fill="#fff" />
          <rect x="7" y="9" width="2" height="1" fill="#fed7aa" />
        </svg>
      </div>

      <div style={{ marginBottom: "10px" }}>
        <span style={{ fontSize: "26px", fontWeight: 700, color: accent, fontFamily: "'Barlow', sans-serif", letterSpacing: "-0.02em" }}>
          PHOENIX
        </span>
      </div>

      <div style={{
        fontSize: "18px", color: "rgba(255,255,255,0.85)", fontFamily: "'Share Tech Mono', monospace",
        minHeight: "28px", marginBottom: "8px",
      }}>
        {displayed}<span style={{ opacity: 0.5 }}>_</span>
      </div>
      <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.35)", minHeight: "20px", fontFamily: "'Share Tech Mono', monospace" }}>
        {sub}
      </div>

      <div style={{ marginTop: "28px", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "10px" }}>
        {[
          { icon: "🌐", text: "Browse freely" },
          { icon: "🎮", text: "3,700+ games" },
          { icon: "🤖", text: "AI assistant" },
          { icon: "🎬", text: "Movies & TV" },
          { icon: "💬", text: "Global chat" },
          { icon: "🎵", text: "Music player" },
        ].map(({ icon, text }) => (
          <div key={text} style={{
            padding: "12px 8px", borderRadius: "10px",
            background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)",
            fontSize: "11px", color: "rgba(255,255,255,0.5)", textAlign: "center",
          }}>
            <div style={{ fontSize: "18px", marginBottom: "4px" }}>{icon}</div>
            {text}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── PAGE 2: Account ─────────────────────────────────────── */
function PageAccount({ username, accent }: PageProps) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const avatars = ["🦅", "🔥", "⚡", "🌙", "🎭", "🦊", "🐉", "🌌", "🦋", "🎯", "🚀", "💎"];
  const [av, setAv] = useState(() => {
    try { return localStorage.getItem("phoenix.avatar") || "🔥"; } catch { return "🔥"; }
  });

  const handleAv = (a: string) => {
    setAv(a);
    try { localStorage.setItem("phoenix.avatar", a); } catch { /* */ }
  };

  return (
    <div>
      <div style={{ marginBottom: "6px", fontSize: "10px", color: accent, letterSpacing: "0.12em" }}>PROFILE SETUP</div>
      <h2 style={{ margin: "0 0 6px", fontSize: "22px", fontWeight: 600, color: "#fff", fontFamily: "'Barlow', sans-serif" }}>
        {greeting}{username ? `, ${username}` : ""}.
      </h2>
      <p style={{ margin: "0 0 24px", fontSize: "12px", color: "rgba(255,255,255,0.35)", lineHeight: 1.6 }}>
        Your account is ready. Choose an avatar to represent you across Phoenix.
      </p>

      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "20px" }}>
        <div style={{
          width: "80px", height: "80px", borderRadius: "50%",
          border: `2px solid ${accent}66`,
          background: "rgba(255,255,255,0.06)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: "36px",
          boxShadow: `0 0 24px ${accent}33`,
          transition: "all 0.3s",
        }}>
          {av}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "8px", width: "100%" }}>
          {avatars.map(a => (
            <button key={a} onClick={() => handleAv(a)} style={{
              padding: "10px", borderRadius: "10px", border: `1px solid ${av === a ? accent : "rgba(255,255,255,0.08)"}`,
              background: av === a ? `${accent}22` : "rgba(255,255,255,0.04)",
              fontSize: "20px", cursor: "pointer",
              transition: "all 0.15s",
              boxShadow: av === a ? `0 0 12px ${accent}44` : "none",
            }}>
              {a}
            </button>
          ))}
        </div>

        <div style={{
          width: "100%", padding: "14px 16px", borderRadius: "12px",
          background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)",
          display: "flex", alignItems: "center", gap: "12px",
        }}>
          <div style={{ fontSize: "24px" }}>{av}</div>
          <div>
            <div style={{ fontSize: "13px", fontWeight: 600, color: "#fff" }}>{username || "Guest"}</div>
            <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.3)" }}>Phoenix Member</div>
          </div>
          <div style={{ marginLeft: "auto", padding: "4px 10px", borderRadius: "999px", background: `${accent}22`, border: `1px solid ${accent}44`, fontSize: "10px", color: accent }}>
            ACTIVE
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── PAGE 3: Theme ───────────────────────────────────────── */
function PageTheme({ accent, themes, selTheme, setSelTheme }: PageProps) {
  return (
    <div>
      <div style={{ marginBottom: "6px", fontSize: "10px", color: accent, letterSpacing: "0.12em" }}>VISUAL THEME</div>
      <h2 style={{ margin: "0 0 6px", fontSize: "22px", fontWeight: 600, color: "#fff", fontFamily: "'Barlow', sans-serif" }}>
        Choose your theme.
      </h2>
      <p style={{ margin: "0 0 18px", fontSize: "12px", color: "rgba(255,255,255,0.35)" }}>
        {themes.length} themes available — personalizes every surface.
      </p>

      <div style={{ maxHeight: "280px", overflowY: "auto", paddingRight: "4px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(86px, 1fr))", gap: "8px" }}>
          {themes.map(th => (
            <button key={th.key} onClick={() => setSelTheme(th.key)}
              title={th.name}
              style={{
                padding: "10px 6px 8px", borderRadius: "12px",
                border: selTheme === th.key ? `2px solid ${th.accent}` : "1px solid rgba(255,255,255,0.08)",
                background: selTheme === th.key ? `${th.accent}18` : "rgba(255,255,255,0.04)",
                cursor: "pointer", transition: "all 0.15s",
                display: "flex", flexDirection: "column", alignItems: "center", gap: "6px",
                boxShadow: selTheme === th.key ? `0 0 12px ${th.accent}44, inset 0 0 12px ${th.accent}12` : "none",
              }}
            >
              {/* Mini bg preview */}
              <div style={{
                width: "40px", height: "22px", borderRadius: "6px",
                background: th.bg, border: "1px solid rgba(255,255,255,0.1)",
                position: "relative", overflow: "hidden",
              }}>
                <div style={{
                  position: "absolute", bottom: "2px", right: "3px",
                  width: "8px", height: "8px", borderRadius: "50%",
                  background: th.accent, boxShadow: `0 0 6px ${th.accent}`,
                }} />
              </div>
              <div style={{
                fontSize: "9px", color: selTheme === th.key ? th.accent : "rgba(255,255,255,0.45)",
                fontWeight: selTheme === th.key ? 700 : 400,
                textAlign: "center", lineHeight: 1.2,
                overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: "78px",
              }}>
                {th.name}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── PAGE 4: Cloak ───────────────────────────────────────── */
function PageCloak({ accent, cloaks, selCloak, setSelCloak }: PageProps) {
  return (
    <div>
      <div style={{ marginBottom: "6px", fontSize: "10px", color: accent, letterSpacing: "0.12em" }}>TAB DISGUISE</div>
      <h2 style={{ margin: "0 0 6px", fontSize: "22px", fontWeight: 600, color: "#fff", fontFamily: "'Barlow', sans-serif" }}>
        Cloak your tab.
      </h2>
      <p style={{ margin: "0 0 18px", fontSize: "12px", color: "rgba(255,255,255,0.35)", lineHeight: 1.6 }}>
        Phoenix can disguise its browser tab title and favicon to blend in with other school apps.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "8px" }}>
        {cloaks.map(c => (
          <button key={c.id} onClick={() => setSelCloak(c.id)}
            style={{
              padding: "12px 14px", borderRadius: "12px",
              border: selCloak === c.id ? `1px solid ${accent}88` : "1px solid rgba(255,255,255,0.08)",
              background: selCloak === c.id ? `${accent}18` : "rgba(255,255,255,0.04)",
              display: "flex", alignItems: "center", gap: "10px",
              cursor: "pointer", transition: "all 0.15s", textAlign: "left",
              boxShadow: selCloak === c.id ? `0 0 10px ${accent}33` : "none",
            }}
          >
            <div style={{
              width: "28px", height: "28px", borderRadius: "8px",
              background: "rgba(255,255,255,0.08)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "14px", flexShrink: 0, overflow: "hidden",
            }}>
              {c.favicon
                ? <img src={c.favicon} alt="" style={{ width: "16px", height: "16px" }} onError={e => (e.currentTarget.style.display = "none")} />
                : c.id === "none" ? "🔥" : "🌐"}
            </div>
            <div>
              <div style={{ fontSize: "12px", fontWeight: 600, color: selCloak === c.id ? "#fff" : "rgba(255,255,255,0.7)" }}>{c.name}</div>
            </div>
            {selCloak === c.id && (
              <div style={{ marginLeft: "auto", width: "8px", height: "8px", borderRadius: "50%", background: accent, boxShadow: `0 0 6px ${accent}` }} />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── PAGE 5: Auto-Cloak + Panic ──────────────────────────── */
function PageAutoCloak({ accent, autoCloak, setAutoCloak, panicKey, setPanicKey, panicKeyInput, setPanicKeyInput }: PageProps) {
  const capRef = useRef<HTMLButtonElement>(null);

  const startCapture = () => {
    setPanicKeyInput(true);
    const handler = (e: KeyboardEvent) => {
      e.preventDefault();
      if (e.key && e.key.length > 0) {
        setPanicKey(e.key === " " ? "Space" : e.key);
        setPanicKeyInput(false);
        window.removeEventListener("keydown", handler);
      }
    };
    window.addEventListener("keydown", handler);
    setTimeout(() => {
      setPanicKeyInput(false);
      window.removeEventListener("keydown", handler);
    }, 8000);
  };

  return (
    <div>
      <div style={{ marginBottom: "6px", fontSize: "10px", color: accent, letterSpacing: "0.12em" }}>STEALTH SETTINGS</div>
      <h2 style={{ margin: "0 0 6px", fontSize: "22px", fontWeight: 600, color: "#fff", fontFamily: "'Barlow', sans-serif" }}>
        Stealth mode.
      </h2>
      <p style={{ margin: "0 0 24px", fontSize: "12px", color: "rgba(255,255,255,0.35)", lineHeight: 1.6 }}>
        Configure automatic disguise and emergency escape for maximum safety.
      </p>

      <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        {/* Auto-cloak toggle */}
        <div style={{
          padding: "18px 20px", borderRadius: "14px",
          background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
          display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>
          <div>
            <div style={{ fontSize: "14px", fontWeight: 600, color: "#fff", marginBottom: "4px" }}>Auto-Cloak</div>
            <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.35)", lineHeight: 1.5 }}>
              Automatically hide tab when you switch away — shows disguised title in the taskbar.
            </div>
          </div>
          <button onClick={() => setAutoCloak(!autoCloak)}
            style={{
              width: "48px", height: "26px", borderRadius: "13px", border: "none",
              background: autoCloak ? accent : "rgba(255,255,255,0.12)",
              cursor: "pointer", position: "relative", flexShrink: 0, marginLeft: "16px",
              transition: "background 0.2s",
            }}
          >
            <div style={{
              position: "absolute", top: "3px", left: autoCloak ? "25px" : "3px",
              width: "20px", height: "20px", borderRadius: "50%",
              background: "#fff", transition: "left 0.2s",
              boxShadow: "0 1px 4px rgba(0,0,0,0.4)",
            }} />
          </button>
        </div>

        {/* Panic key */}
        <div style={{
          padding: "18px 20px", borderRadius: "14px",
          background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
        }}>
          <div style={{ fontSize: "14px", fontWeight: 600, color: "#fff", marginBottom: "4px" }}>Panic Key</div>
          <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.35)", marginBottom: "14px", lineHeight: 1.5 }}>
            Press this key to instantly redirect the tab to your cloaked URL.
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{
              padding: "8px 16px", borderRadius: "8px",
              background: "rgba(0,0,0,0.3)", border: `1px solid ${accent}44`,
              fontSize: "14px", fontWeight: 700, color: accent,
              minWidth: "80px", textAlign: "center",
              fontFamily: "'Share Tech Mono', monospace",
            }}>
              {panicKeyInput ? "Press any key..." : panicKey}
            </div>
            <button ref={capRef} onClick={startCapture}
              style={{
                padding: "8px 16px", borderRadius: "8px",
                border: "1px solid rgba(255,255,255,0.12)",
                background: panicKeyInput ? `${accent}22` : "rgba(255,255,255,0.06)",
                color: "rgba(255,255,255,0.6)", fontSize: "11px", cursor: "pointer",
                fontFamily: "inherit", transition: "all 0.15s",
              }}
            >
              {panicKeyInput ? "Listening..." : "Change"}
            </button>
          </div>
        </div>

        <div style={{
          padding: "12px 16px", borderRadius: "10px",
          background: `${accent}0d`, border: `1px solid ${accent}22`,
          fontSize: "11px", color: `${accent}cc`, lineHeight: 1.6,
        }}>
          💡 These settings can be changed anytime in the Settings panel.
        </div>
      </div>
    </div>
  );
}

/* ── PAGE 6: Feature tour ────────────────────────────────── */
function PageFeatures({ accent }: PageProps) {
  const features = [
    { icon: "🌐", title: "Smart Browser", desc: "Proxy any website through Phoenix's secure relay layer." },
    { icon: "🎮", title: "3,700+ Games", desc: "HTML5, Flash, GBA, NDS and more — no downloads needed." },
    { icon: "🎬", title: "Movies & TV", desc: "Browse thousands of titles with TMDb-powered discovery." },
    { icon: "🤖", title: "Phoenix AI", desc: "GPT-style AI assistant with 47 prompt categories." },
    { icon: "💬", title: "Global Chat", desc: "Real-time chat with all Phoenix users — 24/7." },
    { icon: "🎵", title: "Music", desc: "Stream music and discover new artists and playlists." },
    { icon: "📺", title: "Anime", desc: "Watch anime series with episode browsing." },
    { icon: "🌟", title: "Apps Hub", desc: "Curated collection of web apps and tools." },
  ];

  return (
    <div>
      <div style={{ marginBottom: "6px", fontSize: "10px", color: accent, letterSpacing: "0.12em" }}>FEATURE OVERVIEW</div>
      <h2 style={{ margin: "0 0 6px", fontSize: "22px", fontWeight: 600, color: "#fff", fontFamily: "'Barlow', sans-serif" }}>
        Everything in Phoenix.
      </h2>
      <p style={{ margin: "0 0 16px", fontSize: "12px", color: "rgba(255,255,255,0.35)" }}>
        Navigate with the sidebar on the left — here's what you'll find.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "8px" }}>
        {features.map(f => (
          <FeatureCard key={f.title} {...f} accent={accent} />
        ))}
      </div>
    </div>
  );
}

/* ── PAGE 7: Tools & Productivity ────────────────────────── */
function PageTools({ accent }: PageProps) {
  const tools = [
    { icon: "🧮", title: "Calculator", desc: "Full 4-function calc available on the home screen." },
    { icon: "⏱️", title: "Focus Timer", desc: "Pomodoro 25/5 work-break timer to stay on task." },
    { icon: "📝", title: "Notepad", desc: "Quick scratch pad — content persists across sessions." },
    { icon: "✅", title: "To-Do List", desc: "Track tasks with checkboxes. Lives in the home sidebar." },
    { icon: "🔖", title: "Bookmarks", desc: "Star any website for instant access from the home screen." },
    { icon: "🕐", title: "Browse History", desc: "Full proxied-page history with search and clear controls." },
    { icon: "🎭", title: "Incognito Mode", desc: "Browse without recording history — toggle from the sidebar." },
    { icon: "⌨️", title: "Keyboard Shortcuts", desc: "Press ? anytime to see all available hotkeys." },
  ];

  return (
    <div>
      <div style={{ marginBottom: "6px", fontSize: "10px", color: accent, letterSpacing: "0.12em" }}>TOOLS & PRODUCTIVITY</div>
      <h2 style={{ margin: "0 0 6px", fontSize: "22px", fontWeight: 600, color: "#fff", fontFamily: "'Barlow', sans-serif" }}>
        Built-in tools.
      </h2>
      <p style={{ margin: "0 0 16px", fontSize: "12px", color: "rgba(255,255,255,0.35)" }}>
        Phoenix ships with a full suite of productivity tools on the home dashboard.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "8px" }}>
        {tools.map(t => (
          <FeatureCard key={t.title} {...t} accent={accent} />
        ))}
      </div>
    </div>
  );
}

/* ── PAGE 8: Ready ───────────────────────────────────────── */
function PageReady({ accent }: PageProps) {
  const { displayed } = useTypewriter("System initialization complete.", 36, 200);
  const { displayed: sub } = useTypewriter("All modules loaded. Phoenix is ready.", 28, 1600);
  const [pct, setPct] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const dur = 1800;
    const tick = () => {
      const p = Math.min(100, Math.round(((Date.now() - start) / dur) * 100));
      setPct(p);
      if (p < 100) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, []);

  return (
    <div style={{ textAlign: "center", padding: "8px 0" }}>
      <div style={{ marginBottom: "20px" }}>
        <svg width="64" height="64" viewBox="0 0 16 16" style={{ imageRendering: "pixelated", filter: `drop-shadow(0 0 20px ${accent})` }}>
          <rect x="7" y="14" width="2" height="1" fill="#f97316" />
          <rect x="6" y="13" width="4" height="1" fill="#fb923c" />
          <rect x="5" y="13" width="1" height="2" fill="#f97316" />
          <rect x="10" y="13" width="1" height="2" fill="#f97316" />
          <rect x="4" y="14" width="1" height="1" fill="#ea580c" />
          <rect x="11" y="14" width="1" height="1" fill="#ea580c" />
          <rect x="5" y="8" width="6" height="5" fill="#fb923c" />
          <rect x="4" y="9" width="1" height="3" fill="#fb923c" />
          <rect x="11" y="9" width="1" height="3" fill="#fb923c" />
          <rect x="6" y="8" width="4" height="1" fill="#fed7aa" />
          <rect x="1" y="7" width="4" height="3" fill="#f97316" />
          <rect x="11" y="7" width="4" height="3" fill="#f97316" />
          <rect x="1" y="10" width="3" height="1" fill="#ea580c" />
          <rect x="12" y="10" width="3" height="1" fill="#ea580c" />
          <rect x="3" y="6" width="2" height="1" fill="#f97316" />
          <rect x="11" y="6" width="2" height="1" fill="#f97316" />
          <rect x="4" y="5" width="8" height="3" fill="#fbbf24" />
          <rect x="5" y="4" width="6" height="1" fill="#fef3c7" />
          <rect x="6" y="3" width="4" height="1" fill="#fff" />
          <rect x="7" y="2" width="2" height="1" fill="#fff" />
          <rect x="6" y="7" width="1" height="2" fill="#fff" />
          <rect x="9" y="7" width="1" height="2" fill="#fff" />
          <rect x="7" y="9" width="2" height="1" fill="#fed7aa" />
        </svg>
      </div>

      <div style={{ fontSize: "16px", color: "rgba(255,255,255,0.8)", minHeight: "24px", marginBottom: "6px" }}>
        {displayed}<span style={{ opacity: 0.4 }}>_</span>
      </div>
      <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.35)", minHeight: "18px", marginBottom: "24px" }}>
        {sub}
      </div>

      {/* Progress bar */}
      <div style={{ marginBottom: "20px" }}>
        <div style={{
          width: "100%", height: "3px", borderRadius: "2px",
          background: "rgba(255,255,255,0.08)", overflow: "hidden",
        }}>
          <div style={{
            height: "100%", borderRadius: "2px",
            width: `${pct}%`,
            background: `linear-gradient(90deg, ${accent}88, ${accent})`,
            boxShadow: `0 0 8px ${accent}`,
            transition: "width 0.05s linear",
          }} />
        </div>
        <div style={{ marginTop: "6px", fontSize: "10px", color: "rgba(255,255,255,0.25)", textAlign: "right", fontVariantNumeric: "tabular-nums" }}>
          {pct}%
        </div>
      </div>

      {/* Status lines */}
      {["Core modules ✓", "Media services ✓", "Proxy layer ✓", "AI assistant ✓", "Chat relay ✓"].map((line, i) => (
        <div key={line} style={{
          fontSize: "11px", color: "rgba(255,255,255,0.3)", textAlign: "left",
          padding: "3px 0",
          opacity: pct > (i + 1) * 16 ? 1 : 0,
          transition: "opacity 0.3s",
        }}>
          <span style={{ color: accent, marginRight: "8px" }}>›</span>{line}
        </div>
      ))}
    </div>
  );
}
