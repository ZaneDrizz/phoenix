import { useMemo } from "react";
import {
  Activity, ArrowRight, Bookmark, Clock3, Compass, Film, Gamepad2,
  Library, Play, Sparkles, Tv2, WandSparkles,
} from "lucide-react";
import { getWatchHistory, formatProgress } from "../lib/watch-history";
import { getMovieWatchlist, getAnimeWatchlist } from "../lib/watchlist";
import { getRecentGames } from "../lib/gameprefs";

type Destination = "browser" | "movies" | "tv" | "anime" | "games" | "music" | "ai" | "html";

interface WorkspaceViewProps {
  mode: "discover" | "library" | "activity";
  accent: string;
  onNavigate: (destination: Destination) => void;
  onSearch: () => void;
}

const buttonStyle = (accent: string): React.CSSProperties => ({
  display: "inline-flex",
  alignItems: "center",
  gap: 8,
  border: "1px solid rgba(255,255,255,0.12)",
  borderRadius: 10,
  padding: "9px 13px",
  background: "rgba(255,255,255,0.06)",
  color: "rgba(255,255,255,0.82)",
  cursor: "pointer",
  font: "inherit",
  fontSize: 12,
});

function Empty({ text }: { text: string }) {
  return <div style={{ color: "rgba(255,255,255,0.35)", fontSize: 13, padding: "28px 0" }}>{text}</div>;
}

export default function WorkspaceView({ mode, accent, onNavigate, onSearch }: WorkspaceViewProps) {
  const history = useMemo(() => getWatchHistory(), [mode]);
  const movieList = useMemo(() => getMovieWatchlist(), [mode]);
  const animeList = useMemo(() => getAnimeWatchlist(), [mode]);
  const games = useMemo(() => getRecentGames(), [mode]);

  if (mode === "discover") {
    const actions: Array<{ title: string; copy: string; icon: React.ReactNode; destination: Destination }> = [
      { title: "Browse the open web", copy: "Search, explore, and keep your recent pages close.", icon: <Compass size={20} />, destination: "browser" },
      { title: "Find something to watch", copy: "Movies, series, and anime with searchable details.", icon: <Film size={20} />, destination: "movies" },
      { title: "Ask Phoenix", copy: "Get help writing, coding, planning, or researching.", icon: <Sparkles size={20} />, destination: "ai" },
      { title: "Play a quick game", copy: "Jump back into your recently played games.", icon: <Gamepad2 size={20} />, destination: "games" },
      { title: "Listen while you work", copy: "Open music and keep your session moving.", icon: <Tv2 size={20} />, destination: "music" },
      { title: "Build a page", copy: "Write and preview HTML in the built-in editor.", icon: <WandSparkles size={20} />, destination: "html" },
    ];
    return (
      <WorkspaceFrame eyebrow="PHOENIX WORKSPACE" title="What are you exploring today?" subtitle="One place for the web, entertainment, tools, and ideas." accent={accent}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 22 }}>
          <button onClick={onSearch} style={{ ...buttonStyle(accent), background: accent, color: "#fff", borderColor: accent }}><Compass size={14} /> Search the web</button>
          <button onClick={() => onNavigate("ai")} style={buttonStyle(accent)}><Sparkles size={14} /> Open PhoenixGPT</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(210px,1fr))", gap: 12 }}>
          {actions.map(action => (
            <button key={action.title} onClick={() => onNavigate(action.destination)} style={{ textAlign: "left", padding: 18, minHeight: 132, borderRadius: 16, border: "1px solid rgba(255,255,255,0.1)", background: "linear-gradient(145deg,rgba(255,255,255,0.09),rgba(255,255,255,0.025))", color: "#fff", cursor: "pointer" }}>
              <div style={{ color: accent, marginBottom: 16 }}>{action.icon}</div>
              <div style={{ fontWeight: 650, fontSize: 14, marginBottom: 6 }}>{action.title}</div>
              <div style={{ color: "rgba(255,255,255,0.42)", fontSize: 12, lineHeight: 1.5 }}>{action.copy}</div>
            </button>
          ))}
        </div>
        <div style={{ marginTop: 24, padding: 18, borderRadius: 16, border: `1px solid ${accent}35`, background: `${accent}10`, display: "flex", alignItems: "center", gap: 14 }}>
          <Activity size={18} color={accent} />
          <div style={{ flex: 1 }}><div style={{ color: "#fff", fontSize: 13, fontWeight: 600 }}>Your workspace is ready</div><div style={{ color: "rgba(255,255,255,0.4)", fontSize: 12, marginTop: 4 }}>Saved lists and browsing history stay on this device.</div></div>
          <ArrowRight size={16} color={accent} />
        </div>
      </WorkspaceFrame>
    );
  }

  if (mode === "library") {
    return (
      <WorkspaceFrame eyebrow="YOUR COLLECTION" title="Library" subtitle="Pick up where you left off or revisit something you saved." accent={accent}>
        <Section title="Continue watching" icon={<Play size={15} />} accent={accent}>
          {history.length === 0 ? <Empty text="Nothing here yet. Open Movies, TV, or Anime to start a watch history." /> : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(190px,1fr))", gap: 10 }}>
              {history.slice(0, 8).map(item => <button key={`${item.type}-${item.id}`} onClick={() => onNavigate(item.type === "anime" ? "anime" : item.type === "tv" ? "tv" : "movies")} style={listRow(accent)}><div style={{ width: 40, height: 54, borderRadius: 7, background: item.poster ? `url(${item.poster}) center/cover` : `${accent}22` }} /><div style={{ textAlign: "left", minWidth: 0, flex: 1 }}><div style={{ color: "#fff", fontSize: 12, fontWeight: 600, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>{item.title}</div><div style={{ color: accent, fontSize: 11, marginTop: 5 }}>{formatProgress(item)}</div></div><ArrowRight size={14} color="rgba(255,255,255,0.35)" /></button>)}
            </div>
          )}
        </Section>
        <Section title="Saved to watch" icon={<Bookmark size={15} />} accent={accent}>
          {movieList.length + animeList.length === 0 ? <Empty text="Your saved movies, shows, and anime will appear here." /> : <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{[...movieList, ...animeList].slice(0, 16).map(item => <button key={`${item.type}-${item.id}`} onClick={() => onNavigate(item.type === "anime" ? "anime" : "movies")} style={tagStyle(accent)}>{item.title}</button>)}</div>}
        </Section>
      </WorkspaceFrame>
    );
  }

  return (
    <WorkspaceFrame eyebrow="RECENT SIGNALS" title="Activity" subtitle="A quiet timeline of what you have been doing in Phoenix." accent={accent}>
      <Section title="Recent games" icon={<Gamepad2 size={15} />} accent={accent}>
        {games.length === 0 ? <Empty text="Launch a game and it will appear here." /> : <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{games.map(game => <button key={game.u} onClick={() => onNavigate("games")} style={tagStyle(accent)}>{game.t}</button>)}</div>}
      </Section>
      <Section title="Watch activity" icon={<Clock3 size={15} />} accent={accent}>
        {history.length === 0 ? <Empty text="Your viewing activity will appear here." /> : history.slice(0, 10).map(item => <button key={`${item.type}-${item.id}`} onClick={() => onNavigate(item.type === "anime" ? "anime" : item.type === "tv" ? "tv" : "movies")} style={{ ...listRow(accent), width: "100%", marginBottom: 8 }}><Clock3 size={15} color={accent} /><div style={{ flex: 1, textAlign: "left" }}><div style={{ color: "#fff", fontSize: 12, fontWeight: 600 }}>{item.title}</div><div style={{ color: "rgba(255,255,255,0.38)", fontSize: 11, marginTop: 3 }}>{item.type.toUpperCase()} · {formatProgress(item)}</div></div><ArrowRight size={14} color="rgba(255,255,255,0.3)" /></button>)}
      </Section>
    </WorkspaceFrame>
  );
}

function WorkspaceFrame({ eyebrow, title, subtitle, accent, children }: { eyebrow: string; title: string; subtitle: string; accent: string; children: React.ReactNode }) {
  return <main style={{ flex: 1, overflowY: "auto", padding: "clamp(28px,6vw,72px) clamp(22px,6vw,90px)", position: "relative", zIndex: 2 }}><div style={{ maxWidth: 980, margin: "0 auto" }}><div style={{ color: accent, fontSize: 10, letterSpacing: "0.16em", fontWeight: 700, marginBottom: 14 }}>{eyebrow}</div><h1 style={{ margin: 0, color: "#fff", fontSize: "clamp(28px,4vw,46px)", letterSpacing: "-0.04em", lineHeight: 1.05 }}>{title}</h1><p style={{ margin: "12px 0 30px", color: "rgba(255,255,255,0.45)", fontSize: 14 }}>{subtitle}</p>{children}</div></main>;
}

function Section({ title, icon, accent, children }: { title: string; icon: React.ReactNode; accent: string; children: React.ReactNode }) {
  return <section style={{ marginTop: 26 }}><h2 style={{ display: "flex", alignItems: "center", gap: 8, color: "#fff", fontSize: 15, margin: "0 0 12px" }}><span style={{ color: accent }}>{icon}</span>{title}</h2>{children}</section>;
}

function listRow(accent: string): React.CSSProperties { return { display: "flex", alignItems: "center", gap: 11, padding: 10, borderRadius: 11, border: "1px solid rgba(255,255,255,0.09)", background: "rgba(255,255,255,0.045)", color: "#fff", cursor: "pointer" }; }
function tagStyle(accent: string): React.CSSProperties { return { padding: "9px 12px", borderRadius: 9, border: `1px solid ${accent}30`, background: `${accent}10`, color: "rgba(255,255,255,0.75)", cursor: "pointer", fontSize: 12, textAlign: "left" }; }