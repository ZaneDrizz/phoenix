const MOVIE_KEY = "phoenix.movieWatchlist";
const ANIME_KEY = "phoenix.animeWatchlist";

export interface WatchlistItem {
  id: number;
  title: string;
  poster?: string;
  type: "movie" | "tv" | "anime";
  addedAt: string;
}

function loadList(key: string): WatchlistItem[] {
  try { return JSON.parse(localStorage.getItem(key) || "[]"); } catch { return []; }
}
function saveList(key: string, list: WatchlistItem[]) {
  try { localStorage.setItem(key, JSON.stringify(list)); } catch {}
}

export function getMovieWatchlist(): WatchlistItem[] { return loadList(MOVIE_KEY); }
export function getAnimeWatchlist(): WatchlistItem[] { return loadList(ANIME_KEY); }

export function toggleMovieWatchlist(item: Omit<WatchlistItem, "addedAt">): boolean {
  const list = getMovieWatchlist();
  const idx = list.findIndex(i => i.id === item.id && i.type === item.type);
  if (idx >= 0) { list.splice(idx, 1); saveList(MOVIE_KEY, list); return false; }
  list.unshift({ ...item, addedAt: new Date().toISOString() });
  saveList(MOVIE_KEY, list);
  return true;
}

export function isInMovieWatchlist(id: number, type: "movie" | "tv"): boolean {
  return getMovieWatchlist().some(i => i.id === id && i.type === type);
}

export function toggleAnimeWatchlist(item: Omit<WatchlistItem, "addedAt">): boolean {
  const list = getAnimeWatchlist();
  const idx = list.findIndex(i => i.id === item.id);
  if (idx >= 0) { list.splice(idx, 1); saveList(ANIME_KEY, list); return false; }
  list.unshift({ ...item, addedAt: new Date().toISOString() });
  saveList(ANIME_KEY, list);
  return true;
}

export function isInAnimeWatchlist(id: number): boolean {
  return getAnimeWatchlist().some(i => i.id === id);
}
