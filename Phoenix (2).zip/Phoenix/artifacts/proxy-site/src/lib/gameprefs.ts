const FAVS_KEY = "phoenix.gameFavorites";
const RECENT_KEY = "phoenix.gameRecent";

export interface GameEntry { t: string; u: string; g?: string; }

function load<T>(key: string, fallback: T): T {
  try { const v = localStorage.getItem(key); return v == null ? fallback : JSON.parse(v) as T; }
  catch { return fallback; }
}

export function getGameFavorites(): GameEntry[] { return load<GameEntry[]>(FAVS_KEY, []); }

export function toggleGameFavorite(game: GameEntry): boolean {
  const favs = getGameFavorites();
  const idx = favs.findIndex(g => g.u === game.u);
  if (idx >= 0) {
    favs.splice(idx, 1);
    localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
    return false;
  }
  favs.unshift(game);
  localStorage.setItem(FAVS_KEY, JSON.stringify(favs.slice(0, 24)));
  return true;
}

export function isGameFavorite(url: string): boolean {
  return getGameFavorites().some(g => g.u === url);
}

export function getRecentGames(): GameEntry[] { return load<GameEntry[]>(RECENT_KEY, []); }

export function addToRecentGames(game: GameEntry): void {
  const recent = getRecentGames().filter(g => g.u !== game.u);
  recent.unshift(game);
  localStorage.setItem(RECENT_KEY, JSON.stringify(recent.slice(0, 8)));
}
