export interface WatchEntry {
  id: number | string;
  type: "movie" | "tv" | "anime";
  title: string;
  poster: string | null;
  season?: number;
  episode?: number;
  audioTrack?: "sub" | "dub";
  updatedAt: number;
}

const KEY = "phoenix.watchHistory";
const MAX = 24;

export function getWatchHistory(): WatchEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    return JSON.parse(raw) as WatchEntry[];
  } catch {
    return [];
  }
}

export function saveToHistory(entry: Omit<WatchEntry, "updatedAt">) {
  try {
    const hist = getWatchHistory().filter(
      e => !(e.id === entry.id && e.type === entry.type)
    );
    hist.unshift({ ...entry, updatedAt: Date.now() });
    localStorage.setItem(KEY, JSON.stringify(hist.slice(0, MAX)));
  } catch { /* quota */ }
}

export function removeFromHistory(id: number | string, type: WatchEntry["type"]) {
  try {
    const hist = getWatchHistory().filter(e => !(e.id === id && e.type === type));
    localStorage.setItem(KEY, JSON.stringify(hist));
  } catch { /* quota */ }
}

export function formatProgress(entry: WatchEntry): string {
  if (entry.type === "movie") return "Movie";
  if (entry.season != null && entry.episode != null) {
    return `S${entry.season} E${entry.episode}`;
  }
  if (entry.episode != null) return `Ep ${entry.episode}`;
  return "";
}
